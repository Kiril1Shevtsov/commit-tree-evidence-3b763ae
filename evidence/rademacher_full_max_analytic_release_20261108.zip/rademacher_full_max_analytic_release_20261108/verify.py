#!/usr/bin/env python3
"""Offline inventory, source binding and independent exact replay; not formal proof.

Python 3.8+ standard library only. No network or original workspace required.
All checks remain active under -O. Audit scripts are executed byte-for-byte.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
SCHEMA = 'rademacher-full-max-analytic-v1'
KEY_HASHES = {
 'components/lower/primary/PROOF.md': 'a01325278bbcfaaae016dcfe1b18df39431573a9d7a13c50abfa792324988d8d',
 'components/outer/primary/PROOF.md': 'ab850f6df7bf0656a87a88bb9d96cb2de155a79cf2afbbeb58b9f515844fb12d',
 'components/central/audit/AUDIT.md': 'de4dba4728afa672d3b2de5d42d57f268e461dc1d56cc3f10315024a69528a5b',
 'components/central/primary_small/PROOF.md': 'b9379ccccc5f46717184dd3c65d418ba50cf3731094d73b7e862714683deaeb7',
 'components/central/primary_middle/PROOF.md': '8dc11ad40ae93b1509e9c364a5cfb76c130c806216250a823e54d2eda84bacf5',
 'components/central/cap_defect/PROOF.md': '44024e7bd4c9e78e3144b8b5154149a1fd02a9ceb1bb85b686bb891ddddc513a',
}
COVERAGE = {
 'lower': {'m':'0<m<=1', 'x':'0<=x<infinity', 'event':'|X|<x', 'comparison':'>=', 'status':'PASS'},
 'outer_new': {'m':'3/20<=m<=1', 'x':'m<=x<infinity', 'event':'|X|<=x', 'comparison':'<=', 'status':'PASS'},
 'outer_inherited_small_max': {'m':'0<m<=3/20', 'x':'m<=x<infinity', 'event':'|X|<=x', 'comparison':'<=', 'status':'PASS'},
 'central_small': {'m':'0<m<=1/2', 'x':'0<=x<=m', 'event':'|X|<=x', 'comparison':'<=', 'status':'PASS'},
 'central_middle': {'m':'1/2<=m<=27/40', 'x':'0<=x<=m', 'event':'|X|<=x', 'comparison':'<=', 'status':'PASS'},
 'central_large': {'m':'27/40<=m<=1', 'x':'0<=x<=m', 'event':'|X|<=x', 'comparison':'<=', 'status':'PASS'},
}

def need(ok, message):
    if not ok:
        raise RuntimeError(message)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))

def safe_relative(rel):
    p = PurePosixPath(rel)
    need(bool(rel) and not p.is_absolute() and '..' not in p.parts and str(p)==rel,
         'unsafe relative path: '+str(rel))
    return p

def flags():
    return (['-O'] if sys.flags.optimize else []) + ['-I', '-S', '-B']

def verify(root):
    manifest = read_json(root/'MANIFEST.json')
    need(manifest['schema']==SCHEMA, 'wrong schema')
    files = manifest['files']
    actual = set()
    for p in root.rglob('*'):
        need(not p.is_symlink(), 'symlink forbidden: '+str(p))
        if p.is_file():
            actual.add(p.relative_to(root).as_posix())
    need(actual==set(files)|{'MANIFEST.json'}, 'complete inventory mismatch')
    for rel, record in files.items():
        safe_relative(rel)
        need((root/rel).stat().st_size==record['bytes'], 'byte count mismatch: '+rel)
        need(digest(root/rel)==record['sha256'], 'hash mismatch: '+rel)
    sha_lines=(root/'SHA256SUMS').read_text(encoding='utf-8').splitlines()
    sha_records={line.split('  ',1)[1]:line.split('  ',1)[0] for line in sha_lines}
    need(set(sha_records)==set(files)-{'SHA256SUMS'}, 'SHA256SUMS inventory mismatch')
    for rel, sha in sha_records.items():
        need(sha==files[rel]['sha256'], 'SHA256SUMS digest mismatch: '+rel)
    for rel, sha in KEY_HASHES.items():
        need(digest(root/rel)==sha, 'wrong accepted version: '+rel)

    status=read_json(root/'STATUS.json')
    need(status['status']=='PASS_FULL_ANALYTIC_MAX_COMPOSITION', 'overall status drift')
    need(status['theorem']=='d_K(X,N(0,1)) <= Phi(max_i|a_i|)-1/2', 'theorem drift')
    need(status['coefficient_scope']=='Every finite real vector with sum_i a_i^2=1; independent unbiased signs; zeros and unequal coefficients allowed', 'coefficient scope drift')
    need(status['coverage']==COVERAGE, 'coverage drift')
    need(status['full_max_theorem'] is True and status['unrestricted_q_theorem'] is False, 'max/q scope drift')
    for field in ['formal_proof_assistant_verification','external_peer_review','novelty_claim','full_equality_classification','parameter_grid_as_proof_input','quadrature_as_proof_input','old_numerical_certificate_as_proof_input']:
        need(status[field] is False, 'unsupported claim: '+field)
    need(status['historical_text_policy']=='Immutable source bytes; later independent audits and top-level composition govern current scope', 'historical policy drift')

    source_map=read_json(root/'SOURCE_MAP.json')
    source_records=source_map['files']
    component_files={p for p in files if p.startswith('components/')}
    need({r['archive_path'] for r in source_records}==component_files, 'source map inventory mismatch')
    need(len(source_records)==len(component_files), 'duplicate source map entry')
    for record in source_records:
        rel=record['archive_path']; safe_relative(rel)
        need(digest(root/rel)==record['sha256'] and (root/rel).stat().st_size==record['bytes'], 'source binding mismatch: '+rel)

    lower=root/'components/lower'
    lv=read_json(lower/'audit/VERDICT.json')
    need(lv['status']=='PASS_INDEPENDENT_ANALYTIC_AUDIT', 'lower verdict drift')
    need(lv['accepted_scope']['combined_threshold_range']=='All x>=0, retaining the already independently accepted x<=2m theorem', 'lower scope drift')
    need(lv['checks']['independent_finite_exact_checks']==56, 'lower check count drift')
    need(lv['unresolved_blockers']==[] and lv['primary_corrections_required']==[], 'lower blockers')
    # Verify the older portable lower release as an unchanged sub-packet, without executing its verifier.
    lm=read_json(lower/'MANIFEST.json')
    need(lm['schema']=='analytic-full-lower-v1', 'lower manifest schema drift')
    need({p.relative_to(lower).as_posix() for p in lower.rglob('*') if p.is_file()}==set(lm['files'])|{'MANIFEST.json'}, 'lower inventory mismatch')
    for rel, sha in lm['files'].items():
        safe_relative(rel); need(digest(lower/rel)==sha, 'lower nested hash mismatch: '+rel)
    for rel, sha in read_json(lower/'primary/SOURCE_HASHES.json')['files'].items():
        safe_relative(rel); need(digest(lower/'primary'/rel)==sha, 'lower primary source mismatch')
    for r in read_json(lower/'audit/FROZEN_SOURCE_HASHES.json')['files']:
        need(digest(lower/'audit'/r['frozen_path'])==r['sha256'], 'lower frozen mismatch')
        need(digest(lower/'primary'/r['relative_path'])==r['sha256'], 'lower primary/frozen mismatch')

    outer=root/'components/outer'
    ov=read_json(outer/'audit/AUDIT_VERDICT.json')
    need(ov['status']=='PASS_COMPLETE_OUTER_WEAK_UPPER', 'outer verdict drift')
    need(ov['reviewed_primary_sha256']==KEY_HASHES['components/outer/primary/PROOF.md'], 'outer accepted proof mismatch')
    need(ov['independently_authored_check_count']==61 and ov['positive_Bernstein_coefficients']==25, 'outer exact count drift')
    need(ov['primary_corrections_required'] is False, 'outer corrections')
    for rel, sha in read_json(outer/'primary/SOURCE_HASHES.json')['files'].items():
        safe_relative(rel); need(digest(outer/'primary'/rel)==sha, 'outer source mismatch: '+rel)
    for rel, sha in read_json(outer/'audit/FROZEN_SOURCE_HASHES.json')['files'].items():
        safe_relative(rel)
        need(digest(outer/'primary'/rel)==sha, 'outer primary/frozen source mismatch')
        need(digest(outer/'audit/frozen_sources/candidate'/rel)==sha, 'outer frozen mismatch')
    small=outer/'primary/frozen_inputs/ACCEPTED_SMALL_UPPER_AUDIT/AUDIT_VERDICT.json'
    sv=read_json(small)
    need(sv['status']=='PASS_INDEPENDENT_UPPER015_AUDIT', 'inherited small-max verdict drift')
    need(sv['saved_outputs_match_byte_for_byte'] is True and sv['input_hashes_unchanged'] is True, 'small-max historical integrity drift')
    for rel, sha in sv['input_sha256'].items():
        need(digest(outer/'primary/frozen_inputs/ACCEPTED_SMALL_UPPER_PROOF'/rel)==sha, 'small-max input mismatch: '+rel)

    central=root/'components/central'
    cv=read_json(central/'audit/VERDICT.json')
    need(cv['status']=='PASS' and cv['open_blockers']==[] and cv['mathematical_corrections_required']==[], 'central verdict drift')
    need(cv['checks']['total']==117 and cv['checks']['finite_exact_mathematical_checks']==93 and cv['checks']['original_and_frozen_hash_checks']==24, 'central check count drift')
    frozen=read_json(central/'audit/FROZEN_INPUTS.json')
    relocation=read_json(root/'PORTABLE_SOURCE_MAP.json')['central_originals']
    need(len(frozen)==12 and len(relocation)==12, 'central input count drift')
    for item, mapping in zip(frozen, relocation):
        need(mapping['original_path']==item['source'] and mapping['frozen_path']==item['frozen'], 'relocation ordering mismatch')
        safe_relative(mapping['archive_path'])
        need(digest(central/'audit'/item['frozen'])==item['sha256'], 'central frozen hash mismatch')
        need(digest(root/mapping['archive_path'])==item['sha256'], 'central original mirror hash mismatch')
        need((central/'audit'/item['frozen']).stat().st_size==item['bytes'], 'central frozen size mismatch')

    # Replay only independently authored finite-rational audit scripts.
    # Each runs in its own temp directory; canonical proof/audit bytes are never edited.
    replay=[]
    specs=[('lower',lower/'audit','independent_exact_checks.py','checks_count',56),
           ('outer',outer/'audit','independent_exact_checks.py','check_count',61),
           ('central',central/'audit','independent_verifier.py','check_count',117)]
    for name, audit, script_name, count_key, expected_count in specs:
        expected=(audit/'INDEPENDENT_EXACT_RESULTS.json').read_bytes()
        with tempfile.TemporaryDirectory(prefix='max_analytic_'+name+'_') as td:
            work=Path(td)/'audit';work.mkdir()
            shutil.copyfile(audit/script_name,work/script_name)
            if name=='central':
                shutil.copytree(audit/'frozen_inputs',work/'frozen_inputs')
                tmp_records=read_json(audit/'FROZEN_INPUTS.json')
                originals=Path(td)/'originals'; originals.mkdir()
                for index,(record,mapping) in enumerate(zip(tmp_records,relocation)):
                    mirror=originals/('%02d'%index)
                    shutil.copyfile(root/mapping['archive_path'],mirror)
                    record['source']=str(mirror)
                # This is the sole relocated metadata, outside the release. The frozen source
                # and all output check names/digests stay exactly the same.
                (work/'FROZEN_INPUTS.json').write_text(json.dumps(tmp_records,indent=2)+'\n',encoding='utf-8')
            run=subprocess.run([sys.executable]+flags()+[str(work/script_name)],cwd=work,capture_output=True,text=True,timeout=180)
            need(run.returncode==0, name+' independent checker failed: '+run.stderr)
            observed=(work/'INDEPENDENT_EXACT_RESULTS.json').read_bytes()
            need(observed==expected, name+' exact output is not byte-identical')
        result=json.loads(expected)
        need(result['status']=='PASS' and result[count_key]==expected_count, name+' saved result drift')
        if name=='lower':
            need(sum(len(b['coefficients']) for b in result['bernstein'])==25, 'lower Bernstein count drift')
        if name=='outer':
            need(len(result['P1_Bernstein_coefficients'])+len(result['P2_Bernstein_coefficients'])==25, 'outer Bernstein count drift')
        replay.append({'audit':name,'checks':expected_count,'exact_output_byte_identical':True,'optimized_child':bool(sys.flags.optimize)})
    return {'status':'PASS','schema':SCHEMA,'inventory_files':len(files)+1,
            'frozen_source_files':len(source_records),'covered_components':len(COVERAGE),
            'independent_replays':replay,'finite_mathematical_checks':210,
            'central_original_frozen_hash_checks':24,'total_replayed_checks':234,
            'positive_Bernstein_coefficients_lower_outer':50,
            'original_workspace_required':False,'primary_checkers_executed':False,
            'old_numerical_certificates_executed':False,'formal_proof_verification':False}

def negative_controls(root):
    outcomes=[]
    for mode in ('modified_proof','missing_status','unexpected_file'):
        with tempfile.TemporaryDirectory(prefix='max_analytic_negative_') as td:
            target=Path(td)/'release';shutil.copytree(root,target)
            if mode=='modified_proof':
                path=target/'components/central/primary_small/PROOF.md'
                original=path.read_bytes()
                need(bool(original), 'negative-control source empty')
                path.write_bytes(bytes([original[0] ^ 1])+original[1:])
            elif mode=='missing_status':
                (target/'STATUS.json').unlink()
            else:
                (target/'UNEXPECTED.txt').write_text('negative control',encoding='utf-8')
            try:
                verify(target)
            except RuntimeError as e:
                outcomes.append({'control':mode,'result':'REJECTED_AS_EXPECTED','reason':str(e)})
            else:
                raise RuntimeError('negative control incorrectly accepted: '+mode)
    return outcomes

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--negative-controls',action='store_true')
    args=parser.parse_args()
    try:
        result=verify(ROOT)
        if args.negative_controls:
            result['negative_controls']=negative_controls(ROOT)
        print(json.dumps(result,indent=2))
    except Exception as exc:
        print('FAIL: '+str(exc),file=sys.stderr)
        sys.exit(1)
