#!/usr/bin/env python3
"""Exact rational checks for the analytical central endpoint proof.
No quadrature, numerical interval arithmetic, or parameter grid is used.
SymPy is used only for finite polynomial/rational identities.
"""
from fractions import Fraction as F
from math import factorial, prod
import sympy as sp

passed = 0

def check(name, condition):
    global passed
    assert bool(condition), name
    passed += 1
    print('PASS:', name)

def E(n, x):
    return sum((x**j / factorial(j) for j in range(n+1)), F(0))

B=F(58,25); M=F(27,40); x=B*B/2
pi_lo=F(157,50); pi_hi=F(22,7)
check('MB < pi_lo/2', M*B<pi_lo/2)
check('cosine forcing positive through pi/2', 304-33*(pi_hi/2)**2>0)
check('c upper 4/5', 2/pi_lo<F(4,5)**2)
check('c lower 319/400', 2/pi_hi>F(319,400)**2)
check('positive exponential lower sum', E(8,x)>F(250,17))
exp_upper=E(6,x)+(x**7/factorial(7))/(1-x/8)
check('positive exponential upper tail', exp_upper<F(1595,108))
check('K upper product', F(4,5)*F(17,250)==F(34,625))
check('K lower product', F(319,400)*F(108,1595)==F(27,500))
check('C < 79/10 via pi_hi', 2*pi_hi**3<F(79,10)**2)
check('log 2 < 7/10', E(4,F(7,10))>2)
check('8 log2/pi2 < 4/7', 8*F(7,10)/pi_lo**2<F(4,7))
check('quartic exponent at most 2/3', B**4/48<F(2,3))
check('exponential linear coefficient', F(59,81)>F(18,25))

z=sp.symbols('z')
p=1-z**4/12-z**6/45-sp.Rational(11,3360)*z**8
q=sp.diff(p,z,2)-2*z*sp.diff(p,z)+z*z*p
check('cosine polynomial ODE identity', sp.expand(q-z**8*(304-33*z*z)/10080)==0)
L=z*(z*z+5)/(z**4+6*z*z+3)
U=(z*z+2)/(z**3+3*z)
check('lower Mills residual identity', sp.cancel(sp.diff(L,z)-z*L+1-24/(z**4+6*z*z+3)**2)==0)
check('upper Mills residual identity', sp.cancel(sp.diff(U,z)-z*U+1+6/(z*z*(z*z+3)**2))==0)

LB=B*(B*B+5)/(B**4+6*B*B+3)
UB=(B*B+2)/(B**3+3*B)
P=F(0); ml={}; mu={}
for n in range(2,13,2):
    P=B**(n-1)+(n-1)*P
    d=prod(range(1,n,2))
    if n==2:
        continue
    check(f'moment {n}: B^n > double factorial', B**n-d>0)
    bl=(B**n-d)*LB-P
    bu=(B**n-d)*UB-P
    check(f'moment {n}: both brackets negative', bl<0 and bu<0)
    ml[n]=d+F(34,625)*bl
    mu[n]=d+F(27,500)*bu
for n,bound in [(4,F(247,100)),(6,F(89,10)),(8,F(37))]:
    check(f'M{n} rational lower bound >= {bound}', ml[n]>=bound)
for n,bound in [(8,F(39)),(10,F(180)),(12,F(875))]:
    check(f'M{n} rational upper bound <= {bound}', mu[n]<=bound)

# Zero-defect polynomial identity.
t=sp.symbols('t')
Elo=sp.Rational(247,100)-sp.Rational(39,12)*t**2-sp.Rational(180,45)*t**3-sp.Rational(11*875,3360)*t**4
D=t/6-t**2/40+t**3/336-sp.Rational(247,1200)*t**2-sp.Rational(89,450)*t**3-sp.Rational(407,3360)*t**4-sp.Rational(18,25)*t*(1-t)/12*Elo
N=433125*t**5+171675*t**4+191850*t**3-500*t**2+208236*t-46536
check('zero-defect polynomial identity', sp.expand(D+t*N/2520000)==0)
check('N(1/4) exact value', N.subs(t,sp.Rational(1,4))==sp.Rational(9812977,1024))
check('N derivative positive on [0,1]', 208236-1000>0)
check('t interval lies in [1/4,1]', F(1,4)<=M*M<=1)

# Maximal-defect head polynomial.
m=sp.symbols('m')
Pm=m/6-sp.Rational(277,1200)*m**3-sp.Rational(4909,25200)*m**5-sp.Rational(407,3360)*m**7
check('P derivative at 1/2', sp.diff(Pm,m).subs(m,sp.Rational(1,2))==-sp.Rational(259927,3225600))
check('P(M) positive', Pm.subs(m,sp.Rational(27,40))>0)
check('head threshold at 1/2', sp.Rational(79,10)*Pm.subs(m,sp.Rational(1,2))==sp.Rational(24180241,64512000))
check('first head threshold below 3/8', F(24180241,64512000)<F(3,8))
check('head threshold at 3/5', sp.Rational(79,10)*Pm.subs(m,sp.Rational(3,5))==sp.Rational(218444243,875000000))
check('second head threshold below 1/4', F(218444243,875000000)<F(1,4))

# Explicitly integrated Taylor polynomial lower bounds for J.
check('Q4 positivity endpoint', 1-F(9,4)/2+F(9,4)**2/6-F(9,4)**3/24==F(125,512))
for m0,n,r,threshold in [(F(3,5),5,8,F(47,125)), (F(27,40),3,4,F(13,50))]:
    b=pi_lo/(4*m0); k=pi_lo*(1-m0*m0)/(2*m0)
    check(f'Taylor range at m={m0}', F(4,7)*b*b<1 and k*b<F(9,4))
    S=sum(((-F(4,7))**i/factorial(i)*(-1)**(j+1)*k**j/factorial(j)*b**(2*i+j+2)/(2*i+j+2)
           for i in range(n+1) for j in range(1,r+1)), F(0))
    check(f'exact integrated Taylor bound S({n},{r}) at {m0} > {threshold}', S>threshold)
check('first J bound exceeds 3/8', F(47,125)>F(3,8))
check('second J bound exceeds 1/4', F(13,50)>F(1,4))
print(f'\nALL {passed} EXACT CHECKS PASS')
