from pathlib import Path
import hashlib, json, shutil
base=Path('/workspace/shared')
out=base/'rademacher_full_central_upper_independent_audit_20261108'
items={
 'small/PROOF.md':'rademacher_max_central_small_candidate_20261108/PROOF.md',
 'small/CAP_DEFECT_REFLECTION.md':'rademacher_max_central_small_candidate_20261108/frozen_inputs/CAP_DEFECT_REFLECTION.md',
 'middle/PROOF.md':'rademacher_max_central_endpoint_candidate_20261108/PROOF.md',
 'large/LARGE_MAX_COMPOSITION.md':'rademacher_max_paired_integral_closure_20261108/LARGE_MAX_COMPOSITION.md',
 'large/UPPER_HELPER_PRIMARY.md':'rademacher_max_paired_integral_closure_20261108/frozen_inputs/UPPER_HELPER_PRIMARY.md',
 'large/UPPER_HELPER_AUDIT.md':'rademacher_max_paired_integral_closure_20261108/frozen_inputs/UPPER_HELPER_AUDIT.md',
 'large/UPPER_HELPER_VERDICT.json':'rademacher_max_paired_integral_closure_20261108/frozen_inputs/UPPER_HELPER_VERDICT.json',
 'large/COMPOSITION_AUDIT.md':'rademacher_max_paired_closure_independent_audit_20261108/AUDIT.md',
 'large/COMPOSITION_VERDICT.json':'rademacher_max_paired_closure_independent_audit_20261108/VERDICT.json',
 'prawitz/EXTERNAL_INPUTS.md':'rademacher_max_reflection_bridge_release_20261108/EXTERNAL_INPUTS.md',
 'prawitz/REFLECTION.md':'rademacher_max_reflection_bridge_release_20261108/primary/REFLECTION.md',
 'prawitz/PRAWITZ_SOURCE_AUDIT.md':'rademacher_max_reflection_bridge_release_20261108/provenance/PRAWITZ_SOURCE_AUDIT.md',
}
expected={
 'small/PROOF.md':'b9379ccccc5f46717184dd3c65d418ba50cf3731094d73b7e862714683deaeb7',
 'small/CAP_DEFECT_REFLECTION.md':'44024e7bd4c9e78e3144b8b5154149a1fd02a9ceb1bb85b686bb891ddddc513a',
 'middle/PROOF.md':'8dc11ad40ae93b1509e9c364a5cfb76c130c806216250a823e54d2eda84bacf5',
 'large/UPPER_HELPER_PRIMARY.md':'07bd75b6e73e85f962e8efd7e10259f3a394d520d5afc84644d5f8e8b25fb2be',
 'large/UPPER_HELPER_AUDIT.md':'413e0bb71b1336cc480d953be06847698e1612d27b157c63de1ef2a25b056560',
 'large/UPPER_HELPER_VERDICT.json':'a7242979d720f104db0761d1cb95406620563900606e6c473a89a861d207f216',
}
records=[]
for name,rel in items.items():
 src=base/rel; data=src.read_bytes(); sha=hashlib.sha256(data).hexdigest()
 if name in expected and sha!=expected[name]: raise RuntimeError((name,'unexpected hash',sha))
 dest=out/'frozen_inputs'/name; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(data)
 records.append(dict(source=str(src),frozen=str(dest.relative_to(out)),sha256=sha,bytes=len(data),expected_hash_checked=name in expected))
(out/'FROZEN_INPUTS.json').write_text(json.dumps(records,indent=2)+'\n')
print('FROZEN',len(records),'files; all',len(expected),'provided hashes match')
