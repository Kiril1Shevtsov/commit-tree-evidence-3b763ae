# Independent audit of the full central weak upper bound

Date: 8 November 2026.

## Verdict and exact scope

**PASS.** No mathematical gap, incorrect constant, wrong inequality direction, uncovered parameter join, or lost atom was found. No primary proof correction is required.

For every finite sum X=sum a_i epsilon_i of independent unbiased signs, with sum a_i²=1 and actual maximum m=max|a_i|, this audit accepts

    P(|X|<=x) <= H(x)+H(m),   0<=x<=m,   0<m<=1,
    H=2Phi-1.

In fact the retained elementary helper proves the weak upper bound for all x>=0 when m>=27/40. The two new central components cover 0<m<=1/2 and 1/2<=m<=27/40, including their joins.

The proof is analytic for continuous parameters, arbitrary finite dimension, and unequal real coefficients; signs and zeros cause no restriction. The finite rational identities below do not constitute parameter sampling. There is no quadrature, coefficient grid, interval subdivision, or old numerical certificate in the accepted argument.

The full-CDF max theorem follows when this result is combined with the separately accepted outer upper and global strict lower results. Those two complete results are not independently re-audited in this packet. This packet does not prove the unrestricted fourth-mass q strengthening, originality, or a proof-assistant formalization.

## 1. Inputs, independence, and integrity

Twelve source files are frozen unchanged under frozen_inputs/. FROZEN_INPUTS.json records every original location, frozen location, SHA-256 digest, and byte count. All six provided key digests match, including:

- Small central PROOF.md: b9379ccccc5f46717184dd3c65d418ba50cf3731094d73b7e862714683deaeb7.
- CAP_DEFECT_REFLECTION.md: 44024e7bd4c9e78e3144b8b5154149a1fd02a9ceb1bb85b686bb891ddddc513a.
- Middle endpoint PROOF.md: 8dc11ad40ae93b1509e9c364a5cfb76c130c806216250a823e54d2eda84bacf5.

The large-maximum composition and its prior independent audit, the three frozen upper-helper inputs, and the accepted Prawitz/reflection source contract were reviewed. The old main small-coefficient proof and numerical records inside historical provenance files are not imported as hypotheses. Only the identified analytic Prawitz theorem and elementary large-maximum helper are needed here.

The primary checkers were not read, imported, or executed. independent_verifier.py was independently written from the displayed mathematical expressions. It uses Python Fraction and elementary polynomial operations. Its 117 checks consist of 93 finite mathematical checks and 24 original/frozen hash checks. The successful checks supplement the mathematical reasoning below; their count is not a substitute for proof.

The only non-elementary probability input used by this central proof is the accepted strict-tail Prawitz smoothing inequality in Keller and Klein, Theorem 4.5, (39)–(40), with the normalization frozen in prawitz/EXTERNAL_INPUTS.md. Its original proof is not reconstructed here. Source: https://arxiv.org/html/2006.16834v4#S4.SS1.SSS1 .

## 2. Normalization and the cap-defect lemma, from scratch

Coefficient signs can be absorbed into the signs epsilon_i. Put

    q=sum a_i^4, delta=m²-q, T=pi/m,
    f(s)=product cos(a_i s), c=sqrt(2/pi).

Since a maximum is attained in a finite vector,

    m^4<=q<=m² sum a_i²=m²,
    0<=delta<=m²-m^4.

For the first half-band 0<=s<T/2 every factor is positive. At s=T/2 the attained maximum contributes a zero; all subsequent inequalities extend continuously.

Let F(z)=-log|cos z|. We independently verify, for 0<=v<=pi/4 and 0<=r<=1,

    F((pi-v)r)-F(vr) >= (pi tan(v)/2)r²(1-r²).       (2.1)

When (pi-v)r<pi/2, the positive series of -log cos gives the lower bound pi(pi-2v)r²/2 on the left. It dominates the right since pi-2v>=pi/2>1>=tan v and 1-r²<=1. At a reflected cosine zero the inequality is immediate.

In the other region put z=pi-(pi-v)r. Then vr<=z<pi/2 and z-vr=pi(1-r). Convexity of -log cos on [0,pi/2) gives

    F(z)-F(vr)>=pi(1-r)tan(vr).

For 0<t<=pi/4, the derivative of tan(t)/t² has the sign of t-sin(2t). Concavity of sin on [0,pi/2] gives sin(2t)>=4t/pi>t. Hence tan(vr)>=r² tan v, and

    pi(1-r)tan(vr)>=pi r²(1-r)tan v
                        >=(pi tan v/2)r²(1-r²).

This establishes (2.1). Cases r=0, r=1, and v=0 are direct or continuous limits. In particular the v=0 case does not require evaluating tan(t)/t² at zero. Differentiating numerator and denominator at r=1 gives derivatives -pi tan v and -2, respectively, confirming the claimed optimal limiting coefficient for v>0.

Take v=ms and r_i=|a_i|/m. Since sum r_i²(1-r_i²)=delta/m^4, multiplication/exponentiation yields

    |f(T-s)| <= f(s) exp[-pi tan(ms)delta/(2m^4)]
              <= f(s) exp[-pi delta s/(2m³)],
                              0<=s<=T/4.             (2.2)

The last step uses tan(ms)>=ms and delta>=0. A zero reflected factor is harmless.

On the full half-band actual reflection follows independently from elementary geometry: r(pi-v) lies in [rv,pi-rv] for 0<=v<=pi/2 and 0<=r<=1. Therefore |cos(r(pi-v))|<=cos(rv), and

    |f(T-s)|<=f(s),  0<=s<=T/2.                       (2.3)

Positive logarithmic-cosine coefficients give the two head bounds

    L_m(s):=cos(ms)^(1/m²) <= f(s),
    f(s)<= exp[-s²/2-q s^4/12-m^6 s^6/45].            (2.4)

For the first inequality, sum |a_i|^(2j)<=m^(2j-2)sum a_i²=m^(2j-2), term by term. For the second, retain the first three terms of -log cos, and use sum |a_i|^6>=m^6. These are valid termwise comparisons inside the open half-band and extend to its boundary.

The stronger complementary lower bound in the cap-defect source also checks: in the flat-minus-actual logarithmic series, every term is nonnegative, and the quartic difference is exactly delta s^4/12. Thus L_m(s)exp(delta s^4/12)<=f(s). It is not needed by the present upper proof.

## 3. Prawitz absolute pairing and the sign of the gain

For x>=0, strict-tail Prawitz and symmetry give the weak upper formula

    P(|X|<=x)<=2 integral_0^1 k_+(u)f(Tu)du,
    k_+(u)=(1-u)cos(Txu)+rho(u)sin(Txu),
    rho(u)=(1-u)cot(pi u)+1/pi.

The identity behind the weak event is P(|X|<=x)=1-2P(X<-x), also at x=0. Thus atoms are included, not averaged or discarded.

For u<=1/2, rho>=0 directly. For u>=1/2 set v=1-u; then rho=1/pi-v cot(pi v)>=0 because tan(pi v)>=pi v. Define R(u)=u rho(u). Cotangent antisymmetry gives the exact identity

    R(u)+R(1-u)=1/pi.

With w(u)=(1-u)+TxR(u), we have

    |k_+(u)|<=w(u),
    w(u)+w(1-u)=1+x/m,
    w(1-u)>=u.

The first inequality uses |cos|<=1 and |sin(Txu)|<=Txu. All these weights are nonnegative. The limiting values at u=0,1 are finite after the stated products; there is no divergent boundary contribution.

Take absolute values before pairing. Equations (2.2)–(2.3) yield

    P(|X|<=x)
      <=2 integral_0^(1/2) [w(u)f(Tu)+w(1-u)|f(T(1-u))|]du
      <=2(1+x/m) integral_0^(1/2) f(Tu)du
         -2 integral_0^(1/4) u f(Tu)
                       [1-exp(-pi delta Tu/(2m³))]du.

The subtraction is essential. To bound this expression above, use an upper envelope for f in the positive term and the lower envelope L_m in the subtracted term. Changing variable s=Tu gives

    P(|X|<=x) <= (1+x/m)A(m,delta)-G(m,delta),
    G=(2m²/pi²)J,
    J=integral_0^(pi/(4m)) s L_m(s)
                         [1-exp(-pi delta s/(2m³))]ds.       (3.1)

The factor 2m²/pi² is correct: it is 2/T². No factor T, pi, or two is lost.

For small m, A=A6 obtained from the upper envelope in (2.4):

    A6=(2m/pi) integral_0^(pi/(2m))
       exp[-s²/2-(m²-delta)s^4/12-m^6s^6/45]ds.

For the middle range keep one actual largest factor exact and bound the remaining factors quadratically and quartically:

    A=A_sharp=(2m/pi) integral_0^(pi/(2m)) cos(ms)
       exp[-(1-m²)s²/2-(m²-m^4-delta)s^4/12]ds.             (3.2)

The remaining second and fourth moments are exactly 1-m² and q-m^4. They are nonnegative throughout the physical delta interval. Both head envelopes are dimension-independent.

For 0<=x<=m, concavity of H on [0,infinity) gives H(x)>=(x/m)H(m). Therefore it suffices that

    A(m,delta)-G(m,delta)/2 <= H(m).                        (3.3)

Indeed A<=H+G/2 implies (1+x/m)A-G <=(1+x/m)H, because 1+x/m<=2 and G>=0.

For fixed m, A is an integral of nonnegative exponentials affine in delta, with a nonnegative cosine factor in (3.2). It is convex. The negative gain is a positive-weight integral of exp(-a delta)-1, also convex. Thus the left side of (3.3) is convex in delta. Its maximum on the closed interval [0,m²-m^4] is at an endpoint, in the sense of the chord inequality. No claim that a scalar endpoint is realized by an actual vector is required. This is a valid sufficient-bound reduction, including delta=0 and the endpoint x=m.

## 4. Small m, maximal defect

Let 0<m<=1/2 and delta=m²-m^4, so the scalar quartic coefficient is q=m^4. Drop the nonnegative sixth term, apply exp(-z)<=1-z+z²/2, and extend the positive polynomial times the Gaussian to infinity. The exact even Gaussian moments give

    A6<=cm[1-m^4/4+35m^8/96].

Since H(m)>=cm(1-m²/6),

    (A6-H(m))/m² <= c g(m),
    g(m)=m/6-m³/4+35m^7/96.

For r=m² in [0,1/4], g'=1/6-3r/4+245r³/96 has degree-three Bernstein coefficients

    1/6, 5/48, 1/24, 39/2048.

Their positivity proves g'>0 on the entire interval. This is an exact basis identity, not four sampled values. At the endpoint g(1/2)=225/4096, and c<4/5 gives c g(m)<45/1024.

At maximal defect, the damping parameter is lambda(m)=pi(1-m²)/(2m), decreasing in m. For fixed s on the common domain, L_m(s)=exp[-s² F(ms)/(ms)²] also decreases with m because F(u)/u² increases. The integration endpoint pi/(4m) decreases. All factors are nonnegative, so J(m) decreases and J(m)>=J(1/2).

At m=1/2, expand cos^4(s/2)=(3+4cos s+cos 2s)/8. Direct integration gives

    integral_0^(pi/2) s cos^4(s/2)ds
      =3pi²/64+pi/4-9/16.

Bound the damped part above by integral_0^infinity s exp(-3pi s/4)ds=16/(9pi²). The resulting lower bound for J(1/2) is increasing in pi. At pi=157/50, its excess over 1/2 is exactly

    154736027/35494560000 >0.

Consequently G/2=m²J/pi²>m²/(2pi²). Using pi<22/7,

    1/(2pi²)-45/1024 >49/968-45/1024
                           =827/123904>0.

This proves (3.3) at the maximal-defect endpoint for every 0<m<=1/2.

## 5. Small m, zero defect

Set r=m², y=m²s^4/12, z=m^6s^6/45. On 0<=s<=2 and m<=1/2, y+z<=16/45. The exact decomposition and elementary inequalities give

    exp(-y-z)=exp(-y)-exp(-y)(1-exp(-z))
      <=1-y+y²/2-z exp(-(y+z))
      <=1-y+y²/2-(29/45)z.

Here 1-exp(-z)>=z exp(-z) and exp(-(y+z))>=1-y-z>=29/45. Outside [0,2], discard the negative correction and retain the positive Taylor polynomial. The upper integration endpoint pi/(2m) is greater than two, so extending only that positive polynomial to infinity is valid.

For I_j(2)=integral_0^2 s^j exp(-s²/2)ds, integration by parts gives I6(2)=15I0(2)-102exp(-2). Integrating the degree-seven Taylor lower bound exactly yields

    I0(2)>=269294/225225.

The positive exponential series gives e²>E7(2)=155/21>59/8. Therefore

    I6(2)>15(269294/225225)-816/59
           =3636106/885885>4.

The correction in A6 is thus at least 232m^7/(2025pi), giving

    A6(m,0)<=cm[1-r/4+35r²/96]-232m^7/(2025pi).

The Gaussian third-order Taylor lower bound gives

    H(m)>=cm[1-r/6+r²/40-r³/336].

Since pi c<88/35, their difference is strictly larger than

    cmr[1/12-163r/480+d r²],
    d=203/4455-1/336=21251/498960.

The bracket derivative is at most -163/480+d/2=-158813/498960<0 on [0,1/4]. Its endpoint value is exactly 8777/7983360>0. Thus (3.3) also holds at zero defect. Section 3 convexity closes all small-m physical defects.

## 6. Middle range: cosine envelope and capped moments

Let 1/2<=m<=M=27/40, t=m², B=58/25. Define

    g(u)=exp(u²/2)cos u,
    p(u)=1-u^4/12-u^6/45-11u^8/3360.

On [0,pi/2], g is nonnegative and decreasing because tan u>=u. Set h=exp(-u²/2)p-cos u. Independent differentiation gives

    h''+h=exp(-u²/2)u^8(304-33u²)/10080,
    h(0)=h'(0)=0.

The forcing is nonnegative throughout the interval, since 304-33(11/7)²>0. The sine-kernel solution for h is nonnegative because 0<=u-v<=pi/2. Hence g<=p, and in particular p>=0 on this interval. No assumption about the sign of p beyond the interval is used.

Extend g by zero after pi/2. For half-normal Z and Y=min(Z,B), we have mY<=MB=783/500<157/100<pi/2, and

    0<=g_+(mZ)<=p(mY),
    A_sharp(m,t-t²)/(cm)=E[g_+(mZ)].

The cap is indispensable: the polynomial is only used where its nonnegativity has been proved.

For the Mills ratio R(x)=exp(x²/2) integral_x^infinity exp(-s²/2)ds, let

    L=x(x²+5)/(x^4+6x²+3),
    U=(x²+2)/(x³+3x).

Direct rational differentiation gives

    L'-xL+1=24/(x^4+6x²+3)²>0,
    U'-xU+1=-6/[x²(x²+3)²]<0.

Since R'=xR-1, multiply R-L or R-U by exp(-x²/2) and integrate to infinity. The weighted limits vanish. The signs give L<=R<=U, in the claimed direction.

With K=c exp(-B²/2), d_n=(n-1)!!, P2=B, and P_n=B^(n-1)+(n-1)P_(n-2), integration by parts gives exactly

    E[Y^n]=d_n+K[(B^n-d_n)R(B)-P_n].

For n=4,6,8,10,12, independently verified rational arithmetic shows B^n-d_n>0 and both brackets at L(B),U(B) are negative. This dictates the signs of every K replacement.

The bounds 319/400<c<4/5 follow from 157/50<pi<22/7 by squared comparisons. With z=B²/2=1682/625, the positive exponential series gives

    E8(z)>250/17,
    E6(z)+(z^7/7!)/(1-z/8)<1595/108.

The second is a geometric bound on the positive remaining series, not an alternating estimate. Thus 108/1595<exp(-z)<17/250 and

    27/500<K<34/625.

The moment brackets' negativity now gives

    E[Y^n]>=d_n+(34/625)[(B^n-d_n)L(B)-P_n],
    E[Y^n]<=d_n+(27/500)[(B^n-d_n)U(B)-P_n].

Exact substitution establishes all six required inequalities:

    M4>=247/100, M6>=89/10, M8>=37,
    M8<=39, M10<=180, M12<=875.

The directions remain correct even when the bracket used later is negative; no unproved positive moment expression is assumed.

## 7. Middle range, zero defect

Set a=t(1-t)/12>=0. Since Y<=Z, g_+(mZ)<=p(mY), and p(mY)>=0,

    A_sharp(m,0)/(cm)
       =E[g_+(mZ)exp(-aZ^4)]
       <=E[p(mY)exp(-aY^4)].

Also aY^4<=B^4/48<2/3. The fourth Taylor upper polynomial gives

    exp(-y)<=1-y+y²/2-y³/6+y^4/24<=1-(18/25)y

on this range. The second inequality follows because the factor
1-y/2+y²/6-y³/24 decreases and equals 59/81>18/25 at y=2/3. Its derivative is negative, as may be seen by completing the square.

Insert the six capped-moment inequalities into E[p]-(18/25)aE[Y^4p], preserving the signs. Subtract the Gaussian lower bound 1-t/6+t²/40-t³/336. Independent polynomial multiplication yields exactly

    upper(A_sharp/(cm))-lower(H(m)/(cm))
       =-tN(t)/2520000,
    N(t)=433125t^5+171675t^4+191850t³-500t²+208236t-46536.

We verify N(1/4)=9812977/1024>0. On [0,1],

    N'(t)=2165625t^4+686700t³+575550t²-1000t+208236
          >=207236>0.

Thus N>0 on [1/4,729/1600], proving A_sharp(m,0)<H(m) throughout the required interval. This is a single continuous polynomial sign proof.

## 8. Middle range, maximal defect

From the capped cosine envelope, moment lower bounds, and Gaussian Taylor lower bound,

    (pi²/m²)[A_sharp(m,t-t²)-H(m)] <= C P(m),
    C=sqrt(2pi³)<79/10,
    P(m)=m/6-277m³/1200-4909m^5/25200-407m^7/3360.

Every nonconstant term of P' is negative, and P'(1/2)=-259927/3225600<0. Hence P decreases for all m>=1/2. Independently verified P(M)>0 guarantees that replacing C by 79/10 is conservative on the entire interval. Its two required endpoint bounds are

    (79/10)P(1/2)=24180241/64512000<3/8,
    (79/10)P(3/5)=218444243/875000000<1/4.

For the gain J at maximal defect, the same monotonicity argument as in Section 4 proves that J decreases with m on (0,1). On the integration band, positivity of the logarithmic-cosine coefficients gives

    F(u)/u² <= F(pi/4)/(pi/4)²=8log(2)/pi²<4/7.

The last comparison follows from log2<7/10, itself certified by E4(7/10)>2, and pi>157/50. Therefore

    J(m)>= integral_0^(pi/(4m)) s exp(-4s²/7)
                    [1-exp(-pi(1-m²)s/(2m))]ds.

For each of the two rational values m=3/5 and m=27/40, replace its upper endpoint by b=157/(200m), and its damping coefficient by k=157(1-m²)/(100m). Both replacements are lower bounds; the integrand is nonnegative and increases with k.

Let T_n(z)=sum_(i=0)^n(-z)^i/i! and Q_r(w)=sum_(j=1)^r(-1)^(j+1)w^j/j!. On both integration ranges, exact rational checks give 0<=4s²/7<1 and 0<=ks<9/4. Taylor's remainder gives T_n<=exp(-z) for odd n and Q_r<=1-exp(-w) for even r.

The needed lower polynomials are nonnegative: T3>=1-z>=0 on [0,1], T5-T3=z^4(1-z/5)/24>=0, and Q4(w)/w decreases to 125/512>0 at w=9/4. Further,

    Q8-Q4=(w^5/120)(1-w/6)+(w^7/5040)(1-w/8)>=0.

Thus multiplication of the lower bounds is justified. Exact termwise integration, not quadrature, gives

    S_(n,r)(m)=sum_(i=0)^n sum_(j=1)^r
       [(-4/7)^i/i!][(-1)^(j+1)k^j/j!]
                 b^(2i+j+2)/(2i+j+2).

The independent verifier obtains each sum twice, first directly and then by multiplying its polynomials and integrating coefficients. Both calculations agree exactly, and give

    S_(5,8)(3/5)>47/125>3/8,
    S_(3,4)(27/40)>13/50>1/4.

No decimal approximation is used for either comparison. Consequently J(3/5)>3/8 and J(27/40)>1/4. For 1/2<=m<=3/5,

    (pi²/m²)(A_sharp-H)<3/8<J(3/5)<=J(m).

For 3/5<=m<=27/40, the analogous comparison uses 1/4 and J(27/40). This proves A_sharp-(m²/pi²)J<H at maximal defect. Combined with Section 7 and convexity, it proves (3.3) on the full middle interval.

## 9. Large-maximum helper and weak endpoint atoms

The previously accepted large helper has also been checked directly, rather than merely citing its old verdict. Machin's identity pi=16atan(1/5)-4atan(1/239) follows from the tangent formula: tan(4atan(1/5))=120/119 and tan(4atan(1/5)-atan(1/239))=1, with the angle in the first quadrant. Alternating arctangent sums yield

    157/50<pi<355/113<22/7.

Only six terms at 1/5 for the lower bound, five for the upper bound, and one/two terms at 1/239 are needed. All are exact finite fractions. Then phi(0)>19947/50000 because

    1-2(355/113)(19947/50000)²=320561/28250000000>0.

The integrated third-order Gaussian Taylor lower polynomial at M=27/40 gives

    H(M)>2(19947/50000)(M-M³/6+M^5/40-M^7/336)
        =229520461865155173/458752000000000000>1/2.

Write X=m epsilon+Y, where Y is independent and symmetric. For 0<=x<m, conditioning and symmetry give

    P(|X|<=x)=P(-m-x<=Y<=-m+x)<=P(Y<0)<=1/2.

The upper endpoint -m+x is strictly negative. This remains true at atoms and at x=0. Since H(m)>1/2 for m>=27/40, the target follows. At x>=m use P(|X|<=x)<=1<2H(m)<=H(x)+H(m). In particular x=m is handled separately and correctly; the negative-half-line containment is not incorrectly extended to that endpoint.

## 10. Joins, consequences, and limitations

The three ranges are (0,1/2], [1/2,27/40], and [27/40,1]. The central x range is the closed [0,m] in each. The middle proof's split at 3/5 also overlaps. Thus there is no missing endpoint in m, x, or delta. No limit at m=0 is required because a finite normalized coefficient vector has m>0.

At x=0, the original Prawitz upper controls P(X=0) directly. At x=m, the factor 1+x/m is exactly two, so the scalar half-gain condition remains sufficient with equality in that algebraic step. The head and reflection endpoints at s=T/2 are continuous and do not generate atomic probability omissions. The atom issue concerns the probability input, which is explicitly weak, not the integration variable.

Once the independently accepted outer upper inequality for x>=m and the global strict lower inequality are supplied, put U=P(|X|<=x), L=P(|X|<x). For x>0, symmetry gives

    F(x)=(1+U)/2, F(-x)=(1-L)/2.

If H(x)-H(m)<=L<=U<=H(x)+H(m), these identities immediately imply |F(y)-Phi(y)|<=H(m)/2 for positive and negative y. At zero F(0)=1/2+P(X=0)/2 and the central upper just audited gives the same conclusion. This describes the composition; it does not claim that this packet alone proves the two separately supplied inequalities.

The defect delta=m²-q is used internally to sharpen the maximum-coefficient proof. Its appearance does not replace H(m) by H(sqrt(q)) in the final target. In particular the full unrestricted q theorem remains outside this acceptance.

No unresolved blocker remains for the full central weak upper theorem stated at the start.
