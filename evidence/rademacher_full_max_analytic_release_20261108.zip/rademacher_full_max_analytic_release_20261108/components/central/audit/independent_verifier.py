#!/usr/bin/env python3
"""Independent finite rational algebra, not numerical integration or a grid.
No primary checker is imported, read, or executed. Analytic proof is AUDIT.md.
All acceptance comparisons use Fraction. Assertions are explicit exceptions.
"""
from fractions import Fraction as Q
from math import factorial, comb
from pathlib import Path
import json, hashlib
OUT=Path(__file__).resolve().parent
checks=[]
def check(name, truth, **detail):
    if not truth: raise RuntimeError('FAILED '+name+' '+str(detail))
    checks.append({'name':name,'pass':True,**{k:str(v) for k,v in detail.items()}})
def eq(name,a,b): check(name,a==b,value=a,expected=b)
def gt(name,a,b=0): check(name,a>b,value=a,lower_bound=b)
def lt(name,a,b): check(name,a<b,value=a,upper_bound=b)
def trim(a):
    a=list(map(Q,a))
    while len(a)>1 and a[-1]==0:a.pop()
    return a
def add(a,b):return trim([(a[i] if i<len(a) else 0)+(b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))])
def scale(a,k):return trim([x*k for x in a])
def sub(a,b):return add(a,scale(b,-1))
def mul(a,b):
    z=[Q(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): z[i+j]+=x*y
    return trim(z)
def power(a,n):
    z=[Q(1)]
    for _ in range(n):z=mul(z,a)
    return z
def deriv(a):return trim([i*a[i] for i in range(1,len(a))] or [0])
def val(a,x):return sum(c*x**i for i,c in enumerate(a))
def integral(a,b):return sum(c*b**(i+1)/(i+1) for i,c in enumerate(a))
def dfact(n):
    r=1
    for k in range(n,0,-2):r*=k
    return r
def E(x,n):return sum((x**j/Q(factorial(j)) for j in range(n+1)),Q(0))
def arctan_partial(x,n):return sum(((-1)**j*x**(2*j+1)/Q(2*j+1) for j in range(n+1)),Q(0))
# Machin tangent identity and alternating enclosures.
eq('Machin tangent of four atan(1/5) minus atan(1/239)',(Q(120,119)-Q(1,239))/(1+Q(120,119)*Q(1,239)),Q(1))
pi_lo=16*arctan_partial(Q(1,5),5)-4*arctan_partial(Q(1,239),0)
pi_hi=16*arctan_partial(Q(1,5),4)-4*arctan_partial(Q(1,239),1)
gt('Machin lower exceeds 157/50',pi_lo,Q(157,50))
lt('Machin upper below 355/113',pi_hi,Q(355,113))
lt('355/113 below 22/7',Q(355,113),Q(22,7))
gt('c lower 319/400 by squared comparison',2/Q(22,7),Q(319,400)**2)
lt('c upper 4/5 by squared comparison',2/Q(157,50),Q(4,5)**2)
# Small-m maximal-defect endpoint.
gprime=[Q(1,6),Q(-3,4),Q(0),Q(245,96)]
betas=[sum(gprime[j]*Q(1,4)**j*Q(comb(k,j),comb(3,j)) for j in range(k+1)) for k in range(4)]
eq('small derivative Bernstein coefficients',betas,[Q(1,6),Q(5,48),Q(1,24),Q(39,2048)])
check('small derivative Bernstein positivity',all(b>0 for b in betas))
g=[0,Q(1,6),0,Q(-1,4),0,0,0,Q(35,96)]
eq('g(1/2)',val(g,Q(1,2)),Q(225,4096))
eq('c-upper times g(1/2)',Q(4,5)*val(g,Q(1,2)),Q(45,1024))
p=Q(157,50)
Jlower=3*p*p/64+p/4-Q(9,16)-16/(9*p*p)
eq('J(1/2) rational margin',Jlower-Q(1,2),Q(154736027,35494560000))
gt('J(1/2)>1/2 rational margin',Jlower,Q(1,2))
eq('small maximal-defect final margin',Q(49,968)-Q(45,1024),Q(827,123904))
gt('small maximal-defect positive margin',Q(827,123904))
# Gaussian moments are exact recurrence, normalized by sqrt(pi/2).
eq('quartic first Gaussian moment coefficient',Q(dfact(3),12),Q(1,4))
eq('quartic second Gaussian moment coefficient',Q(dfact(7),288),Q(35,96))
# Small-m zero-defect endpoint.
eq('small y+z maximum',Q(1,4)*2**4/12+Q(1,64)*2**6/45,Q(16,45))
T7=[Q(0)]*15
for j in range(8):T7[2*j]=Q((-1)**j,2**j*factorial(j))
eq('integrated seventh Gaussian Taylor polynomial',integral(T7,Q(2)),Q(269294,225225))
eq('E7(2)',E(Q(2),7),Q(155,21))
gt('E7(2)>59/8',E(Q(2),7),Q(59,8))
I6=15*Q(269294,225225)-Q(816,59)
eq('sixth truncated moment rational bound',I6,Q(3636106,885885))
gt('sixth truncated moment exceeds four',I6,Q(4))
eq('sixth correction coefficient',Q(2)*Q(29,45)*Q(1,45)*4,Q(232,2025))
d=Q(232,2025)/Q(88,35)-Q(1,336)
eq('small zero-defect d',d,Q(21251,498960))
eq('small zero-defect derivative upper',Q(-163,480)+d/2,Q(-158813,498960))
eq('small zero-defect endpoint bracket',Q(1,12)-Q(163,1920)+d/16,Q(8777,7983360))
gt('small zero-defect endpoint positive',Q(8777,7983360))
# Middle range cosine polynomial ODE, independently differentiated.
p=[1,0,0,0,Q(-1,12),0,Q(-1,45),0,Q(-11,3360)]
res=add(sub(deriv(deriv(p)),scale(mul([0,1],deriv(p)),2)),mul([0,0,1],p))
expected=[0]*8+[Q(304,10080),0,Q(-33,10080)]
eq('cosine envelope ODE polynomial',res,trim(expected))
gt('cosine envelope ODE sign at pi upper',304-33*(Q(22,7)/2)**2)
B=Q(58,25); M=Q(27,40)
eq('M B',M*B,Q(783,500))
lt('M B below pi lower half',M*B,Q(157,100))
# Mills rational differential residuals, cross multiplied.
for name,N,D,target in [('L',[0,5,0,1],[3,0,6,0,1],24),('U',[2,0,1],[0,3,0,1],-6)]:
    residual=add(sub(sub(mul(deriv(N),D),mul(N,deriv(D))),mul([0,1],mul(N,D))),mul(D,D))
    eq('Mills '+name+' residual numerator',residual,[Q(target)])
L=B*(B*B+5)/(B**4+6*B*B+3); U=(B*B+2)/(B**3+3*B)
lt('Mills rational order at B',L,U)
x=B*B/2
eq('B squared half',x,Q(1682,625))
gt('E8 exponential lower',E(x,8),Q(250,17))
lt('exponential geometric upper',E(x,6)+x**7/Q(factorial(7))/(1-x/8),Q(1595,108))
eq('K lower product',Q(319,400)*Q(108,1595),Q(27,500))
eq('K upper product',Q(4,5)*Q(17,250),Q(34,625))
Pmom={2:B}
for n in range(4,13,2):Pmom[n]=B**(n-1)+(n-1)*Pmom[n-2]
lower_targets={4:Q(247,100),6:Q(89,10),8:Q(37)}
upper_targets={8:Q(39),10:Q(180),12:Q(875)}
for n in [4,6,8,10,12]:
    dn=Q(dfact(n-1)); coeff=B**n-dn
    gt('moment '+str(n)+' Mills coefficient positive',coeff)
    bracket_lo=coeff*L-Pmom[n]; bracket_hi=coeff*U-Pmom[n]
    lt('moment '+str(n)+' bracket L negative',bracket_lo,0)
    lt('moment '+str(n)+' bracket U negative',bracket_hi,0)
    if n in lower_targets:gt('moment '+str(n)+' lower bound',dn+Q(34,625)*bracket_lo,lower_targets[n])
    if n in upper_targets:lt('moment '+str(n)+' upper bound',dn+Q(27,500)*bracket_hi,upper_targets[n])
# Middle zero-defect scalar polynomial.
lt('aY4 upper below 2/3',B**4/48,Q(2,3))
q4=[1,Q(-1,2),Q(1,6),Q(-1,24)]
eq('linear exponential bracket at 2/3',val(q4,Q(2,3)),Q(59,81))
gt('linear exponential bracket >18/25',Q(59,81),Q(18,25))
head=[1,0,Q(-247,1200),Q(-89,450),Q(-407,3360)]
inside=[Q(247,100),0,Q(-39,12),Q(-180,45),Q(-11*875,3360)]
upper=sub(head,scale(mul([0,Q(1,12),Q(-1,12)],inside),Q(18,25)))
hlower=[1,Q(-1,6),Q(1,40),Q(-1,336)]
D=sub(upper,hlower)
N=[-46536,208236,-500,191850,171675,433125]
eq('middle zero-defect D polynomial identity',D,scale([0]+N,Q(-1,2520000)))
eq('N(1/4)',val(N,Q(1,4)),Q(9812977,1024))
gt('N(1/4) positive',val(N,Q(1,4)))
eq('N derivative',deriv(N),[Q(208236),Q(-1000),Q(575550),Q(686700),Q(2165625)])
gt('N derivative lower on [0,1]',Q(208236)-1000)
# Middle maximal-defect head polynomial.
P=[0,Q(1,6),0,Q(-277,1200),0,Q(-4909,25200),0,Q(-407,3360)]
headminusH=sub(head,hlower)
eq('head-gap P via t=m squared',trim([headminusH[(i+1)//2] if i%2 else 0 for i in range(8)]),trim(P))
eq('P derivative at half',val(deriv(P),Q(1,2)),Q(-259927,3225600))
gt('P(M) positive',val(P,M))
lt('C squared below (79/10)^2',2*Q(22,7)**3,Q(79,10)**2)
eq('P half upper',Q(79,10)*val(P,Q(1,2)),Q(24180241,64512000))
lt('P half upper below 3/8',Q(79,10)*val(P,Q(1,2)),Q(3,8))
eq('P three-fifths upper',Q(79,10)*val(P,Q(3,5)),Q(218444243,875000000))
lt('P three-fifths upper below 1/4',Q(79,10)*val(P,Q(3,5)),Q(1,4))
# Gain Gaussian envelope and two exactly integrated lower polynomials.
gt('log 2 below 7/10 via E4',E(Q(7,10),4),2)
lt('8 log2 over pi squared below 4/7 via rationals',8*Q(7,10)/Q(157,50)**2,Q(4,7))
eq('Q4/w at 9/4',val(q4,Q(9,4)),Q(125,512))
# Derivative q4 is negative: 1/3*w-1/8*w² <=2/9, so <=-5/18.
eq('maximum upper for q4 derivative',Q(-1,2)+Q(2,9),Q(-5,18))
for m,n,r,target,comparison in [(Q(3,5),5,8,Q(47,125),Q(3,8)),(M,3,4,Q(13,50),Q(1,4))]:
    b=Q(157,200)/m; k=Q(157,100)*(1-m*m)/m
    lt('gain z cap at '+str(m),Q(4,7)*b*b,1)
    lt('gain w cap at '+str(m),k*b,Q(9,4))
    total=sum((Q(-4,7)**i/Q(factorial(i))*Q((-1)**(j+1),factorial(j))*k**j*b**(2*i+j+2)/Q(2*i+j+2) for i in range(n+1) for j in range(1,r+1)),Q(0))
    # Reconstruct by polynomial convolution and integrate independently as a second identity.
    T=[Q(0)]*(2*n+1)
    for i in range(n+1):T[2*i]=Q(-4,7)**i/Q(factorial(i))
    Qr=[Q(0)]+[Q((-1)**(j+1),factorial(j))*k**j for j in range(1,r+1)]
    eq('gain sum equals polynomial integral at '+str(m),total,integral(mul([0,1],mul(T,Qr)),b))
    gt('gain rational target at '+str(m),total,target)
    gt('gain target comparison at '+str(m),target,comparison)
# Large-m elementary upper helper, independently rederived.
phi0=Q(19947,50000)
gt('phi0 rational lower by squared comparison',1-2*Q(355,113)*phi0**2)
Hlarge=2*phi0*(M-M**3/6+M**5/40-M**7/336)
eq('H(27/40) elementary lower',Hlarge,Q(229520461865155173,458752000000000000))
gt('H(27/40) lower exceeds half',Hlarge,Q(1,2))
# Recheck frozen/source bytes, without executing any source checker.
for item in json.loads((OUT/'FROZEN_INPUTS.json').read_text()):
    digest=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
    eq('frozen hash '+item['frozen'],digest(OUT/item['frozen']),item['sha256'])
    eq('original hash '+item['frozen'],digest(item['source']),item['sha256'])
result={'status':'PASS','check_count':len(checks),'method':'Exact fractions and finite polynomial identities only. No primary checker execution, grid, quadrature, or floating acceptance comparison.','checks':checks}
(OUT/'INDEPENDENT_EXACT_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS:',len(checks),'independent exact checks')
