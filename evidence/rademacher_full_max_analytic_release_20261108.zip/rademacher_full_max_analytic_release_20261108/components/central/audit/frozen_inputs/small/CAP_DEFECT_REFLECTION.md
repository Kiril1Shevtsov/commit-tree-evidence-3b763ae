# Sharp cap-defect reflection for Rademacher products

Date: 8 November 2026. Status: primary analytical proof, self-checked; an independent audit is still required. This is an ingredient for the remaining upper side, not a full Kolmogorov theorem.

Let X = sum a_i epsilon_i, sum a_i^2 = 1, m = max |a_i| > 0, q = sum a_i^4, delta = m^2 - q >= 0, T = pi/m, and f(t) = product cos(a_i t). Coefficient signs can be absorbed.

## 1. A sharp one-factor inequality

Put F(z) = -log |cos z|, interpreted as positive infinity at zeros. For 0 <= v <= pi/4 and 0 <= r <= 1,

    F((pi-v)r) - F(vr)
        >= (pi tan(v)/2) r^2 (1-r^2).                 (1)

For every fixed v>0 the coefficient pi tan(v)/2 is optimal uniformly over r: the ratio of the left side to r^2(1-r^2) tends to precisely this coefficient as r tends to one from below.

Proof. First suppose (pi-v)r < pi/2. The positive power series for -log cos gives

    F((pi-v)r)-F(vr) >= pi(pi-2v) r^2/2.

Since pi-2v >= pi/2 > 1 >= tan(v), this implies (1). If (pi-v)r = pi/2 the assertion is immediate.

In the remaining range set z = pi-(pi-v)r. Then vr <= z < pi/2, z-vr = pi(1-r), and F((pi-v)r)=F(z). Convexity of F on [0,pi/2) gives

    F(z)-F(vr) >= pi(1-r) tan(vr).

The function tan(t)/t^2 is decreasing on (0,pi/4]. Indeed its derivative has the sign of t-sin(2t), and concavity of sine gives sin(2t) >= 4t/pi > t on this interval. Consequently tan(vr) >= r^2 tan(v). Thus

    F(z)-F(vr) >= pi r^2(1-r) tan(v)
               >= (pi tan(v)/2) r^2(1-r^2).

The cases r=0, r=1 or v=0 follow directly or by continuity. For sharpness, the derivative with respect to r of the left side at r=1 is -pi tan(v), whereas the derivative of r^2(1-r^2) is -2. This proves the stated limit.

## 2. A profile-aware reflected bound

For 0 <= s <= pi/(4m), apply (1) with v=ms and r_i=|a_i|/m. Since

    sum r_i^2(1-r_i^2) = delta/m^4,

we obtain

    |f(T-s)| <= f(s) exp[-pi tan(ms) delta/(2m^4)]
              <= f(s) exp[-pi delta s/(2m^3)].          (2)

Here f(s)>0 throughout the interval. If a reflected cosine is zero, the inequality remains valid directly. The first exponent is the stronger assertion. The equality delta=0 forces all nonzero coefficient magnitudes to equal m, so the bound recovers exact flat reflection.

## 3. Complementary head bounds

For 0 <= s < pi/(2m), the same positive logarithmic-cosine series yields

    cos(ms)^(1/m^2) exp(delta s^4/12) <= f(s)
        <= exp(-s^2/2 - q s^4/12).                    (3)

For the lower estimate, in every coefficient of order 2j the difference between the flat cap profile and the actual profile is nonnegative:

    m^(2j-2) - sum |a_i|^(2j) >= 0.

At j=2 this difference is delta and the logarithmic-cosine coefficient is 1/12. The upper estimate follows by retaining the quadratic and quartic terms of the series. All claims are continuous in the actual coefficients and independent of dimension.

## 4. Direct CDF use and the remaining obligation

The accepted strict lower Prawitz kernel at x=m simplifies exactly to

    k_-(u) = -sin(pi u)/pi.

Using actual reflection |f(T-s)|<=f(s) on the whole half interval, and (2) on the shorter interval, therefore gives the explicit nonnegative mass estimate

    P(|X|<m) >= (2m/pi^2) integral_0^(pi/(4m))
       sin(ms) f(s)
       [1-exp(-pi tan(ms) delta/(2m^4))] ds.           (4)

In particular it gives an actual CDF gain away from flat profiles. For the upper side, the reflected-end contribution can be suppressed by (2) while the head retains its actual quartic term q in (3); this addresses the loss incurred by replacing both ends with independent Gaussian envelopes.

Formula (4) has not been shown to reach H(m)-H(sqrt(q)) uniformly. More precisely, along profiles with m tending to zero and 0<delta=o(m^3), its right side is asymptotic to phi(0) delta/m, as is H(m)-H(sqrt(q)). To justify this observation, use f(s) tending pointwise to exp(-s^2/2), divide the integrand by delta/m, and dominate it by a constant times s^2 exp(-s^2/2); on the integration interval tan(ms)/(ms) <= 4/pi. This leading-coefficient agreement is not a proof of the finite-parameter inequality. Nor do (1)-(4) establish the remaining upper-middle region or the unrestricted q conjecture. Those are the intended uses to be tested next.

Dependencies: the positive logarithmic-cosine series and the Prawitz strict-lower inequality used in the accepted max reflection release, /workspace/shared/rademacher_max_reflection_bridge_release_20261108. The one-factor inequality and the quantitative exponent above are new primary work in this file.
