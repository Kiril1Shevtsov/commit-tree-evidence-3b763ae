# Central weak upper bound for every maximum m <= 1/2

Date: 8 November 2026. Status: primary analytic candidate, awaiting independent audit. This is a continuous-parameter component of the full max theorem, not a full q theorem.

Let X=sum a_i epsilon_i, sum a_i^2=1, m=max |a_i|, q=sum a_i^4, delta=m^2-q, H=2Phi-1, and c=sqrt(2/pi). This note proves the candidate statement

    P(|X|<=x) <= H(x)+H(m),   0<m<=1/2, 0<=x<=m.        (T)

The proof supplies a general convex endpoint reduction that remains useful at larger m. The event is weak, including atoms. No coefficient grid or numerical quadrature is used.

## 1. The exact endpoint reduction

Write T=pi/m, f(s)=product cos(a_i s), and

    rho(u)=(1-u)cot(pi u)+1/pi,
    R(u)=u rho(u).

The accepted weak upper Prawitz inequality reads

    P(|X|<=x)<=2 integral_0^1
       [(1-u)cos(Txu)+rho(u)sin(Txu)] f(Tu) du.

We use rho>=0, R(u)+R(1-u)=1/pi, and the accepted actual reflection |f(T-s)|<=f(s) on 0<=s<=T/2. The stronger primary cap-defect lemma, proved in the frozen input, gives

    |f(T-s)| <= f(s) exp[-pi delta s/(2m^3)],
                                  0<=s<=T/4.          (1)

It follows from the sharper one-factor inequality
F((pi-v)r)-F(vr)>=(pi tan(v)/2)r^2(1-r^2),
where F=-log|cos|, 0<=r<=1 and 0<=v<=pi/4. Its complete elementary proof is frozen as CAP_DEFECT_REFLECTION.md and must be included in the independent audit.

The logarithmic-cosine series, together with sum a_i^6>=m^6, gives on 0<=s<T/2

    cos(ms)^(1/m^2) <= f(s)
      <= exp[-s^2/2 - q s^4/12 - m^6 s^6/45].          (2)

The lower estimate is the usual cap comparison. For the upper estimate retain the first three positive terms of -log cos and one actual largest coefficient in the sixth mass. The endpoint follows by continuity.

For x>=0, dominate the absolute kernel by

    w(u)=(1-u)+Tx R(u).

Then w(u)+w(1-u)=1+x/m and w(1-u)>=u. Pair the two ends, use (1) on the first quarter and ordinary actual reflection elsewhere, and use both directions of (2) on terms with the corresponding signs. This gives

    P(|X|<=x) <= (1+x/m) A6(m,delta)-G(m,delta),       (3)

where

    A6=(2m/pi) integral_0^(pi/(2m))
        exp[-s^2/2-(m^2-delta)s^4/12-m^6s^6/45] ds,

    G=(2m^2/pi^2) J,

    J=integral_0^(pi/(4m)) s cos(ms)^(1/m^2)
             [1-exp(-pi delta s/(2m^3))] ds.

For 0<=x<=m, concavity of H gives H(x)+H(m)>=(1+x/m)H(m). Thus (T) follows if

    A6(m,delta)-G(m,delta)/2 <= H(m).                  (4)

Indeed the factor 1+x/m is at most two and G>=0.

Crucially, the left side of (4) is convex in delta. Its first term is an integral of exponentials affine in delta; the negative gain has the form a positive integral of exp(-constant*delta)-1. Since

    0<=delta<=m^2-m^4,

it suffices to prove (4) at the two endpoints. This is an upper-bound reduction, not an assertion that the endpoint profiles themselves are feasible at every m.

## 2. Endpoint delta=m^2-m^4, all 0<m<=1/2

Here q=m^4. Drop the nonnegative sixth-order term in A6 and extend the resulting quadratic Taylor upper bound to infinity. Gaussian moment integration gives

    A6 <= c m [1-m^4/4+35m^8/96].                     (5)

This uses exp(-z)<=1-z+z^2/2 and the positivity of that polynomial. Also H(m)>=c m(1-m^2/6), so

    (A6-H(m))/m^2 <= c g(m),
    g(m)=m/6-m^3/4+35m^7/96.                         (6)

The function g is increasing on [0,1/2]. To see this, put r=m^2 and observe that

    g'(m)=1/6-3r/4+245r^3/96.

Its Bernstein coefficients of degree three on 0<=r<=1/4 are exactly

    (1/6, 5/48, 1/24, 39/2048),

all positive. Therefore, using c<4/5,

    c g(m) <= c g(1/2) < (4/5)(225/4096)=45/1024.     (7)

On this endpoint the gain parameter is lambda(m)=pi(1-m^2)/(2m), which decreases with m. Moreover cos(ms)^(1/m^2) decreases with m wherever defined: -log cos(v)/v^2 has positive power-series coefficients and is increasing. The integration interval also decreases. Consequently J(m,m^2-m^4) decreases with m and is bounded below by its value at m=1/2.

At m=1/2, using cos^4(s/2)=(3+4cos s+cos(2s))/8 and bounding the exponentially damped part by integral_0^infinity s exp(-3pi s/4) ds gives

    J(1/2,3/16)
      >= 3pi^2/64+pi/4-9/16-16/(9pi^2)>1/2.          (8)

The final expression is increasing in pi. At pi=157/50 its excess over 1/2 is exactly

    154736027/35494560000>0.

Thus G/2=m^2 J/pi^2>m^2/(2pi^2). Since pi<22/7,

    1/(2pi^2)-45/1024
      >49/968-45/1024=827/123904>0.                   (9)

Equations (6)-(9) prove (4) at this endpoint for the entire interval 0<m<=1/2.

## 3. Endpoint delta=0, all 0<m<=1/2

Now G=0. Write r=m^2, y=m^2 s^4/12 and z=m^6 s^6/45. For 0<=s<=2 and m<=1/2,

    y+z <= 1/3+1/45=16/45.

The exact identity exp(-y-z)=exp(-y)-exp(-y)[1-exp(-z)], together with 1-exp(-z)>=z exp(-z), yields

    exp(-y-z) <= 1-y+y^2/2-(29/45)z,    0<=s<=2.     (10)

Outside this interval use only exp(-y-z)<=1-y+y^2/2. Since the half-band endpoint pi/(2m) is greater than two, extend the positive Taylor polynomial to infinity and subtract the explicit correction on [0,2]. We claim

    I6(2):=integral_0^2 s^6 exp(-s^2/2) ds>4.          (11)

Indeed integration by parts gives I6(2)=15 I0(2)-102exp(-2). The degree-seven Taylor lower polynomial for exp(-s^2/2), integrated over [0,2], gives

    I0(2)>=269294/225225.

Also the exponential series through degree seven gives e^2>155/21>59/8. Hence

    I6(2)>15(269294/225225)-816/59
          =3636106/885885>4.

Combining (10)-(11) with the full Gaussian moments gives

    A6(m,0) <= c m[1-r/4+35r^2/96]
                    -232m^7/(2025pi).                (12)

The degree-three Taylor lower bound in the Gaussian integral gives

    H(m)>=c m[1-r/6+r^2/40-r^3/336].                 (13)

Use pi*c < (22/7)(4/5)=88/35. Then (12)-(13) imply

    H(m)-A6(m,0)
      > c m r [1/12-163r/480+d r^2],
    d=203/4455-1/336=21251/498960.                    (14)

The bracket decreases on [0,1/4]: its derivative is at most

    -163/480+d/2=-158813/498960<0.

Its endpoint value is

    1/12-163/1920+d/16=8777/7983360>0.                (15)

Thus (4) holds strictly at delta=0 as well. Convexity in Section 1 proves (T) for every actual q and every 0<m<=1/2.

## 4. Scope and remaining work

The proof is analytic and continuous in m and delta. The one displayed Bernstein identity has four positive coefficients and is an algebraic identity, not a parameter grid. All elementary rational comparisons are reproduced in check_constants.py for error checking.

The result is only the central weak upper region x<=m with m<=1/2. A separate outer-upper argument and a remaining large-m central argument are being checked. The full lower-central theorem has already been independently accepted. No full analytic max theorem or unrestricted q theorem is asserted by this primary note.
