# Exact reflection pairing for the max-coefficient CDF functional

Date: 2026-11-08. Status: primary analytic derivation, not independently audited. No complete CDF theorem is claimed.

Let X=sum a_i epsilon_i, sum a_i^2=1, 0<m=max |a_i|<=1, T=pi/m, p=1/m^2, and f(t)=product cos(a_i t). Write phi for the standard normal density and H=2Phi-1.

## 1. A relation between actual frequencies, not separate envelopes

For every 0<=t<=T/2,

    |f(T-t)| <= f(t).                                      (1)

Indeed set v=mt in [0,pi/2] and r=|a_i|/m in [0,1]. The angle r(pi-v) lies in [rv,pi-rv]. Since rv belongs to [0,pi/2], this implies

    |cos(r(pi-v))| <= cos(rv).

Multiplication proves (1). The right side is nonnegative. If t<T/2 and some nonzero |a_i|<m, its factor inequality is strict; the other factors may still vanish at the endpoint t=T/2, where no strictness is claimed. For t<T/2 the low-frequency product is positive, so the product inequality is strictly improved whenever the vector is nonflat.

The inequality also holds for a nonattained upper bound m, although the pinned upper envelope below then needs to be replaced by the ordinary Gaussian upper envelope. This does not transfer to the q scale h=sqrt(sum a_i^4), because in general some |a_i|>h.

## 2. The exact old signed Prawitz functional

Define, for 0<u<1,

    rho(u)=(1-u)cot(pi u)+1/pi,
    k_xi(u)=(1-u)cos(pi xi u)-rho(u)sin(pi xi u).

The endpoints have removable limits. The Prawitz input used by the existing audited max proof states

    P(|X|<x) >= -2 J(x),
    J(x)=integral_0^1 k_{x/m}(u) f(Tu) du.                 (2)

For the weak upper-central event, replace x by -x in J and reverse the displayed sign: P(|X|<=x)<=2J(-x). These conventions retain atoms.

The formula, sign and normalization were directly checked against

    /workspace/shared/keller_klein_full_release_20261107/
      audit_upper_B_full_20261107/SIGNED_B_SOURCE_AUDIT.md

and the full upper/lower composition files. No old numerical witnesses were rerun.

Pair u with 1-u in (2), and apply (1). It follows that

    J(x) <= integral_0^{1/2} c_xi(u) f(Tu) du,
    c_xi(u)=k_xi(u)+|k_xi(1-u)|, xi=x/m.                 (3)

This keeps the common-frequency relation. It is stronger than replacing f independently by an absolute envelope on the two halves.

On the first half-band,

    L_m(u)=cos(pi u)^p <= f(Tu)
        <= U_m(u)=cos(pi u) exp[-(p-1)pi^2 u^2/2].       (4)

The lower bound follows from the decrease of log(cos z)/z^2 on [0,pi/2). For the upper bound, factor out one attained largest coefficient and bound each remaining cosine by its Gaussian bound. Endpoints follow by continuity.

Thus the completely explicit, dimension-independent quantity

    J_pair(m,xi)
      = integral_0^{1/2} c_xi(u)
          [U_m(u) if c_xi(u)>=0; L_m(u) if c_xi(u)<0] du (5)

satisfies J(x)<=J_pair(m,xi). A sufficient lower-CDF inequality is

    [H(m)-H(m xi)]/2 - J_pair(m,xi) >= 0.               (6)

No numerical evaluation of (5) is used to assert (6) here.

## 3. Exact flat-gap cancellation and a real near-boundary deficit

At xi=1,

    k_1(u)=k_1(1-u)=-sin(pi u)/pi,
    c_1(u)=0,
    J_pair(m,1)=0.

Thus the pairing removes the exponentially small absolute-envelope loss at the critical first-gap threshold exactly.

However, this cancellation alone does not prove (6) immediately to the right of xi=1. For fixed 0<u<1/2, k_xi(1-u)<0 near xi=1. Direct differentiation gives

    (partial_xi c_xi)(u)|_{xi=1} = -cos(pi u).

The derivatives are bounded uniformly on the compact u interval after taking the removable endpoint limits. Since c_1=0, dominated convergence in (5) gives

    partial_xi J_pair(m,xi)|_{1+}
      = - integral_0^{1/2} cos(pi u)^{p+1} du.

Consequently the right derivative of the left side of (6) is

    -m phi(m) + integral_0^{1/2} cos(pi u)^{p+1} du.     (7)

At m=1/sqrt(2), p=2, this is

    -exp(-1/4)/(2 sqrt(pi)) + 2/(3pi) < 0.

For the strict sign it suffices to square the positive quantities: it is equivalent to 16 exp(1/2)<9pi. The elementary bounds exp(1/2)<5/3 and pi>3 give 16 exp(1/2)<80/3<27<9pi. (The exponential bound follows at once from its power series with a geometric tail.)

Therefore (6) is genuinely FALSE for all sufficiently small xi>1 at m=1/sqrt(2). This is a counterexample to the sufficient paired-envelope functional, not to the Rademacher theorem. The optimization in (5) permits the odd reflected sign profile even when p=2; it has discarded additional parity/product information. A strict-lower comparison bridge or a stronger relation is still necessary.

## 4. Limited numerical viability check, not a certificate

The accompanying exploratory scipy quadrature sampled

    m=.15,.2,.25,1/sqrt(10),.4,.5,.6,.7,.8,.9,1

and xi=1,1.01,1.1,1.25,1.5,1.75,2,2.5,3,4,5. All sampled values at xi>=1.1 were positive. Some xi=1.01 values were negative, consistently with (7); xi=1 vanishes analytically. These samples do not prove a full interval or any coefficient sector. They only suggest testing an analytic comparison bridge near xi=1 and an analytic estimate of (5) farther away.

The old half-weight comparison gives P(|X|<x)>=P(|X|<2b)/3 for suitable b>=m, b<x, preserving the strict endpoint conventions. Combining it with (5) is a possible route, not an established closure.

The upper-central side remains separate. In particular, using only the pointwise U_m in (4) at x=0 loses the needed cubic Gaussian correction in the small-m regime; the previously accepted central-profile/Hölder argument uses more structure. No full computer-free proof has been obtained from the present functional.
