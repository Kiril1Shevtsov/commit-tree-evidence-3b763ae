# Retained analytic inputs and endpoint conventions

Let X=sum a_i epsilon_i be a finite independent unbiased-sign sum with sum a_i^2=1 and max|a_i|<=m. Define f(t)=E exp(itX), real by symmetry, and H(t)=2Phi(t)-1.

## Prawitz strict-tail smoothing

For any T>0 and real z, set

    rho(u)=(1-u)cot(pi u)+1/pi,
    k(u;z,T)=(1-u)cos(Tzu)-rho(u)sin(Tzu),
    J(z;T)=integral_0^1 k(u;z,T) f(Tu) du.

Endpoint singularities are removable after multiplication. The input is

    P(X<z)>=1/2-J(z;T).

For x>0, symmetry then gives

    P(|X|<x)>=-2J(x;T),
    P(|X|<=x)<=2J(-x;T).

The weak upper identity also holds at x=0. The lower inequality at x=0 is not needed: its target is automatic. Strict and weak endpoints must not be interchanged at atoms. The source is Keller and Klein, Proof of Tomaszewski's Conjecture on Randomly Signed Sums, Theorem 4.5, equations (39)-(40):

https://arxiv.org/html/2006.16834v4#S4.SS1.SSS1

The frozen normalization/source review is provenance/PRAWITZ_SOURCE_AUDIT.md. Its numerical pilot is outside this packet's proof dependencies.

## Half-weight interval comparison

For l<r let

    W(l,r)=P(l<X<r)+(P(X=l)+P(X=r))/2.

The retained special consequence of Keller-Klein Lemma 3.7 is

    W(m,2m)<=W(-m,m),
    W(-2m,2m)<=3W(-m,m).

The second line follows by symmetry and half-weight additivity. The lemma's hypotheses for its general comparison W(C,D)<=W(A,B) include |A|<=C and 2 max(m,D-B)<=C-A. At (A,B,C,D)=(-m,m,m,2m), both hold at equality. The interval-comparison input is analytic; the later computer-assisted parameter cells in the original proof are not imported.

Source:
https://arxiv.org/html/2006.16834v4

The frozen prior convention check is provenance/HALF_WEIGHT_SOURCE_AUDIT.md; the new actual substitution is independently checked in audit/BRIDGE_AUDIT.md.

## Elementary constants

The proofs use 3<pi<22/7, the sharper pi>157/50 when bounding phi(0)<2/5, and the elementary exponential bound exp(1/2)<5/3. Machin's identity and alternating arctangent sums derive pi>157/50 in provenance/ADAPTIVE_PRIMARY.md. The reflection audit supplies exp(1/2)<=277/168<5/3 using a geometric bound on the exponential tail. No tabulated normal probability is required.
