# Independent audit of the signed B interval integrator and 15-cell pilot

## Verdict and exact scope

**PASS, limited to the frozen source/mathematical contract and the 15 listed pilot cells.** The new B engine has a sound interval-enclosure construction for the upper-central application under the assumptions below. A fresh 256-bit build, run at exact tolerance 1/200000000, passed all 15 witnesses. Every one of the 30 finer J/gap intervals is contained in its corresponding 160-bit primary interval.

This accepts the implementation as a source-level method for subsequent B computations, not any unexecuted or unchecked output. It does not certify full B coverage, a full coefficient range, lower-central inequalities, lower P/C extensions, the tails, or the full Keller–Klein conjecture. Full-domain acceptance still requires exact coverage checks, verification of all primary records, and independent replay of that full run. This is an independent source/analytic audit and fresh build/replay of the same implementation, not a second independently authored rigorous integration engine or proof-assistant formalization.

No downloaded author mathematical code was executed. The only external mathematical theorem used here is the previously audited strict-tail Prawitz smoothing input, in Keller–Klein Theorem 4.5, equations (39)–(40), with its symmetric reduction: https://arxiv.org/html/2006.16834v4#S4.SS1.SSS1 . Its proof is not reconstructed here.

## Frozen bytes and execution

Independently recomputed the following SHA256 values before and after replay:

- signed_interval.cpp: 38543b3feff85724c55e9cd4632863446a767dd937fb3df27d4837e5aabf6e07
- SIGNED_B_METHOD.md: 604a75154725994dcd007a9437f86edb6383ce86e6335892a748ce7e350b8b28
- pilot_B.tsv: 2512e6a20f7ec7a8844aa6c8820ecf1e2117526cba63c85ba949831c30bd7779
- pilot_B_160.jsonl: 30c643f01dae35cd3495b3c10a0d10b5c413e6616f3fb24cf7e23f488dfffe65
- included interval.hpp: ffead441ac72051aea15a729b377733fa1a88d98ac6e7448e320002d92b1c0b8

The four first files are in ../keller_klein_signed_pilot_20261107; the header is in ../keller_klein_interval_pilot_20261107. The primary INPUT_SHA256SUMS was verified. The header's separate arithmetic/official-header ABI audit in AUDIT_AFFINE_PILOT_20261107.md and AUDIT_AFFINE_ADDITIONS_20261107.md was read; the relevant arithmetic, max, erf, endpoint conversion and serialization helpers were also inspected directly in this audit.

Fresh compile, from the frozen source directory:

    g++ -O2 -std=c++17 -DINTERVAL_BITS=256 signed_interval.cpp -Wl,-l:libmpfi.so.0 -Wl,-l:libmpfr.so.6 -lgmp -o ../audit_signed_b_20261107/signed_interval256

Replay on CPU 3:

    taskset -c 3 ../audit_signed_b_20261107/signed_interval256 pilot_B.tsv 1/200000000 20000

Environment: x86_64 Linux, g++ Debian 14.2.0-19, MPFI 1.5.4, MPFR 4.2.2. The run exited zero, with 15/15 passes in 4.08483142 seconds. It used 232–330 leaves per witness and 5–18 rough/sign-uncertain leaves. No CPU 0 task was launched.

Raw replay: pilot_B_256.jsonl, SHA256 fc8c4563361b055833695ae41d0f889bb79b50819766b7d858499c1715be6646. Standard error is empty. Minimum lower gap: 1.198607071875760540813513231823827478024521393490969837e-5, source row 1522, cell 0. The largest recorded J width is approximately 4.9907903272095073e-9, below the exact requested tolerance.

## Mathematical contract, sign, normalization and atoms

Let X=sum b_i epsilon_i be a finite sum of independent unbiased Rademacher signs, with sum b_i^2=1. Coefficient signs may be absorbed into epsilon_i, and zero coefficients discarded. For a witness require 0<alpha<beta<=1, 0<=x_left<x_right, T>0, and actual maximum m=max|b_i| in [alpha,beta]. Set H(x)=erf(x/sqrt(2)), v=Tu, t=beta v, lambda=-T x_right.

The source uses

    k=(1-u)cos(lambda u)-rho(u)sin(lambda u),
    rho=(1-u)cot(pi u)+1/pi.

With z=-x_right this is exactly the plus-sine upper-central kernel. The strict-tail Prawitz inequality and symmetry give

    P(|X|<=x_right) = 1-2 P(X<-x_right)
                         <= 2 integral_0^1 k(u) phi_X(Tu) du.

The event on the left is weak: atoms at +/-x_right and at zero are retained. There is no unrecorded factor T: the smoothing formula has already been expressed in u in [0,1], and its characteristic function is evaluated at Tu. The source's characteristic-function envelopes have sum b_i^2=1 built into their Gaussian exponent and their power 1/beta^2.

For any x in [x_left,x_right], monotonicity of weak central probability and of H gives the sufficient test

    H(alpha)+H(x_left)-2 J >= 0,

where J is an upper enclosure for integral k phi_X. Since H(m)>=H(alpha), this proves P(|X|<=x)<=H(x)+H(m) on this specific cell, uniformly over the coefficient vector. The source uses alpha, not beta, in the target and uses the right threshold in the kernel. Both choices are necessary and correct.

Input-contract caveat: the executable itself checks xl<xr but does not enforce xl>=0. All 15 frozen inputs satisfy xl>=0, which the independent output checker enforces. Any later coverage/input checker must enforce this assumption or imply it from exact nonnegative grid construction. This is not a defect in the accepted pilot or the stated upper-central contract, but the binary alone should not be advertised as validating arbitrary unrestricted inputs.

## Four characteristic-function envelopes

Write p=1/beta^2, G(v)=exp(-v^2/2), and phi_X(v)=product cos(b_i v). The unique root theta of exp(-t^2/2)+cos t in (pi/2,pi) exists by the endpoint signs; its derivative is -t exp(-t^2/2)-sin t<0 there.

1. **0<=t<=pi/2:** log(cos s)/s^2 decreases from -1/2 on (0,pi/2). Summing the normalized inequalities with weights b_i^2 yields cos(t)^p<=phi_X(v)<=G(v). At t=pi/2 the zero lower endpoint is valid by a limit. The implementation avoids differentiating its power through a cosine zero.

2. **pi/2<=t<=theta:** for every s in [0,theta], |cos s|<=exp(-s^2/2), so |phi_X(v)|<=G(v). If the product is negative, select one factor with s_i=|b_i|v>pi/2. Then |cos s_i|<=|cos t| and the product of the absolute values of the remaining factors is <=exp(-(1-b_i^2)v^2/2)<=exp(-(1-beta^2)v^2/2). Therefore the lower bound is cos(t) exp(-(1-beta^2)v^2/2). If the product is nonnegative this negative lower bound is automatic. The source implements this L and G as U.

3. **theta<=t<=pi:** q(s)=log|cos s|/s^2 increases on (pi/2,pi), since q'(s)=[-s tan s-2log|cos s|]/s^3>0. On the first half q(s)<=-1/2, while q(t)>=-1/2 in this region. Thus q(s_i)<=q(t) for every 0<s_i<=t, with zero cosine handled by a limit. Summing with b_i^2 gives |phi_X(v)|<=|cos t|^p. Hence L=-|cos t|^p and U=|cos t|^p are valid. This direct weighted-log argument also justifies the profile/Hölder wording of the method note.

4. **t>=pi:** -1<=phi_X(v)<=1 is sufficient and is used without a smooth transcendental envelope.

The implementation's thetaRoot starts with exact rationals 17/10 and 19/10, verifies they lie within the root's domain and verifies their function signs. Ninety interval bisections preserve an enclosing root bracket. Region tests compare exact outward MPFR endpoints against safe sides of pi/2, theta and pi; a crossing or uncertain boundary is sent to a rough panel. The same envelope is selected at the midpoint and on the whole cell only after whole-cell classification. No branch is assigned using an approximate floating-point key.

## Kernel bound, rough panels and endpoint identities

For 0<u<1, rho>=0. This is direct for u<=1/2; for u>=1/2, w=1-u gives rho=1/pi-w cot(pi w)>=0 from tan y>=y. Also cot(pi u)<=1/(pi u), whence rho<=1/(pi u). Consequently

    |k(u)| <= 1+|lambda|/pi = K.

Each envelope value lies in [-1,1], so f(u)=max(kL,kU) also satisfies |f(u)|<=K. For an uncertain region, the fallback [-K h,K h] encloses its integral. For uncertain kernel sign, maxI(kL,kU) is an interval enclosure for f and multiplication by h is valid. Replacing an unnecessarily wide quadrature/natural interval by [-K h,K h] is valid independently of the first enclosure; no monotonicity in its width is being assumed. A slight conservative interval discrepancy in the width comparison affects only refinement efficiency.

The strips [0,delta] and [1-delta,1], delta=2^-45, together contribute an interval [-2delta K,2delta K]. The source keeps this enclosure in the global sum, rather than dropping the strips.

For small u, the implemented identity is

    k=(1-u)[cos(lambda u)-(lambda/pi) cos(pi u) sinc(lambda u)/sinc(pi u)]
      -(lambda u/pi) sinc(lambda u).

It follows by substituting sin y=y sinc y into rho sin(lambda u). For w=1-u small,

    rho=[1-cos(pi w)/sinc(pi w)]/pi.

This follows from cot(pi u)=-cot(pi w). Both are exact identities, with continuous removable endpoint extensions. The source uses the sinc identities only when the whole argument interval has absolute value <=1/2. The associated sinc denominators are strictly positive; any interval containing zero would trigger the header's denominator guard rather than an acceptance. Elsewhere the direct cotangent formula is smooth on the interior cell.

## Sinc derivative tails and fourth-order jets

The degree-32 sinc polynomial contains k=0,...,16 terms (-1)^k z^(2k)/(2k+1)!. For a linear z with slope lambda and j=0,...,4, its first omitted Taylor-derivative coefficient has absolute bound

    |lambda|^j Z^(34-j) / [j! * 35 * (34-j)!],  Z=sup|z|<=1/2.

The exact next-term ratio includes the factor 35/37, which is <=1; uniformly in all later terms, it is at most Z^2/[(36-j)(35-j)]. The source adds the symmetric geometric sum bound first/(1-ratio) separately to each coefficient j. It does not confuse a function-value tail with a derivative tail. The argument and slope used for w=1-u correctly have opposite derivative sign.

All jet coefficients are f^(j)/j!. Uninitialized higher coefficients are actually initialized to zero by I's constructor. Multiplication is convolution; reciprocal solves a*z=1 recursively; exponential uses n*z_n=sum k*a_k*z_(n-k); logarithm uses a'/a; and paired sine/cosine recurrences differentiate s'=a'c, c'=-a's. The implementation matches these equations through order 4. Interval parameters are treated as constant and enclose the fixed exact parameters, so loss of dependencies only broadens the derivatives.

On a fixed-region, certified-constant-kernel-sign cell, f is one C4 branch: kU when k>=0, kL when k<0. No derivative across a kernel switch or a cosine-power zero is taken. Whole-cell jet coefficients enclose the derivatives at each point in that cell. A Taylor expansion at the midpoint, through degree 3 with fourth derivative remainder, integrates to

    h f(mid)+h^3 c2(mid)/12+h^5 c4(cell)/80.

The odd terms vanish. Since integral_(−h/2)^(h/2) x^4 dx=h^5/80, the signed interval fourth coefficient multiplies a nonnegative weight, and the source's factor is correct. Powers with p<4 need not be C4 at their cosine zero; that zero is excluded from smooth evaluation and is handled by refinement/rough panels. This matters for the largest pilot beta and is correctly respected.

## Arithmetic, adaptive summation and fail-closed behavior

Rationals are parsed with GMP and converted outward to MPFI. MPFI supplies outward arithmetic/transcendentals; erf uses monotonic MPFR calls with RNDD and RNDU. maxI independently takes the maximum of the two lower endpoints and of the two upper endpoints. The helper called absI may have a negative lower endpoint on a crossing-zero interval, but its upper endpoint is a valid absolute bound and every use here requires only that upper bound. It is never incorrectly treated as a nonnegative absolute interval.

The priority queue's width comparison uses actual MPFR endpoints. Refinement order itself is only an efficiency choice. replaceTerm subtracts the old lower endpoint from the current lower accumulator and adds the two new lower endpoints with outward-down rounding. It performs the analogous upper update with outward-up rounding. Inductively the accumulator encloses the sum of all current panel enclosures plus the endpoint strips, even if cancellation causes accumulated excess width. It does not subtract the old interval as an ordinary interval difference.

The integrator stops only when the upper endpoint of the total-width interval is <= the lower endpoint of the requested rational tolerance. A maximum-leaf failure throws, returns nonzero, and produces no success summary. A separate run with max_leaves=2 verified this behavior: exit code 3 and diagnostic 'max leaves'. Zero input witnesses cannot return success. The serialized decimal endpoints are separately rounded outward; pass/fail uses the actual internal lower gap endpoint, not the display string. Doubles are used only for elapsed time.

## Independent recorded-output checker and sanity probes

check_pilot_outputs.py is newly authored for this audit. It uses exact Fraction arithmetic, explicit checks rather than disableable Python assertions, and hardcoded frozen hashes. It checks all 15 ordered identities and exact rational parameters, the nonnegative x domain, 160/256-bit metadata, exact tolerance containment, finite ordered interval endpoints, interval widths, strictly positive gap lower endpoints, flags, leaf/evaluation consistency, and successful summaries. It verifies overlap and, more strongly, containment for all 30 finer J/gap intervals. Result: output_check.json, PASS_EXACT_PILOT_OUTPUT_CHECK.

Additional probes in probe_signed_jets.cpp include the frozen own source under a renamed main. Independently written check_probes.py compares 195 point-jet coefficients against 180-decimal mpmath references for sinc, the kernel at zero/one/near both endpoints/interior, and an exp/log/trigonometric composition. The exact sinc derivative formula at zero is used instead of a numerically differentiated zero. All probes pass, as does the crossing-zero maxI test. These are **non-certifying numerical sanity checks**, not replacements for the analytic derivative-tail and source arguments above. The initial numerical-differentiation oracle produced a tiny nonzero residual for an exact odd sinc derivative at zero; the oracle was corrected to the exact parity formula, not the audited source. The final raw probes and checker are retained.

All audit artifacts and exact hashes are recorded in audit_manifest.json and SHA256SUMS. build_replay.sh documents reproduction. CPU 3 was used for replay and probes. Acceptance remains only the frozen B implementation and the 15 named pilot cells; no later modified source inherits it automatically.
