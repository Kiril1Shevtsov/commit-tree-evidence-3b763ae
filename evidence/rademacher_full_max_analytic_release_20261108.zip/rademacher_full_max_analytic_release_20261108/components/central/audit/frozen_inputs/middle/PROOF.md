# Central upper endpoint lemma for 1/2 <= m <= 27/40

Date: 8 November 2026. Status: complete analytical candidate, exact arithmetic self-check PASS; independent audit pending.

This proof uses no numerical quadrature, parameter grid, or interval-arithmetic subdivision. There are two fixed parameter intervals, separated at 3/5, and two evaluations of explicitly integrated Taylor polynomials. The auxiliary Gaussian moments are bounded by rational Mills-ratio inequalities.

## 1. Statement and normalization

Write t=m^2, M=27/40, c=sqrt(2/pi), and

    H(m) = c integral_0^m exp(-v^2/2) dv.

For 0 <= delta <= t-t^2 define

    A_sharp(m,delta) = (2m/pi) integral_0^(pi/(2m))
        cos(ms) exp(-(1-t)s^2/2 -(t-t^2-delta)s^4/12) ds,

    J(m,delta) = integral_0^(pi/(4m)) s cos(ms)^(1/t)
        [1-exp(-pi delta s/(2m^3))] ds.

The two endpoint conclusions are

    A_sharp(m,0) < H(m),                                      (1)
    A_sharp(m,t-t^2) - (m^2/pi^2) J(m,t-t^2) < H(m)            (2)

for every 1/2 <= m <= M. Consequently, convexity in delta gives

    A_sharp(m,delta) - (m^2/pi^2) J(m,delta) <= H(m)

throughout this rectangle with its variable upper delta endpoint.

The factor in front of J is m^2/pi^2, namely one half of the parent's Gain=2m^2 J/pi^2. At the second endpoint the damping coefficient is pi(1-m^2)/(2m).

For completeness the head envelope is valid for Rademacher products: retain a largest factor cos(ms) exactly and use log cos v <= -v^2/2-v^4/12 on all the other factors. Their second moment is 1-t and their fourth moment is q-t^2=t-t^2-delta. No actual coefficient profile is needed at a formal endpoint: the scalar bound is proved on the full stated delta interval.

The integrands defining A_sharp are convex in delta. Also -J is convex in delta, since the second derivative of -(1-exp(-a delta)) is a^2 exp(-a delta). Thus the final convexity assertion is in the correct direction.

## 2. A polynomial cosine envelope

Put

    g(u)=exp(u^2/2) cos u,  0 <= u <= pi/2,
    p(u)=1-u^4/12-u^6/45-11u^8/3360.

Then g is decreasing, nonnegative, and g(u) <= p(u) on this interval. Monotonicity follows from tan u >= u. For the inequality set

    h(u)=exp(-u^2/2)p(u)-cos u.

Direct differentiation gives

    h''+h = exp(-u^2/2) u^8(304-33u^2)/10080 >= 0,
    h(0)=h'(0)=0.

Indeed pi<22/7 implies 304-33(pi/2)^2>0. Therefore

    h(u)=integral_0^u sin(u-v) exp(-v^2/2)
                         v^8(304-33v^2)/10080 dv >= 0.

Extend g by zero for u>=pi/2; call this extension g_+.

Let Z be half-normal with density c exp(-s^2/2), let B=58/25, and set Y=min(Z,B). Since MB=783/500 < pi/2 (use pi>157/50), monotonicity and the envelope give

    0 <= g_+(mZ) <= p(mY).

In particular p(mY)>=0. The normalization is

    A_sharp(m,t-t^2)/(cm) = E[g_+(mZ)].                         (3)

## 3. Six capped Gaussian moment bounds

Let M_n=E[Y^n]. The bounds used below are

    M_4 >= 247/100,  M_6 >= 89/10,  M_8 >= 37,
    M_8 <= 39,       M_10 <= 180,    M_12 <= 875.              (4)

Here is a fully rational derivation. Set G=exp(-B^2/2), K=cG, and

    R(x)=exp(x^2/2) integral_x^infinity exp(-s^2/2) ds,
    L(x)=x(x^2+5)/(x^4+6x^2+3),
    U(x)=(x^2+2)/(x^3+3x).

For every x>0,

    L(x) <= R(x) <= U(x).                                    (5)

To verify (5), R'=xR-1, while

    L'-xL+1 = 24/(x^4+6x^2+3)^2 > 0,
    U'-xU+1 = -6/[x^2(x^2+3)^2] < 0.

Multiply the differences by exp(-x^2/2), integrate to infinity, and use their vanishing weighted limits.

For even n let d_n=(n-1)!! and define P_2(B)=B,

    P_n(B)=B^(n-1)+(n-1)P_(n-2)(B).

Integration by parts gives the exact capped-moment identity

    M_n=d_n+K[(B^n-d_n)R(B)-P_n(B)].                          (6)

All B^n-d_n for n=4,6,8,10,12 are positive. At both rational values R=L(B),U(B), the brackets in (6) are negative. Also

    27/500 < K < 34/625.                                     (7)

For (7), use 157/50<pi<22/7, giving 319/400<c<4/5. Put x=B^2/2=1682/625 and E_n(x)=sum_(j=0)^n x^j/j!. The following two small rational inequalities suffice:

    E_8(x)>250/17,
    E_6(x)+[x^7/7!]/[1-x/8] <1595/108.

The first implies G<17/250; the second bounds exp(x) by the geometric tail of its positive series and implies G>108/1595. They yield (7).

Combining (5)-(7) gives explicit rational lower and upper moment bounds:

    M_n >= d_n+(34/625)[(B^n-d_n)L(B)-P_n(B)],
    M_n <= d_n+(27/500)[(B^n-d_n)U(B)-P_n(B)].                (8)

Substitution in the first formula proves the three lower bounds in (4); substitution in the second proves the three upper bounds. All six comparisons and signs are checked with exact fractions in verify.py.

## 4. The zero-defect endpoint

Put a=t(1-t)/12. From the original integral and the cap argument,

    A_sharp(m,0)/(cm)
       = E[g_+(mZ) exp(-a Z^4)]
       <= E[p(mY) exp(-a Y^4)].                              (9)

This is legitimate because p(mY)>=0, and Y<=Z. Also

    0<=aY^4<=B^4/48<2/3.

For 0<=y<=2/3, the fourth Taylor polynomial gives

    exp(-y) <= 1-y+y^2/2-y^3/6+y^4/24 <= 1-(18/25)y.          (10)

For the second step, 1-y/2+y^2/6-y^3/24 is decreasing on this interval and at 2/3 equals 59/81>18/25.

Using (4), (9), and (10), an upper bound on A_sharp(m,0)/(cm) is

    1 - (247/1200)t^2 - (89/450)t^3 - (407/3360)t^4
    - (18/25)[t(1-t)/12]
        [247/100 - (39/12)t^2 - (180/45)t^3
                         - (11*875/3360)t^4].                (11)

The third Taylor polynomial for the Gaussian gives

    H(m)/(cm) = integral_0^1 exp(-t v^2/2) dv
              >= 1-t/6+t^2/40-t^3/336.                      (12)

Subtract (12) from (11). The resulting polynomial D(t) satisfies exactly

    D(t)/t = -N(t)/2520000,
    N(t)=433125t^5+171675t^4+191850t^3-500t^2
                                      +208236t-46536.

Now

    N(1/4)=9812977/1024>0,
    N'(t)=2165625t^4+686700t^3+575550t^2-1000t+208236>0

on [0,1]. Hence D(t)<0 whenever 1/4<=t<=729/1600. This proves (1) on the entire interval, without parameter subdivision.

## 5. The maximal-defect endpoint: head bound

By (3), (4), and (12),

    [pi^2/m^2][A_sharp(m,t-t^2)-H(m)] <= C P(m),             (13)
    C=sqrt(2pi^3)<79/10,
    P(m)=m/6 -277m^3/1200 -4909m^5/25200 -407m^7/3360.

P is strictly decreasing for m>=1/2: every nonconstant term of P' is negative, and

    P'(1/2)=-259927/3225600<0.

P(M)>0, so multiplying by the upper bound on C is valid throughout the interval. The endpoint values give

    (79/10)P(1/2)=24180241/64512000 <3/8,
    (79/10)P(3/5)=218444243/875000000 <1/4.                 (14)

The constant bound C<79/10 follows immediately from pi<22/7 by squaring.

## 6. The maximal-defect endpoint: gain bound

Write J(m)=J(m,t-t^2). This function is decreasing in m on (0,1). Indeed the upper integration limit decreases, k(m)=pi(1-m^2)/(2m) decreases, and

    cos(ms)^(1/m^2)=exp[-s^2 F(ms)/(ms)^2], F(u)=-log cos u,

also decreases: F(u)/u^2 increases by its positive power series.

For 0<=u<=pi/4 that same monotonicity yields

    F(u)/u^2 <= 8 log(2)/pi^2 <4/7.

The last inequality follows from log(2)<7/10 and pi>157/50; the logarithm bound follows, for example, from E_4(7/10)>2. Thus

    J(m) >= integral_0^(pi/(4m))
            s exp(-4s^2/7)[1-exp(-k(m)s)] ds.                (15)

We need just the two rational bounds

    J(3/5)>3/8,              J(27/40)>1/4.                  (16)

Here are exact, finite polynomial proofs. At either m define rational

    b=157/(200m),       k=157(1-m^2)/(100m).

These are lower bounds for the limit and k(m) in (15). Define

    T_n(z)=sum_(i=0)^n (-z)^i/i!,
    Q_r(w)=sum_(j=1)^r (-1)^(j+1) w^j/j!.

An odd n gives T_n(z)<=exp(-z), and an even r gives
Q_r(w)<=1-exp(-w). On the two integration intervals below, 0<=4s^2/7<1 and 0<=ks<9/4. T_3,T_5 are nonnegative on z in [0,1]. Q_4 is nonnegative on w in [0,9/4], since

    Q_4(w)/w=1-w/2+w^2/6-w^3/24

is decreasing and equals 125/512>0 at w=9/4. Also Q_8>=Q_4 there by grouping its fifth/sixth and seventh/eighth terms. We can therefore multiply the polynomial lower bounds.

Set

    S_(n,r)(m) = sum_(i=0)^n sum_(j=1)^r
       [(-4/7)^i/i!] [(-1)^(j+1) k^j/j!]
                         b^(2i+j+2)/(2i+j+2).

This is the exact integral of s T_n(4s^2/7) Q_r(ks) from 0 to b, not a quadrature rule. Direct rational arithmetic gives

    S_(5,8)(3/5) > 47/125 >3/8,
    S_(3,4)(27/40) >13/50 >1/4.

The respective diagnostic decimal values are approximately 0.376670 and 0.261353; they play no role in the proof. The finite sums and comparisons are reproduced exactly in verify.py. This proves (16).

Finally, for 1/2<=m<=3/5, (13)-(16) and monotonicity give

    [pi^2/m^2](A_sharp-H) <3/8<J(3/5)<=J(m).

For 3/5<=m<=27/40 they give

    [pi^2/m^2](A_sharp-H) <1/4<J(27/40)<=J(m).

This proves (2).

## 7. Scope

This file proves the remaining scalar central endpoint lemma on [1/2,27/40] and the intermediate-delta extension. The small-m central region, the Prawitz reduction from central probabilities to this scalar inequality, the lower bound, and the outer upper region are separate ingredients. This file does not itself certify those ingredients or announce a complete max-coefficient theorem.
