# Keller–Klein normal approximation through coefficient one tenth

## Status and provenance

This is a newly reconstructed proof text after the execution workspace was lost. It is not a byte-for-byte recovery of any earlier file. The previously reported mathematical audit through 1/10 is historical evidence only; the present text and its accompanying reconstructed checkers require a fresh file-level audit before this directory is released. No numerical verification of the complementary coefficient range is claimed here.

The intended result is the following. If a finite Rademacher sum \(X=\sum_i b_i\varepsilon_i\) satisfies \(\sum_i b_i^2=1\), and \(0<a\le1/10\) is any bound for \(\max_i|b_i|\), then, for every real \(x\),
\[
 |\Pr(X\le x)-\Phi(x)|\le \Phi(a)-\tfrac12.
\]
Zero coefficients may be deleted and coefficient signs absorbed into the independent symmetric signs. No equal-coefficient assumption or continuity of the law of \(X\) is made.

Put \(H(x)=2\Phi(x)-1\), \(\phi_0=(2\pi)^{-1/2}\), \(\phi(x)=\phi_0e^{-x^2/2}\), \(c=\sqrt{2/\pi}=2\phi_0\), and \(c_a=H(a)/2\). We prove the weak upper-central and strict lower-central inequalities
\[
 \Pr(|X|\le x)\le H(x)+H(a),\qquad
 \Pr(|X|<x)\ge H(x)-H(a)\quad(x\ge0).
\]

## External inputs and corrected citation

The smoothing input is Prawitz's inequality as stated in Keller and Klein, *Proof of Tomaszewski's Conjecture on Randomly Signed Sums*, Theorem 4.5, equations (39)–(40), and the symmetric reduction in Section 4.1.2:
https://arxiv.org/html/2006.16834v4#S4.SS1.SSS1

For a symmetric real random variable and \(T>0\), let
\[
 \rho(u)=(1-u)\cot(\pi u)+1/\pi,\quad
 k_\pm(u;x,T)=(1-u)\cos(Tux)\pm\rho(u)\sin(Tux).
\]
The strict-tail form gives
\[
 \Pr(|X|\le x)\le2\int_0^1k_+(u;x,T)\varphi_X(Tu)\,du,
 \quad
 \Pr(|X|<x)\ge-2\int_0^1k_-(u;x,T)\varphi_X(Tu)\,du.
\]
The removable limits at zero are understood. In particular, these are not statements that discard the mass of an atom.

The second input is the half-weight interval comparison in the same paper, Lemma 3.7. Write \(W(A,B)\) for mass in \((A,B)\) plus half the mass at each endpoint. Its assumptions are \(|A|\le C\) and \(2\max(M,D-B)\le C-A\), where \(M\) is the largest coefficient. We apply it only to \((-b,b,b,2b)\) with \(b\ge a\).

Citation correction: earlier working texts called the original smoothing input “Theorem 3.1 / Corollary 3.2.” Those are not its numbers in the original Keller–Klein paper. The correct original reference is Theorem 4.5, (39)–(40). This correction changes no formula below.

## The small central interval

Take \(T=\pi/a\). The elementary cotangent partial fraction expansion gives \(\rho\ge0\) on \((0,1)\). Set \(R(u)=u\rho(u)\). We use
\[
 R(u)\le1/\pi-(\pi/3)u^2(1-u)\quad(0\le u\le1),
\]
and, for \(0\le w\le1/2\),
\[
 R(1-w)\le(\pi/3)(w^2-w^3+4w^4/3).
\]
Both polynomials are nonnegative when extended to the nonnegative half-line. For the second inequality, writing
\(q(z)=\cot z-1/z+z/3\) and using its negative-power-series coefficients reduces the bound to
\(-q(\pi w)\le (4\pi/9)w^3/(1-w)\); the standard partial fractions, or the stronger bound \((1-w)|q(\pi w)|\le\pi^3w^3/45\), prove it. The latter bound is justified below.

Since \(|\sin(Tux)|\le Tux\), the nonnegative weight
\(2[(1-u)+TxR(u)]\) dominates \(2|k_+|\). Apply Hölder with exponents \(1/b_i^2\) to \(\prod_i|\cos(b_iTu)|\). Consequently
\[
 \Pr(|X|\le x)\le\sup_{0<e\le a}\{A_e+xB_e\},\qquad
 A_e=2\int_0^1(1-u)h_e(u)\,du,\quad
 B_e=2\int_0^1TR(u)h_e(u)\,du,
\]
where \(h_e(u)=|\cos(eTu)|^{1/e^2}\). The absolute value is taken before Hölder, so a changing sign of the characteristic function is harmless.

For \(e\le a/2\), \(h_e(u)\le e^{-(Tu)^2/2}\). For each of the two pairs
\[
 (b_0,b_1)=(a/2,9a/10),\quad(9a/10,a),
\]
the function \(z\mapsto\log|\cos z|/z^2\) decreases on \((0,\pi/2)\) and increases on \((\pi/2,\pi)\). Therefore the central profile for \(b_0\), up to its first zero, together with the reflected profile for \(b_1\), after its first zero, majorizes every intermediate \(h_e\). Where the two regions overlap their sum is a valid upper bound.

Let
\[
 G(v)=e^{-v^2/2},\quad P_e(v)=1-e^2v^4/12+e^4v^8/288>0.
\]
On \(0\le ev\le\pi/2\), \(\cos(ev)^{1/e^2}\le G(v)P_e(v)\). Indeed \(\log\cos z\le-z^2/2-z^4/12\), and \(e^{-y}\le1-y+y^2/2\) for \(y\ge0\). With \(d=\pi/b_1-T\), valid majorants are
\[
\begin{aligned}
 C_A(e)&={2\over T}\left[\int_0^\infty(1-v/T)P_eG\,dv+
                  \int_T^\infty(v/T)P_eG\,dv\right],\\
 R_A(e,d)&={2\over T^2}\int_d^\infty(v-d)P_eG\,dv,\\
 C_B(e)&=2\int_0^\infty[1/\pi-\pi v^2/(3T^2)+\pi v^3/(3T^3)]P_eG\,dv,\\
 R_B(e,d)&={2\pi\over3}\int_d^\infty[(v-d)^2/T^2-(v-d)^3/T^3+
                    4(v-d)^4/(3T^4)]P_eG\,dv.
\end{aligned}
\]
In \(C_A\), the extra tail prevents extension of a negative weight from invalidating an upper bound. The other extended weights are nonnegative. The pair majorants are \(C_A(b_0)+R_A(b_1,d)\) and \(C_B(b_0)+R_B(b_1,d)\). The Gaussian branch uses \(P=1\), no reflection, and the same \(C_A\) correction.

All Gaussian polynomial moments are exact:
\(I_0=\sqrt{\pi/2}\), \(I_1=1\), \(I_n=(n-1)I_{n-2}\). Writing \(t=e/a\), the uncorrected central moments are
\[
 C_A^0(e)=ca(1-t^2a^2/4+35t^4a^4/96)
 -{2a^2\over\pi^2}(1-2t^2a^2/3+4t^4a^4/3),
\]
\[
 C_B(e)=c-c(t^2/4+1/3)a^2+{4a^3\over3\pi^2}
 +c(35t^4/96+5t^2/12)a^4-{8t^2a^5\over3\pi^2}
 -{35ct^4a^6\over32}+{80t^4a^7\over9\pi^2}.
\]
The second pair has \(d=0\) and hence its reflected moments are also exact.

For tails let \(S_0(z)=1/z\), \(S_1(z)=1\), \(S_n(z)=z^{n-1}+(n-1)S_{n-2}(z)\). Mills' inequality and integration by parts imply
\(\int_z^\infty v^nG(v)\,dv\le G(z)S_n(z)\). In particular
\(S_9=z^8+8z^6+48z^4+192z^2+384\).
The central correction divided by \(a^3\) is at most
\[
 {2\over\pi^2a}e^{-\pi^2/(2a^2)}
       [1+a^4S_9(\pi/a)/288].
\]
For the first pair put \(s=9/10,z=\pi/(9a)\). Its two reflected bounds, after division by \(a^2\), are
\[
 Q_A(a)={2\over\pi^2}e^{-z^2/2}[1+s^4a^4S_9(z)/288],
\]
\[
 Q_B(a)={2\over3\pi}e^{-z^2/2}
 [S_2(z)+s^4a^4S_{10}(z)/288+
 {4a^2\over3\pi^2}(S_4(z)+s^4a^4S_{12}(z)/288)].
\]
Here negative terms have only been removed. Every Laurent coefficient in these positive tail polynomials is nonnegative. Their least powers of \(a\) are respectively \(-5,-4,-5\). Differentiating \(a^q e^{-\kappa^2/(2a^2)}\) proves that all these tails increase on \(0<a\le1/10\): the worst condition is \(-5+(\pi/(9a))^2>0\). They also vanish at \(a\downarrow0\).

Put \(u=1/10,r=1/2,s=9/10,\eta=10^{-100}\). Since \(H(a)\ge c(a-a^3/6)\), lower bounds for the six normalized gaps are:
\[
\begin{aligned}
 A_G&=2/\pi^2-cu/6-\eta,& B_G&=c/6-4u/(3\pi^2),\\
 A_1&=2/\pi^2-c(1/6-r^2/4)u-4r^2u^2/(3\pi^2)-35cr^4u^3/96-Q_A(u)-\eta,\\
 B_1&=c(r^2/4+1/6)-4u/(3\pi^2)-c(35r^4/96+5r^2/12)u^2-80r^4u^5/(9\pi^2)-Q_B(u),\\
 A_2&=c(s^2/4-1/6)-35cs^4u^2/96-8(1-s^4)u^3/(3\pi^2)-\eta,\\
 B_2&=c(s^2/4-1/6)-c(35s^4/96+4/(3\pi^2))u^2
       -8(1-s^2)u^3/(3\pi^2)-35c(1-s^4)u^4/32-385cu^6/(24\pi^2).
\end{aligned}
\]
The normalizations for \(A_G,A_1\) are \(a^2\); for \(A_2\) they are \(a^3\); all \(B\)-gaps use \(a^2\). After positive remainders are dropped, every nonconstant retained coefficient has negative sign, justifying evaluation at \(u\).

The separate exact-rational outward-interval program checks that the central tail is less than \(\eta\), that \(A_G,A_1>u/50\), and that the other four gaps exceed \(1/50\). Its smallest displayed normalized gap is \(B_2>0.02552175258767474>0.02\). These are strict rational endpoint decisions, not decimal sampling. Thus
\[
 A_e\le H(a)-a^3/50,\qquad B_e\le H(a)/a-a^2/50.
\]
Concavity of \(H\) yields \(H(x)\ge xH(a)/a\) for \(0\le x\le a\), proving the stronger upper-central bound
\[
 \Pr(|X|\le x)\le H(a)+H(x)-(a^3+xa^2)/50.
\]

## The signed smoothing estimates outside the small interval

Let \(\xi=x/a\ge1\), still \(T=\pi/a\), and put \(s=Tu\).
For \(u\le1/2\), \(h=|\cos(as)|^{1/a^2}\le\varphi_X(s)\le G(s)\). For \(u\ge1/2\), the Hölder profile argument gives \(|\varphi_X(s)|\le G(s)+h\). For either kernel,
\[
 \int_0^1k\varphi_X\le J:=E+D_1+D_2+A,
\]
where
\[
 E=\int_0^1kG,\quad D_1=\int_0^{1/2}k^-(G-h),\quad
 D_2=2\int_{1/2}^1 k^-G,\quad A=\int_{1/2}^1|k|h .
\]
Here \(k^-=\max(0,-k)\). Define the errors to be bounded above by zero:
\[
 F_+=J_+-(\Phi(x)-1/2)-c_a,\qquad
 F_-=J_-+(\Phi(x)-1/2)-c_a.
\]

The partial fraction expansion
\[
 \cot z={1\over z}-2z\sum_{n\ge1}{1\over n^2\pi^2-z^2}
\]
gives, for \(q(z)=\cot z-1/z+z/3\),
\[
 |\,\rho(u)-1/(\pi u)\,|\le\pi u/3,\qquad
 (1-u)|q(\pi u)|\le\pi^3u^3/45\quad(0\le u\le1).
\]
For the second bound, expand \(q\) in positive even powers after changing its sign. Each denominator obeys \(1-u^2/n^2\ge1-u\); then use \(\sum n^{-4}=\pi^4/90\). This also proves the reflected weight bound used earlier.

Write
\[
 D(x)=\int_0^\infty\sin(sx)G(s)\,ds
 =x\int_0^1e^{-x^2(1-v^2)/2}\,dv,\quad
 M=1-xD,\quad N=x+(1-x^2)D.
\]
Elementary consequences are \(0\le D\le x\), \(xD\le2\), \(0\le N\le2x\) for \(x\le1\), and \(|N|\le\sqrt{\pi/2}<4/3\). For \(xD\le2\), use \(1-v^2\ge1-v\); the bound for \(N\) also follows from \(N=\int_0^\infty s^2\sin(sx)G(s)\,ds\).

Integration of the polynomial part of the kernel and extension to infinity gives
\[
 E_\pm\mp(\Phi(x)-1/2)
 \le a\phi(x)-a^2M/\pi^2
 \mp a^2x\phi(x)/3\ \pm a^3N/(3\pi^2)
 +2a^4/(45\pi)+\epsilon_E.
\]
All tail extensions are bounded absolutely in \(\epsilon_E\).

For \(0\le y\le1\),
\[
 -\log\cos y-y^2/2\le y^4/12+Ky^6,\qquad K=1/30.
\]
One elementary proof uses the positive Taylor coefficients of \(\tan y\): the quotient of the remainder by \(y^6\) increases. At \(y=1\), the alternating cosine bound \(\cos1\ge389/720\) and the degree-five positive exponential sum \(e^{37/60}>720/389\) give \(-\log\cos1<37/60=1/2+1/12+1/30\).

Both kernels obey on the central half
\[
 k^-\le(\xi-1)+as/\pi+a^2s^2(\xi^2/2+\xi/3).
\]
Using \(1-e^{-z}\le z\) and the previous logarithmic bound on \(as\le1\), then treating the rest as a Gaussian tail, gives
\[
\begin{aligned}
 D_1\le{}&\phi_0(\xi-1)a^3/4+2a^4/(3\pi^2)
 +15\phi_0K(\xi-1)a^5+48Ka^6/\pi^2\\
 &+(\xi^2/2+\xi/3)[5\phi_0a^5/4+105\phi_0Ka^7]+\epsilon_D.
\end{aligned}
\]
On the reflected half set \(t=1-u\), \(\beta=\pi\xi\). The weight estimate
\[
 |k|\le t|\cos\beta|+(\pi\xi+4\pi/9)t^2|\sin\beta|
          +(4\pi^2\xi/9)t^3|\cos\beta|
\]
and \(h\le e^{-(Tt)^2/2}\) show
\[
 A\le {a^2\over\pi^2}|\cos\beta|
       +{\phi_0a^3\over\pi}(\xi+4/9)|\sin\beta|
       +{8\xi a^4\over9\pi^2}.
\]
Finally combine the cosine loss with the sine term using
\[
 -Q(1-|\cos\beta|)+B|\sin\beta|\le B^2/(2Q)\quad(Q>0).
\]
For both signs we arrive at
\[
\begin{aligned}
 F_\pm\le{}&a\phi(x)-c_a+a^2xD/\pi^2
 \mp a^2x\phi(x)/3\ \pm a^3N/(3\pi^2)\\
 &+D_{1,\mathrm{poly}}+{\phi_0^2\over2}(\xi+4/9)^2a^4
       +{8\xi a^4\over9\pi^2}+c_Ra^4,
 \qquad c_R=3/200.
\end{aligned}
\]

## Uniform remainder budget and the exponential cutoff

Set \(x_E=\sqrt{2\log(1/c_a)}\). Since \(c_a>a/3\), we have \(x_E^2\le2\log(3/a)\le6/a\le1/a^2\) for \(a\le1/10\). In the region \(x\le x_E\), this implies \(\xi\le a^{-2}\). With \(e_a=e^{-1/(2a^2)}\), absolute Gaussian tails give
\[
 \epsilon_E\le6a^2e_a,\quad \epsilon_D\le4a^{-2}e_a,\quad D_2\le4e_a.
\]
For completeness, these generous tail constants can be obtained without a numerical quadrature. For \(z>0\), use \(\int_z^\infty G\le G(z)/z\), \(\int_z^\infty sG=G(z)\), \(\int_z^\infty s^2G\le G(z)(z+1/z)\), and \(\int_z^\infty s^{-1}G\le G(z)/z^2\). The polynomial Gaussian kernel extended past \(T\) is bounded by
\[
 1+as/\pi+1/(as)+as/3+a^2s^2/(3\pi).
\]
After multiplication by \(a/\pi\), its tail is at most
\[
 a^2G(T)[2/\pi^2+1/\pi^3+2/(3\pi)+a^2/(3\pi^3)]<a^2e_a,
\]
which is smaller than the stated \(6a^2e_a\). On \(s\ge1/a\), the bound \(\xi\le a^{-2}\) gives
\(\kappa\le a^{-2}+as/\pi+(1/(2a^2)+1/3)s^2\). Its integral, multiplied by \(a/\pi\), is at most
\[
 e_a[1/(2\pi a^2)+11/(6\pi)+a^2(1/\pi^2+1/(3\pi))]<4a^{-2}e_a.
\]
Finally \(0\le\rho(u)\le1/(\pi u)\), so \(|k|\le1+2/\pi<5/3\) on \(u\ge1/2\). Hence
\(D_2\le20a^2e^{-\pi^2/(8a^2)}/(3\pi^2)<4e_a\).

Their sum divided by \(a^4\) is at most \(14a^{-6}e_a\). This expression increases for \(a\le1/10\), and \(e>8/3\) gives
\[
 14\cdot10^6(3/8)^{50}<1/10000,\qquad
 2/(45\pi)+1/10000<3/200.
\]
These exact rational inequalities justify the stated \(c_R\).

Also \(\log30<7/2\), because
\(\sum_{j=0}^{10}(7/2)^j/j!=1951237723/58982400>30\).
Monotonicity of \(a\log(3/a)\) on this interval then gives
\[
 ax^2< L=7/10,\qquad ax<U=27/100\quad(x\le x_E),
\]
where \(aL\le(1/10)(7/10)<(27/100)^2\).

## Exact polynomial sign checks

All quantities in this section are rational except the temporarily symbolic \(\pi,\phi_0\). Use \(3<\pi\), \(25/8<\pi<22/7\), \(3/8<\phi_0<2/5\). The companion symbolic program re-expands the Gaussian moments and verifies all displayed algebraic identities and the rational budgets.

For \(a\le x\le1\), Taylor bounds for the Gaussian terms give
\[
 F_\pm/a^3\le P_0^\pm+aP_1^\pm+a^2P_2^\pm+a^3P_3+a^4P_4,
\]
with
\[
\begin{aligned}
 P_0^+&=-\phi_0(6\xi^2+\xi+1)/12,&
 P_0^-&=-\phi_0(\xi-1)(6\xi-1)/12,\\
 P_1^+&=(\xi^2+14\xi/9+2/3)/\pi^2
             +\phi_0^2(\xi+4/9)^2/2+c_R,\\
 P_1^-&=(\xi^2+8\xi/9+2/3)/\pi^2
             +\phi_0^2(\xi+4/9)^2/2+c_R,\\
 P_2^+&=\phi_0\xi^4/8+\phi_0\xi^3/6+15\phi_0K(\xi-1)
                      +(5/4)\phi_0(\xi^2/2+\xi/3),\\
 P_2^-&=\phi_0\xi^4/8+15\phi_0K(\xi-1)
                      +(5/4)\phi_0(\xi^2/2+\xi/3),\\
 P_3&=48K/\pi^2,& P_4&=105\phi_0K(\xi^2/2+\xi/3).
\end{aligned}
\]
For the upper sign divide by \(\xi^2\). The negative constant is at most \(-3/16\). With \(u=1/10\), a uniform positive budget is
\[
 S=u[29/81+(2/25)(13/9)^2+3/200]+1/20+u/15+u^2/20
      +5u^2/12+8u^3/45+7u^4/6.
\]
The margin \(3/16-S=116443/1620000>0\).

For the lower sign, first take \(9/5\le\xi\le3\), then \(\xi\ge3\). The negative constants after division are at most \(-49/648\) and \(-11/96\), respectively. Put
\[
 C_1=23/81+(2/25)(13/9)^2+3/200,\quad
 R=u^2/20+5u^2/12+8u^3/45+7u^4/6.
\]
The positive budgets are \(uC_1+9u^2/20+R\) and \(uC_1+1/20+R\). Their exact margins are \(31703/1620000>0\) and \(10559/810000>0\).

For \(1\le x\le x_E\), use \(e^{1/2}\ge13/8\) and \(c_a\ge\phi_0a(1-a^2/6)\). The negative baseline divided by \(a\) is at most \(-15/104+u^2/15\). Set \(V=uL/2+u^2U/3\). The entire positive upper budget, including this \(u^2/15\), is
\[
\begin{aligned}
 B={}&u^2/15+2u/9+4u^2/81+U/10+2u^3/27+u^2U/5+8u^5/45\\
 &+V/2+7u^2V/5+(2/25)[L+8uU/9+16u^3/81]
                 +8uU/81+3u^3/200.
\end{aligned}
\]
Thus the upper margin is \(15/104-B=12427271/877500000>0\). For the lower sign add \(16u/195\), bounding the positive \(ax\phi(x)/3\). Its margin is \(5227271/877500000>0\).

This proves the upper-central inequality for \(a\le x\le x_E\), and the strict lower-central inequality for \(9a/5\le x\le x_E\).

For \(x\ge x_E\), the upper inequality is trivial from the probability bound one and the Gaussian Mills bound. The lower follows from Hoeffding:
\(\Pr(|X|<x)\ge1-2e^{-x^2/2}\ge1-2c_a\ge H(x)-H(a)\).
The strict event is correct because Hoeffding bounds \(\Pr(|X|\ge x)\).

## Bridging the lower central gap without discarding atoms

For \(b\ge a\), Lemma 3.7 with \((-b,b,b,2b)\), followed by symmetry, gives
\(W(-2b,2b)\le3W(-b,b)\).
For \(x>a\), let \(b\uparrow x\) from below. Finiteness of the distribution, or monotone one-sided limits, yields
\[
 \Pr(|X|<x)\ge\tfrac13\Pr(|X|<2x).
\]
For \(a<x\le9a/5\), the already proved lower bound applies at \(2x\), since \(2x\ge9a/5\) and \(2x\le9/25<1\). The Gaussian comparison needed to conclude is
\[
 H(2x)+2H(a)-3H(x)
 \ge2\phi_0[2a-x-(4x^3+a^3)/3]
 \ge2\phi_0a[1/5-3041u^2/375]
 =2\phi_0a\,4459/37500>0.
\]
At \(0\le x\le a\) the target lower bound is nonpositive and is automatic. All junctions are therefore covered.

## Conversion to the full CDF statement

For \(x>0\), symmetry gives
\(\Pr(|X|\le x)=2F(x)-1\) and \(\Pr(|X|<x)=2F(x-)-1\).
The upper-central estimate bounds \(F(x)\); the lower-central estimate bounds \(F(x-)\), hence also \(F(x)\).
For \(y>0\), \(F(-y)=1-F(y-)\), so both bounds transfer to negative points with the correct one-sided CDF. At zero, symmetry gives \(F(0)\ge1/2\), and the weak-central estimate bounds its atom above. This proves the intended statement for every real \(x\), including atoms.

## Separate elementary upper bound for large coefficients

This paragraph is not a proof of the missing lower bound. If the actual largest coefficient \(a\ge27/40\), write \(X=a\varepsilon+Y\), with \(Y\) symmetric. For \(0\le x<a\),
\(\Pr(|X|\le x)=\Pr(|a+Y|\le x)\le\Pr(Y<0)\le1/2\).
For \(x\ge a\) it is at most one. The exact inequality \(H(27/40)>1/2\) follows from \(\phi_0>19947/50000\) and
\[
 2{19947\over50000}(b-b^3/6+b^5/40-b^7/336)
 ={229520461865155173\over458752000000000000}>1/2,\quad b=27/40.
\]
The bound on \(\phi_0\) is independently checked by Machin's formula. Thus the weak upper-central inequality holds for all \(x\ge0\) when \(a\ge27/40\). The lower-central inequality in that range is not claimed.

## Verification boundaries

The two accompanying checkers cover exact algebra, rational budgets, and all transcendental constants in the small-coefficient argument. They do not themselves prove Prawitz's theorem, the interval-comparison theorem, or the written analytic inequalities. A fresh independent audit of this reconstructed text is required and recorded separately.

No old MPFI replay is presented as a file of this reconstructed package. The exact-rational checker is sufficient for the finite constants and can be rerun using only the Python standard library. The symbolic checker uses SymPy only for exact symbolic algebra; it makes no floating-point acceptance decision.

The remaining full-CDF coefficient range \(1/10<a\le1\) has not been accepted by a complete independent numerical replay. The separate upper-only helper above does not change that statement. No assertion of worldwide priority or resolution of the whole Keller–Klein conjecture is made.

