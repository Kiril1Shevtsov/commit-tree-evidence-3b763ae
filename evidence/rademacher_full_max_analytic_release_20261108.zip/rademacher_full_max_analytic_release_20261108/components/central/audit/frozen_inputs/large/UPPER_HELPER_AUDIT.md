# Независимый аудит реконструированного доказательства Keller–Klein

Источник отчёта: независимый математический аудитор /root/audit_math_progress/audit_uniform_point_one, 2026-11-07. Отчёт возвращён текстом из read-only среды; запись в этот файл выполнена координатором. Это новый аудит конкретных доступных reconstructed bytes, а не восстановление старого MPFI replay.

## 1 Вердикт и границы

Проверен пакет /workspace/shared/keller_klein_010_reconstructed_20261107.

PASS: математических, численных, endpoint или coverage-пробелов в проверенном восстановленном доказательстве не обнаружено.

Принято: если X=Σbᵢεᵢ, знаки независимы и равномерны на {−1,1}, число коэффициентов конечно, Σbᵢ²=1, то для любого 0<a≤1/10 с max|bᵢ|≤a выполнено
|P(X≤x)−Φ(x)|≤Φ(a)−1/2
для каждого действительного x. Коэффициенты могут быть неравными; ограничений сверху на конечную размерность нет. Параметр a может быть верхней границей максимального коэффициента, а не только его точным значением. Атомы и x=0 включены.

Отдельно принято только weak upper-central утверждение P(|X|≤x)≤H(x)+H(a), x≥0, когда фактический максимальный коэффициент a≥27/40. Lower-central или full-CDF утверждение на этом большом диапазоне данным helper не устанавливается.

Оставшийся full-CDF диапазон 1/10<a≤1 настоящим аудитом не принят. Приоритет и решение неограниченной conjecture не заявляются.

## 2 Проверенные файлы и свежие запуски

Полностью прочитаны RECONSTRUCTED_PROOF.md, independent_exact_audit.py, independent_rational_intervals.py, оба сохранённых результата, checkpoint manifest и provenance.

Свежие read-only запуски с PYTHONDONTWRITEBYTECODE=1 и Python -B:
- exact symbolic checker: 93/93 PASS, exit code 0, stderr пуст;
- rational outward checker: 14/14 PASS, exit code 0, stderr пуст;
- stdout каждого запуска побайтно совпал с соответствующим сохранённым JSON.

Дополнительно выполнены 39 самостоятельных проверок: повторная оценка шести выражений из точных Gaussian moments; сопоставление с standalone backend; новые tail prefactors; Machin identity и выбор ветви; отсутствие float literals; directed dyadic rounding, reciprocal, sqrt, exp и отказ при нуле в знаменателе. Все 39 прошли.

Все 13 записей SHA256SUMS совпали до и после запусков. Primary-файлы не изменялись. Проверка hashes файлов плана и source-review означает только сохранность: утверждения о complementary-range replay этим verdict не принимаются.

## 3 Источники знаки и атомы

Ссылка на smoothing исправлена правильно: Keller–Klein, Theorem 4.5, equations (39)–(40).

Для симметричной случайной величины исходный generic kernel имеет minus-sine знак. Подстановка −x даёт plus-sine kernel для weak upper-central оценки. Lower-central оценка использует minus-sine kernel при +x.

Правильные отношения:
P(|X|≤x)=1−2P(X<−x) при x≥0;
P(|X|<x)=2P(X<x)−1 при x>0.
Второе равенство не требуется при нуле: lower-central target там неположителен. Возможная запись smoothing lower inequality при нуле безопасна, но не является применением этого равенства при x=0.

Предел paired kernel при u→0 конечен. Singular cotangent term не создаёт неучтённого endpoint remainder.

Для Lemma 3.7 сохранена half-weight convention. При подстановке (−b,b,b,2b), b≥a, обе гипотезы выполнены. Переход b↑x, b<x, даёт строгие central events. Атомы не отбрасываются.

## 4 Affine reduction и покрытие профилей

Проверены ρ≥0 и |k₊|≤(1−u)+TxR(u); Hölder после взятия абсолютных значений с положительной мерой и показателями 1/bᵢ²; убывание log|cos z|/z² на (0,π/2) и возрастание на (π/2,π); Gaussian cover для e≤a/2; два закрытых coefficient intervals [a/2,9a/10] и [9a/10,a] без пропусков и без сетки по a.

Проверены неотрицательность Pₑ и обеих продолженных polynomial weights, коррекция central A tail для отрицательного линейного веса, Jacobians и степени T при отражении v=π/b₁−Tu.

Из (1−w)|q(πw)|≤π³w³/45 следует −q(πw)≤(4π/9)w³/(1−w), поскольку π²<10<20. Умножение на (1−w)w даёт нужный quartic remainder.

Central polynomial weight положителен на всей неотрицательной полуоси: на [0,1] применяются u²(1−u)≤4/27 и π²<10; при u≥1 утверждение непосредственно. Reflected quartic положителен, поскольку 1−w+4w²/3>0.

## 5 Affine moments и предел a к нулю

Gaussian moments восстановлены из I₂ₘ(0)=(2m−1)!!√(π/2), I₂ₘ₊₁(0)=2ᵐm!. Они дают все central и zero-shift reflected formulas.

Точные favorable remainders:
- Gaussian A,B: 0;
- first A: a⁴/(6π²);
- first B: 35ca⁴/512+2a³/(3π²);
- last A: 19a/(75π²);
- last B: 3439a⁵/(1125π²)+35ca⁴/(9π²)+19ca²/240.

Все они неотрицательны. Retained nonconstant coefficients отрицательны, поэтому a=1/10 даёт uniform lower bounds.

Минимальные Laurent powers central, reflected A и reflected B tails равны −5,−4,−5. Коэффициенты положительны. Производная aᑫexp(−κ²/(2a²)) имеет знак q+κ²/a². Проверенные endpoint margins дают монотонность на всём 0<a≤1/10; хвосты стремятся к нулю при a↓0, finite lower cutoff не вводится.

Свежие lower endpoints:
AG 0.18934429127129445362309405775497588…;
BG 0.11947126898149918978746475821683027…;
A1 0.19351232303111426491938144440442702…;
B1 0.16645863652810536597219471482424504…;
A2 0.02658938034529076300595692737154833…;
B2 0.02552175258767474006154796295838021….

AG,A1 сравниваются с 1/500, остальные с 1/50. Наименьший slack >0.00552175258767474006.

Central tail/a³ строго положителен и заключён между
3.2533361263567604484489807837837577971700957236595198005464974709329084159282055×10⁻²⁰⁹
и
3.2533361263567604484489807837837577971700957236595198005464974709329084159282056×10⁻²⁰⁹.
η=10⁻¹⁰⁰ достаточно; старый budget 10⁻³⁰⁰ не используется. Concavity H завершает affine bound на всём [0,a], включая оба конца и атом при нуле.

## 6 Signed Prawitz decomposition

Characteristic envelopes h≤φX≤G на первой половине и |φX|≤max(G,h)≤G+h на второй корректны. J=E+D₁+D₂+A учитывает смены знака: kG+2k⁻G=|k|G на второй половине.

Проверены D′=1−xD, M=1−xD, N=x+(1−x²)D; 0≤D≤x; xD≤2; 0≤N≤2x при x≤1; |N|≤√(π/2)<4/3 для любого x.

Upper corrections имеют минус перед a²xφ/3 и плюс перед a³N/(3π²), lower corrections противоположны. В новом тексте знаки правильные.

Log-cos bound K=1/30 корректен. Positive-coefficient remainder argument действует внутри радиуса π/2; rational cosine/exponential endpoint checks достаточны.

Общий κ-majorant для k⁻ корректен при ξ≥1 для обоих знаков. Все коэффициенты D₁, включая 15,48,105, воспроизведены из Gaussian moments с Jacobian a/π.

Reflected alias majorant и три Gaussian moments корректны. Неравенство
−Q(1−|cos β|)+B|sin β|≤B²/(2Q)
следует из 1−|cos β|≥sin²β/2 и completion of the square. Ограничение β малой окрестностью кратных π не используется.

## 7 Новые явные tail prefactors

Эти derivations проверены независимо, а не только сравнены с checker output.

Для εE интегрирование пяти абсолютных членов extended kernel даёт
a²G(T)[2/π²+1/π³+2/(3π)+a²/(3π³)].
При π>3,a≤1/10 bracket≤3901/8100<1. Поэтому εE<a²eₐ и тем более ≤6a²eₐ.

Для εD получается
eₐ[1/(2πa²)+11/(6π)+a²(1/π²+1/(3π))].
После умножения bracket на a² endpoint upper bound равен 108/625<4. Значит εD<4a⁻²eₐ.

На reflected half ρ≤1/(πu), поэтому |k|≤1+2/π<5/3. Отсюда
D₂≤20a²exp(−π²/(8a²))/(3π²).
Prefactor≤1/135<4, π²/8>1/2, следовательно D₂<4eₐ.

Combined error/a⁴≤14a⁻⁶eₐ. Монотонность и 14·10⁶(3/8)⁵⁰<1/10000 закрывают хвост равномерно до a↓0. Вместе с 2/(45π) это меньше cR=3/200.

## 8 Cutoff budgets и стыки

Из cₐ>a/3,6a≤1 и определения xE следует ξ≤a⁻² в нужной области. xE>1: cₐ<(2/5)(1/10)<1/2.

Positive Taylor sum точно даёт log30<7/2; монотонность a log(3/a) даёт ax²<7/10 и ax<27/100 при x≤xE.

Воспроизведены все margins:
upper small 116443/1620000;
upper large 12427271/877500000;
lower near 31703/1620000;
lower far 10559/810000;
lower large 5227271/877500000.

Положительный lower-sign term axφ(x)/3 в большом диапазоне покрыт 16u/195.

Upper coverage: [0,a] affine, [a,1] и [1,xE] Prawitz, [xE,∞) probability/Mills.
Lower coverage: [0,a] trivial, (a,9a/5] bridge, [9a/5,1] и [1,xE] Prawitz, [xE,∞) Hoeffding.
На ξ=3 обе small-range lower estimates применимы. Все прочие стыки включены.

Bridge использует 2x≤9/25<1 и положительный bracket 4459/37500. x=a и нулевая точка не требуют limit argument. Hoeffding bounds нестрогое |X|≥x, сохраняя strict central event, включая x=xE.

## 9 Full CDF

Для t>0 положим U(t)=P(|X|≤t), L(t)=P(|X|<t). Получено
H(t)−H(a)≤L(t)≤U(t)≤H(t)+H(a).
Симметрия даёт F(t)=(1+U(t))/2, F(−t)=(1−L(t))/2. Эти формулы и L≤U дают обе стороны на обеих полуосях. При нуле F(0)=(1+P(X=0))/2, а weak upper-central bound контролирует атом. Непрерывность F не предполагается.

## 10 Rational backend

Fraction arithmetic точна; directed dyadic rounding корректен и для отрицательных значений; multiplication берёт четыре endpoint products; reciprocal отвергает знаменатель с нулём; sqrt использует integer square roots с безопасным верхним концом.

exp(−x) строится через y=x/1024∈[0,1), degree-100 positive Taylor sum и tail t₁₀₁/(1−y/102), затем reciprocal и integer power1024. Решения используют exact fractions, не Decimal displays.

Machin bounds имеют правильную чётность partial sums и направления при вычитании. Отдельная проверка tangent identity и ветви прошла. sqrt/exp probes сопоставлены с точными rational inequalities; exp использовал независимую alternating-series enclosure.

Float literals в checker’ах отсутствуют. Новый finite certificate не зависит от MPFI/MPFR, утраченного header или executable.

## 11 Отдельный большой helper

Изолирование фактического максимума X=aε+Y корректно. Для 0≤x<a central event после conditioning строго лежит в Y<0 даже при атомах. При x=a отдельно используется вероятность≤1.

Taylor lower bound и rational φ0 lower bound дают
H(27/40)>229520461865155173/458752000000000000>1/2.
Принят только weak upper-central helper. Lower-central информация из него не выводится.

## 12 Provenance

Новый аудит относится к новым reconstructed bytes. Исторические hashes и старый MPFI replay не означают восстановления старых файлов. Downloaded author code и внешний numerical certificate не исполнялись.

Аудит основан на двух установленных внешних теоремах, проверенных аналитических выводах, exact algebra и rational outward arithmetic. Это не proof-assistant formalization.

Математический и свежий file-level acceptance завершены. Оставшаяся операция упаковки отчёта/verdict/manifest не меняет проверенный primary.

