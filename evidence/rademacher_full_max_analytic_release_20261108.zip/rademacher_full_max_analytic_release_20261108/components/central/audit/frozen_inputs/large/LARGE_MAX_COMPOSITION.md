# Complete analytic composition for actual maximum m>=27/40

Date: 2026-11-08. Status: conditional primary composition; PROOF.md and TAIL.md still require independent audit. This file does not itself declare acceptance.

## Frozen accepted upper input

The previously accepted elementary weak upper-central helper is copied unchanged under frozen_inputs/:

- UPPER_HELPER_PRIMARY.md, section "Separate elementary upper bound for large coefficients", SHA-256
  07bd75b6e73e85f962e8efd7e10259f3a394d520d5afc84644d5f8e8b25fb2be.
- UPPER_HELPER_AUDIT.md, section 11, SHA-256
  413e0bb71b1336cc480d953be06847698e1612d27b157c63de1ef2a25b056560.
- UPPER_HELPER_VERDICT.json, separate_helper_scope, SHA-256
  a7242979d720f104db0761d1cb95406620563900606e6c473a89a861d207f216.

The source's historical statement that its helper alone does not prove the lower side remains correct. The new lower proof below is a separate input. Other source sections and its old numerical/checker counts are not additional hypotheses of this composition.

The retained exact constant is

    H(27/40)
      > 229520461865155173/458752000000000000 > 1/2.

Its accepted analytic proof uses phi(0)>19947/50000 and the integrated alternating Gaussian polynomial through degree seven. The primary and audit identify the Machin-series verification of that elementary constant. No old signed-integral certificate is imported or rerun.

## Proposed complete theorem on the large-maximum range

Let X=sum_{i=1}^n a_i epsilon_i, where the signs are independent and uniform, the coefficients are real, sum a_i^2=1, and the ACTUAL maximum is

    m=max_i |a_i|>=27/40.

Then, conditional on independent acceptance of the new inputs,

    |P(X<=y)-Phi(y)|<=Phi(m)-1/2  for every real y.       (T)

Dimension is arbitrary finite, coefficient signs and zero coefficients are allowed, and all CDF endpoints retain their atoms.

### Upper-central inequality, all x>=0

Absorb the sign of a maximum coefficient into its Rademacher sign, and write X=m epsilon+Y. The law of Y is symmetric. For 0<=x<m,

    P(|X|<=x)=P(|m+Y|<=x)<=P(Y<0)<=1/2<H(m)<=H(x)+H(m).

For x>=m,

    P(|X|<=x)<=1<2H(m)<=H(x)+H(m).

Thus the weak upper-central bound holds everywhere, including zero and x=m.

### Lower-central inequality, all x>=0

Since 27/40>2/3, split the thresholds as follows:

1. On 0<=x<=m, H(x)-H(m)<=0 and the strict central bound is automatic.
2. On m<x<=7m/6, use the independently accepted reflection/half-weight bridge from the prior release. It proves P(|X|<2m)>=87m/(64pi) and consequently the target on this interval, including x=7m/6.
3. On 7m/6<=x<=2m, use the new integral inequality PROOF.md with p=1/m^2 and xi=x/m. It proves the strict lower-central target on the whole closed interval, conditional on its pending audit.
4. On x>=2m, use TAIL.md. Chebyshev gives the strict central event bound, with a positive Gaussian comparison margin established uniformly for m>=2/3. The endpoint x=2m is included.

There is no uncovered join. Hence

    P(|X|<x)>=H(x)-H(m) for every x>=0.

### Full CDF conversion

For x>0 and F(y)=P(X<=y), symmetry gives

    P(|X|<=x)=2F(x)-1,
    P(|X|<x)=2F(x-)-1,
    F(-x)=1-F(x-).

The upper-central estimate bounds F(x) from above. The strict lower-central estimate bounds F(x-) from below, hence also F(x). Together they bound the discrepancy on positive arguments. Monotonicity F(x-)<=F(x), together with the same two estimates, bounds both endpoints at x and therefore transfers both sides to -x through the third identity.

At zero, symmetry gives F(0)=1/2+P(X=0)/2. The weak upper-central estimate gives P(X=0)<=H(m), proving the required bound there. This establishes (T) without assuming a continuous law.

## Exact scope remaining after acceptance

The new ingredients would establish:

- Lower-central target for 0<=x<=2m for every m in (0,1].
- Entire lower-central target for every m>=2/3.
- Full original CDF theorem, without the large signed-integral certificate, for m>=27/40.

The separately accepted analytic theorem for m<=3/20 remains available. These statements do NOT cover the middle range 3/20<m<27/40 completely. They do not prove the unrestricted q strengthening. No priority or formal proof-assistant claim is made.

## Required new independent audit

Review PROOF.md, TAIL.md and this composition, including the Gamma integral, the positive phase remainder, polynomial identities, strict-event conventions, the accepted helper hash binding, and all threshold joins. check_algebra.py is only a primary exact-arithmetic diagnostic and is not independent acceptance. The complete old certificates must not be rerun or treated as an analytic premise.
