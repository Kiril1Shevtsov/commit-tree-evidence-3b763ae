# Independent audit: paired-integral closure and large-maximum theorem

Date: 2026-11-08. Auditor: independent native worker assigned to audit the submitted proof, not its author.

## Verdict

**PASS. No mathematical gap, false identity, parameter-coverage gap, or endpoint error was found. No primary-file correction is required.**

Accepted new statements, with H=2Phi-1:

1. For every real p>=1 and every real xi in [7/6,2], the submitted paired integral satisfies

       (2/pi) integral_0^(pi/2) [-c_xi(v/pi)] cos(v)^p dv
         > H(xi/sqrt(p))-H(1/sqrt(p)).

2. Combining this with the frozen, previously audited reflection/Prawitz/half-weight bridge, every finite normalized independent Rademacher sum X with actual maximum m satisfies

       P(|X|<x) >= H(x)-H(m),  0<=x<=2m,  0<m<=1.

3. The Chebyshev argument proves the remaining lower-central tail x>=2m for m>=2/3. Consequently the entire lower-central statement holds for m>=2/3.

4. Combining that lower result with the frozen elementary upper helper proves

       |P(X<=y)-Phi(y)| <= Phi(m)-1/2

   for every real y and every actual maximum m>=27/40, in arbitrary finite dimension, with unequal coefficients, zeros, signs, and all atoms retained.

The strict inequality in statement 1 and the strict-event convention in statements 2–3 must not be confused. The resulting lower probability comparison is strict when x>m. At x=m, only >= is asserted and equality can occur (for example X=+/-1). At x=0 the lower target is automatically nonpositive.

This audit does **not** establish the unrestricted analytic max theorem or the fourth-mass q strengthening. In particular the entire full-CDF middle sector 3/20<m<27/40 is not closed by this package. The prior analytic small-coefficient result is not re-audited here.

## 1. Sources, independence and integrity

The primary candidate is `/workspace/shared/rademacher_max_paired_integral_closure_20261108`. Read and reviewed PROOF.md, TAIL.md, LARGE_MAX_COMPOSITION.md, their SOURCE_HASHES.json, and the three frozen upper-helper inputs. The separate retained input packet is `/workspace/shared/rademacher_max_reflection_bridge_release_20261108`; its primary reflection, bridge and sign proofs, independent audits, external-input statement, status, and relevant source-contract sections were inspected.

All 8 entries in the candidate SOURCE_HASHES.json and all 14 entries in the accepted release MANIFEST.json match their actual bytes. Both manifests themselves are additionally hashed. All 24 files, including the two manifests, have been copied into `frozen_sources/`; `FROZEN_SOURCE_HASHES.json` binds each copy to its original location and digest. The original source files were not edited. The final integrity check compares the originals and frozen copies again.

Key reviewed primary hashes:

- Candidate PROOF.md: `3ce8f25521dfb933e2d0e11c1980b6597d8546706f612162b313ecedda225e81`.
- Candidate TAIL.md: `0df22380af8d49f4e4bba1abc44035a6df94b94ca86cfd7674535cc1094fbe95`.
- Candidate LARGE_MAX_COMPOSITION.md: `a06d0ee2454a401e98c03fe3072bdfb7a1d09df29fadaca9203606294a53e854`.
- Retained reflection primary: `4e54fe019cdfb457940de048aab5202e087aa99ac9f53786f78141b550e085bf`.
- Retained bridge primary: `db626c447e913247fd2acf0624bf6b21d28c0fffdc09de59583fd71a073938af`.
- Retained sign-pattern primary: `6843b2cc84470eb10ea25d29c5a4bddf38b6a77b094f36ed096cfe3648281009`.

The upper helper primary/audit/verdict hashes match all three values quoted in the composition. Its older main small-coefficient theorem and numerical audits are not imported into the new large-maximum proof. Likewise the frozen Prawitz and half-weight provenance reports contain old computational results; only their identified analytic input statements and endpoint conventions are retained here.

The primary `check_algebra.py` and old numerical certificates were **not executed**. No quadrature, coefficient search, parameter grid, or floating acceptance comparison was used. The new `independent_exact_algebra.py` was independently authored from the displayed mathematical expressions, using Python Fraction polynomial arithmetic. Its 31 finite exact checks pass. These checks supplement the analytic review below; neither their count nor their successful exit replaces the proof.

## 2. Phase identities, independently derived

Write s=sin v, c=cos v, h=pi delta/2, d=delta(pi/2-v), A=delta v=h-d and B=delta(pi-v)=h+d. Direct cancellation in the original cotangent kernel gives

    k1=-(1-v/pi) sin A/s - sin(v+A)/pi,
    k2=-(v/pi) sin B/s - sin(v-B)/pi.

For F=k2-k1, isolate sin A/s and use

    sin A+sin B=2 sin h cos d,
    sin(v+A)-sin(v-B)=2 sin h cos(v-d).

Thus, with R=v/s-c and C=2 sin h/pi,

    F=sin A/s + C[-(v/s)cos d + cos(v-d)]
     =sin A/s - C R cos d + C s sin d.

For E=-k1-k2, use

    sin B-sin A=2 cos h sin d,
    sin(v+A)+sin(v-B)=2 cos h sin(v-d).

With D=2 cos h/pi this yields

    E=sin A/s + D[(v/s)sin d+sin(v-d)]
     =sin A/s + D[R sin d+s cos d].

These are exactly (1)–(2). Algebraically W=-k1-|k2|=min(F,E), without any sign assumption on k2. R>=0 because Q=v-sin v cos v has Q(0)=0 and Q'=2sin²v>=0. All other factors used as nonnegative lie in their stated first-quadrant ranges.

At v=0 the removable limits are F=E=W=delta. At v=pi/2, F=W=0 and E=sin h+2cos h/pi. Thus the endpoint extension is correct; no singular boundary term is integrated.

## 3. Monotone quotient and kernel lower bounds

For 0<delta<=1, put N=sin(delta v)-delta sin v cos v and Q=v-sin v cos v. For 0<v<pi/2,

    N'/Q'=delta[1-(sin(delta v/2)/sin v)^2].

Let alpha=delta/2 in (0,1/2]. The logarithmic derivative of sin(alpha v)/sin v equals

    [alpha v cot(alpha v)-v cot v]/v >0.

Indeed (z cot z)'=(sin z cos z-z)/sin²z<0 on (0,pi/2), as already proved by Q>0. Hence N'/Q' is decreasing.

Since N(v)=integral_0^v (N'/Q')(t)Q'(t)dt and Q(v)=integral_0^v Q'(t)dt, N/Q is the weighted average of a decreasing function. More explicitly,

    (N/Q)'=(Q'/Q)[N'/Q'-N/Q]<=0.

Therefore N/Q at v is at least its value at pi/2, namely 2sin(pi delta/2)/pi=C. Multiplication and division by the positive denominators give

    sin(delta v)/sin v-C R(v)>=delta cos v.

No unproved rule for ratios is being assumed here. Delta=0 follows directly, and the two v endpoints follow by the displayed limits.

In F, rewrite -C R cos d=-C R+C R(1-cos d), discard the latter nonnegative term, and use concavity sin(delta w)>=delta sin w=delta cos v. This gives

    F>=delta cos v+delta C sin v cos v.

In E, both D terms are nonnegative and sin(delta v)>=delta sin v; hence E>=delta. Since delta>=delta cos v, min(F,E)>=delta cos v throughout delta in [0,1].

For delta<=1/2 the accepted sign input has k2<=0. It can also be checked immediately from

    -pi k2=sin B R(v)+sin v cos B>=0,

because B<=pi/2. Therefore W=F on this subrange. The decreasing sinc function gives

    C/delta>=2sqrt(2)/pi>49/55>8/9,

using sqrt(2)>7/5 and pi<22/7. This proves the claimed stronger estimate

    W>=delta cos v+(8/9)delta² sin v cos v.

It is valid at delta=0 by continuity and at both v endpoints. The actual target only needs delta>=1/6.

## 4. Gamma-ratio estimate

The beta integral gives

    A(p)=(2/pi)integral_0^(pi/2)cos(v)^(p+1)dv
        =Gamma((p+2)/2)/(sqrt(pi)Gamma((p+3)/2)).

For R_G(z)=sqrt(z)Gamma(z)/Gamma(z+1/2), the usual digamma difference integral is

    psi(z+1/2)-psi(z)=integral_0^infinity e^(-zt)/(1+e^(-t/2))dt.

Subtracting it from 1/(2z) yields

    (log R_G)'(z)=-(1/2)integral_0^infinity e^(-zt)tanh(t/4)dt.

The standard Gamma-ratio asymptotic R_G(z)->1 fixes the integration constant. Integrating from z to infinity, with nonnegative integrand or an elementary dominated/Fubini justification, proves (8). Near t=0 its integrand has a finite limit; at infinity it is exponentially integrable for z>=1.

The global bound tanh u>=u-u³/3 is valid: the derivative of their difference is u²-tanh²u>=0, since 0<=tanh u<=u. It gives

    log R_G(z)>=a-b, a=1/(8z), b=1/(192z³).

For z>=1, b<=a/24. Consequently

    (a-b)²/2>=529/(73728z²)>=1/(192z³)=b,

where the second inequality is 529z>=384. Since a-b>0, the positive exponential Taylor bound gives R_G>=1+a. There is no small-u restriction on the tanh bound and no asymptotic truncation used as an inequality.

At z=(p+2)/2, this proves (9). To compare its right side with B(p)=1-3/(4p)+1/(3p²), note that B(p)>0 for p>=1. The squared difference is exactly

    [9p^5(4p+9)²-(12p²-9p+4)²(p+2)³]
      /[144p^4(p+2)³]
      =N1(p)/[72p^4(p+2)³].

Direct expansion produces the submitted N1. Independently shifting by p=1+t gives

    N1(1+t)=99+774t+1656t²+1510t³+525t⁴+60t⁵.

All coefficients and the denominator are positive on t>=0. Thus the squared comparison, then the unsquared comparison, are valid. This proves (7) for every real p>=1, not merely integer dimensions.

## 5. Continuous-parameter comparison and exact polynomial certificates

Writing the Gaussian increment as delta sqrt(2/pi)/sqrt(p) times the mean of exp(-r²/(2p)) over [1,1+delta] is exact. The global Taylor inequality exp(-y)<=1-y+y²/2 for y>=0 yields the specified mean bound. Direct integration gives mu2=1+delta+delta²/3 and mu4=1+2delta+2delta²+delta³+delta⁴/5.

For delta>=1/2 this mean is no larger than its value at 1/2: adding points to the right adds values no greater than the previous mean. At 1/2 the exact moments are 19/12 and 211/80. After using the Gamma estimate and W>=delta cos v, the residual is at least

    sqrt(2/pi)delta/sqrt(p) [1/(24p)+7/(1920p²)]>0.

This includes delta=1 and p=1.

For delta<=1/2, integrating the extra phase term is exact because

    integral_0^(pi/2)sin v cos(v)^(p+1)dv=1/(p+2).

The candidate residual (12) follows with a=1/4-delta/2-delta²/6 and b=1/3-mu4/8. Since mu4 increases with delta>=0, b>=7/1920. Since a decreases, a<=a(7/16)=-1/1536 when delta>=7/16; that entire subrange has positive residual.

For 1/6<=delta<=7/16, direct differentiation of Z=(ap-b)/delta gives

    Z'=-(6p-5)/(24delta²)+(1/4-p/6)+delta/4+3delta²/40.

Its derivative in p is -1/(4delta²)-1/6<0. At p=1, its derivative in delta is 1/(12delta³)+1/4+3delta/20>0. Its maximum on the required rectangle is therefore at (p,delta)=(1,7/16), where it equals -15991/1505280<0. Hence Z decreases in delta and

    Z<=6(a0p-b0), a0=35/216, b0=8249/51840.

Dividing (12) by delta² proves that (13) is sufficient. Here a0p-b0>=a0-b0=151/51840>0, so both sides of (13) are positive and squaring is reversible. The squared comparison is

    256p^5>5832pi(p+2)²(a0p-b0)².

Replacing pi by the strictly larger 22/7 is conservative. Independent multiplication gives exactly the displayed N2 after multiplying by 1612800. For p>=2, t=p-2>=0 gives

    N2(2+t)=343007824+1312022312t+7165469989t²
              +8725567200t³+3352608000t⁴+412876800t⁵,

which is strictly positive.

For 1<=p<=2 put t=p-1. If N2(1+t)=sum_j c_j t^j, the degree-five Bernstein coefficients are independently computed by

    B_k=sum_(j=0)^k c_j binom(k,j)/binom(5,j).

This gives exactly

    (410619501, 3864833439/5, 1665757427/2,
     5347458981/10, 403016808/5, 343007824).

All are positive. The nonnegative basis binom(5,j)t^j(1-t)^(5-j) sums to one, so N2 is at least the smallest B_j on [0,1], including t=0 and t=1. This is a continuous positivity proof, not six sampled function values. The independent checker also expands the Bernstein representation back to the monomial polynomial and verifies exact equality.

Thus both p ranges meet at p=2 with a positive value. The delta ranges meet at 7/16 and 1/2 with overlap. Delta=1/6 is included, and no limiting passage at p=infinity is required: normalization gives a finite p=1/m² for each m>0. The complete closed parameter rectangle is established.

## 6. Chebyshev tail, independently checked

The function t³phi(t) is maximized at sqrt(3), by direct differentiation. Since sqrt(3)<2, phi(0)<2/5, and exp(3/2)>3,

    sup_(t>0)t³phi(t)=3sqrt(3)phi(0)e^(-3/2)<4/5<1.

Thus both derivative signs in TAIL.md are strictly positive. Specifically,

    F'(m)=2phi(m)+4[(2m)^(-3)-phi(2m)]>0,
    G_m'(x)=2[x^(-3)-phi(x)]>0.

The anchor is exact: by decreasing Gaussian density,

    H(4/3)-H(2/3)<=4phi(2/3)/3
      <(8/15)e^(-2/9)<24/55.

Here exp(2/9)>1+2/9, so the last inequality has the correct direction. Therefore

    F(2/3)>7/16-24/55=1/880.

For all m>=2/3 and x>=2m, G_m(x)>=F(m)>0. Markov applied to the weak event X²>=x² gives

    P(|X|<x)=1-P(X²>=x²)>=1-1/x²>H(x)-H(m).

This uses only E[X²]=1. There is no missing factor two and no loss of atoms at x. In particular x=2m is covered.

## 7. Retained inputs, joins and full CDF conversion

The retained reflection input pairs actual frequencies, not independent envelopes. At T=pi/m, the factor relation |cos(r(pi-v))|<=cos(rv), r=|a_i|/m<=1, gives |f(T-t)|<=f(t). The lower low-band envelope is f(Tu)>=cos(pi u)^(1/m²). Since c<=0 on xi in [1,2], multiplication reverses that envelope comparison in the required direction. Hence

    P(|X|<x)>=-2J(x)>=-2J_pair(m,xi)
      =(2/pi)integral_0^(pi/2) W_xi(v)cos(v)^p dv.

The new integral target is exactly H(x)-H(m) when p=1/m² and xi=x/m. Its covered x interval is the closed [7m/6,2m]. The Prawitz input is the strict-tail form of Keller–Klein Theorem 4.5, (39)–(40); no new theorem about its proof is asserted here.

The previously accepted bridge uses Keller–Klein Lemma 3.7 with half-weight interval masses. Its hypotheses hold at (-m,m,m,2m), giving W(-2m,2m)<=3W(-m,m). For x>m, P(|X|<x)>=W(-m,m), and W(-2m,2m)>=P(|X|<2m). The source bound P(|X|<2m)>=87m/(64pi) therefore yields P(|X|<x)>=29m/(64pi). The exact Gaussian comparison margin 203/1408-2/15=229/21120>0 proves the target on (m,7m/6]. For x<=m the target is nonpositive; no half-weight-to-strict comparison at x=m is used.

The interval joins at m, 7m/6 and 2m are therefore covered with their correct endpoints. Since 27/40>2/3, the tail applies throughout the proposed large-maximum sector.

For completeness, the elementary upper helper has also been rechecked directly. Write X=m epsilon+Y, where Y is independent and symmetric. Then for x<m,

    P(|X|<=x)=P(|m+Y|<=x)<=P(Y<0)<=1/2.

The containment is strict in the sign of Y even at boundary atoms, because the upper endpoint -m+x is negative. At x>=m the probability is at most one. The bound H(27/40)>1/2 makes these respectively at most H(x)+H(m), and below 2H(m)<=H(x)+H(m).

The retained elementary constant is independently verified, not assumed from an old numerical table. Machin's identity pi=16atan(1/5)-4atan(1/239) follows by the tangent addition formula and the angle lying in (0,pi/2). Alternating arctangent sums give 157/50<pi<355/113. Thus phi(0)>19947/50000, since

    1-2(355/113)(19947/50000)²=320561/28250000000>0.

Integrating the global Taylor lower bound e^(-y)>=1-y+y²/2-y³/6 gives, at b=27/40,

    H(b)>2(19947/50000)(b-b³/6+b⁵/40-b⁷/336)
        =229520461865155173/458752000000000000>1/2.

For the final CDF conversion, at each t>0 define L=P(|X|<t), U=P(|X|<=t). The now proven inequalities are

    H(t)-H(m)<=L<=U<=H(t)+H(m).

Symmetry gives F(t)=(1+U)/2 and F(-t)=(1-L)/2. These immediately yield both discrepancy bounds on both half-lines. At zero F(0)=1/2+P(X=0)/2, and the upper-central inequality at zero controls the atom. No continuity hypothesis, unverified limiting equality, or omission of a negative-side atom occurs.

## 8. Meaning of analytic acceptance and boundaries

This is a mathematical analytic proof with explicitly displayed finite rational identities. Computer algebra was used to independently check those finite identities and source integrity, but the logical sign proofs are finite expansions, coefficient positivity, monotonicity, standard Gamma identities, and the two stated external analytic probability theorems. They do not require a numerical integration certificate, cell grid, exhaustive coefficient search, or a dimension cutoff. In that precise sense the accepted large-maximum theorem is computer-free.

This is not a formal proof-assistant verification and does not prove originality or priority. It does not replace the actual maximum by a fourth-mass scale. It does not silently import the older numerical all-parameter theorem from the provenance reports. The unresolved full analytic middle sector remains unresolved by this deliverable.

No unresolved blocker remains for the four explicitly accepted statements at the start of this audit.
