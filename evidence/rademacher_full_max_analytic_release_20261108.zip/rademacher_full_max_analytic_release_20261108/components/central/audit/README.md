# Full central upper: independent PASS

Accepted statement: for every finite normalized independent Rademacher sum with actual maximum m, P(|X|<=x)<=H(x)+H(m) for every 0<=x<=m and every 0<m<=1. Atoms and all parameter joins are retained.

- AUDIT.md: complete independent mathematical review and composition.
- VERDICT.json: machine-readable exact scope.
- frozen_inputs/ and FROZEN_INPUTS.json: unchanged primary/retained inputs and source hashes.
- independent_verifier.py: independently authored Fraction/polynomial verifier.
- INDEPENDENT_EXACT_RESULTS.json: 117 PASS checks (93 mathematics, 24 source-integrity checks).
- ARTIFACT_MANIFEST.json: final deliverable digests.

Reproduce the finite rational checks with:

    python independent_verifier.py

This does not execute a primary checker or use quadrature, a parameter grid, interval subdivision, or a numerical coefficient certificate. The analytic argument accepts the stated Prawitz inequality as an established external input. It is not a formal proof-assistant verification.

Combining this result with the separately accepted outer upper and global strict lower results closes the full analytic maximum-coefficient theorem. This packet alone does not independently certify those two other full components. It does not close the unrestricted fourth-mass q strengthening.
