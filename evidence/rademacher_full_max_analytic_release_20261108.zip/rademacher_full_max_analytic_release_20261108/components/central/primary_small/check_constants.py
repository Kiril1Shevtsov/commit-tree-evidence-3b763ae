#!/usr/bin/env python3
"""Finite exact arithmetic in the primary analytic proof; not formal verification."""
from fractions import Fraction as Q
from math import factorial, comb
import json

checks=[]
def check(name, condition, value=None):
    if not condition:
        raise RuntimeError(name)
    checks.append({'name':name, 'result':'PASS', 'value':str(value)})

# Bernstein identity for g'(m), with r=m^2 and r=t/4.
bs=[Q(1,6),Q(5,48),Q(1,24),Q(39,2048)]
observed=[Q(0) for _ in range(4)]
for j,b in enumerate(bs):
    for k in range(3-j+1):
        observed[j+k]+=comb(3,j)*b*comb(3-j,k)*(-1)**k
expected=[Q(1,6),-Q(3,16),Q(0),Q(245,6144)]
for i,(a,b) in enumerate(zip(observed,expected)):
    check('Bernstein expansion coefficient '+str(i),a==b,a)
for i,b in enumerate(bs):
    check('Bernstein positivity '+str(i),b>0,b)
g=Q(1,2)/6-Q(1,2)**3/4+Q(35,96)*Q(1,2)**7
check('g at one half',g==Q(225,4096),g)
check('c upper factor',Q(4,5)*g==Q(45,1024),Q(4,5)*g)
p=Q(157,50)
j=3*p*p/64+p/4-Q(9,16)-16/(9*p*p)
check('J half lower margin',j-Q(1,2)==Q(154736027,35494560000)>0,j-Q(1,2))
check('gain margin',Q(49,968)-Q(45,1024)==Q(827,123904)>0,Q(827,123904))
check('y+z ceiling',Q(1,3)+Q(1,45)==Q(16,45),Q(16,45))
check('exponential lower factor',1-Q(16,45)==Q(29,45),Q(29,45))
L=sum(Q((-1)**k*2**(k+1),(2*k+1)*factorial(k)) for k in range(8))
E=sum(Q(2**k,factorial(k)) for k in range(8))
check('Gaussian Taylor integral',L==Q(269294,225225),L)
check('exponential series',E==Q(155,21),E)
check('e squared lower margin',E-Q(59,8)==Q(1,168)>0,E-Q(59,8))
i6=15*L-Q(816,59)
check('sixth truncated moment',i6==Q(3636106,885885),i6)
check('sixth moment margin',i6-4==Q(92566,885885)>0,i6-4)
check('normalization lower coefficient',Q(232,2025)*Q(35,88)==Q(203,4455),Q(203,4455))
d=Q(203,4455)-Q(1,336)
check('d exact',d==Q(21251,498960)>0,d)
slope=-Q(163,480)+d/2
check('decreasing bracket',slope==-Q(158813,498960)<0,slope)
end=Q(1,12)-Q(163,1920)+d/16
check('positive bracket endpoint',end==Q(8777,7983360)>0,end)
check('Archimedes lower supports pi>157/50',Q(223,71)>Q(157,50),Q(223,71)-Q(157,50))
out={'status':'PASS','checks_count':len(checks),'checks':checks}
print(json.dumps(out,indent=2))
