# Independent analytic audit of the small-q weak upper-central theorem

Date: 2026-11-08. Verdict: **PASS** for the exact source bytes pinned below.

For every finite independent Rademacher sum X with sum a_i^2=1 and q=sum a_i^4<=10^-6, the audited proof establishes

    P(|X|<=x) <= H(x)+H(sqrt(q)) for every x>=0.

This audit also accepts every item of COMMON_SIGNED_LEMMA.md, including its sharper minus-kernel head bound. It does not by itself establish the lower-central theorem, the composition into a full CDF theorem, any larger q range, or a novelty claim. Prawitz's theorem remains an explicit external theorem, not a theorem reproved here. The two required Fourier envelopes were independently rechecked from their mathematical derivations and agree with the existing audit. No primary checker was executed or used to substitute for an analytic argument. No sampling grid or numerical quadrature was used. The only auxiliary computation was independent exact rational addition of the displayed budgets.

## Frozen source hashes

SHA-256:

- rademacher_small_q_upper_analytic_20261108/PROOF.md: 6064ca96a113377aab3fae0a7c4d1858f6059c66349ec3552e9a5c9ca20aebd3
- rademacher_small_q_upper_analytic_20261108/COMMON_SIGNED_LEMMA.md: 05ca9a111db5995e37f7ae34548555c5af25b915aec7947730f1187d0dfa20cc
- rademacher_global_fourier_gate_20261108/PROOF.md: d6396d7b2205a50d1d5e862e58336de53a85e83e7680568fb50f8819e2687370
- rademacher_global_fourier_independent_audit_20261108/audit.md: 2b8c0006c2730ea08814d014146ccb006f5c27b38927b3730d3be0573c882e70

All paths here are relative to /workspace/shared. No primary file was modified. Existing max-coefficient proofs were read for provenance only; their coefficient assumptions are not imported into this theorem.

## 1. Smoothing normalization, sign and atoms

Theorem 4.5, equations (39)-(40), and the symmetric reduction in section 4.1.2 of Keller–Klein were checked directly at https://arxiv.org/html/2006.16834v4#S4.SS1.SSS1 on the audit date. They give a lower bound on the strict one-sided probability. For real even characteristic functions the kernel after pairing frequencies is (1-u)cos(Tuy)-rho(u)sin(Tuy). Taking y=-x therefore gives k_+. Symmetry gives exactly P(|X|<=x)=1-2P(X<-x), including x=0. The stated upper-central inequality P(|X|<=x)<=2J_+ follows, with no missing factor T. Taking y=x instead gives the corresponding strict lower-central smoothing form. Kernel singularities at zero are removable after the sine multiplication. Thus neither endpoint atoms nor the zero atom are discarded.

## 2. Uniform Fourier and moment hypotheses

Normalization implies 0<h=sqrt(q)<=1/1000, max|a_i|<=sqrt(h), and sum|a_i|^6<=h^3. The last inequality follows either from l^p monotonicity or by multiplying sum a_i^4=h^2 by max a_i^2<=h. Consequently |a_i s|<=1 throughout s<=r=h^-1/2. All low-frequency cosines are positive.

For completeness the bridge follows from z<=dist(z,pi Z)+z^2/pi and the Euclidean triangle inequality, giving ||dist(t|a|,pi Z)||_2>=t-t^2h/pi>=0 for t<=T. Squaring this nonnegative bound and using |cos z|<=exp(-dist(z,pi Z)^2/2) is legitimate.

The sharp reflected cosine envelope uses the convex function [-log|cos(sqrt(u))|]/u on pi^2/4<u<=pi^2. Its tangent at v^2, 3pi/4<=v<pi, produces a global quartic minorant because the intercept is below 1/2, the low-argument bound is z^2/2, and the tangent is negative beyond pi^2. Summing the quadratic and quartic terms uses precisely sum a_i^2 and sum a_i^4. At v=pi the bound is immediate. This verifies its use without any assumption max|a_i|<=h. Since r/T=sqrt(h)/pi<1/4, every reflected frequency T-s used in the proof lies in the permitted band.

The positive logarithmic cosine series yields both f<=G and f<=G P_h. The polynomial P_h=1-y+y^2/2, y=h^2s^4/12, is positive on the whole half-line, so extending its Gaussian integral cannot reverse an inequality. The Euler-product coefficients satisfy c_k<=(1/(2k))(4/9)^(k-1). Summing k>=3 at |z|<=1 gives 8/135<1/16 as the sixth-order remainder coefficient. Thus (6), including its h^3 term rather than an unjustified h^4, is valid.

In the middle, t(1-t/T)>=r/2 by concavity and r<=T/2, giving E_h=exp(-1/(8h)). The logarithmic derivative of h^-6 E_h is positive in the full range. At h=1/1000, 10^18 exp(-125)<10^-18<10^-6 by e>2 and 2^120>10^36. This verifies the uniform E_h<=h^6/10^6, also as h tends to zero.

## 3. Exact central pairing and the small central interval

Differentiation gives rho'(u)=-[sin(pi u)cos(pi u)+pi(1-u)]/sin^2(pi u). The numerator is nonnegative by y-sin(y)cos(y)>=0 with y=pi(1-u). The endpoint limit rho(1)=0 proves rho>=0. Cotangent partial fractions give rho<=1/(pi u).

Direct substitution, not an inequality, gives

    R(u)+R(1-u)=u(1-u)[cot(pi u)+cot(pi(1-u))]+1/pi=1/pi.

The nonnegative majorant weight is (1-u)+TxR(u). Pairing s and T-s using the same positive GP_h bound yields exactly 2(h+x)/pi times the head integral. Its full Gaussian moment value is c(h+x)(1-h^2/4+35h^4/96). The middle is bounded by (1+2x/h)E_h<=3E_h; integrating the weight over a larger interval is valid because it is nonnegative.

Concavity gives H(x)>=xH(h)/h for 0<=x<=h. The target is therefore at least c(h+x)(1-h^2/6). The difference is at least 3h^3/64-3E_h>0 because 1/12-35h^2/96>=1/16 and c>3/4. This includes both x=0 and x=h. There is no hidden reflection-sign or parity assumption.

## 4. Signed decomposition and Gaussian algebra

For h<=x<=x_*, the inequalities x_*^2<=6/h<=h^-2 imply xi<=h^-2. The uniform kernel bound 1+xi follows from rho<=1/(pi u). On the head, k(f-G)<=k^-(G-f) for either sign. Away from the head, bound the middle f contribution and the removed Gaussian contribution absolutely; the latter uses integral_r^infinity G<=G(r)/r. Their sum is at most 4h^-2 E_h. The reflected contribution is kept separately, so no head/end overlap occurs.

After putting s=Tu, the polynomial kernel is

    (1-hs/pi)cos(sx) + sigma[1/(hs)-hs/3+h^2s^2/(3pi)]sin(sx).

Its five integrals give exactly h phi(x)-h^2M/pi^2+sigma B(x)-sigma h^2x phi(x)/3+sigma h^3N/(3pi^2). Integration by parts yields D'=1-xD and N=x+(1-x^2)D. The integral representation of D gives D<=x and xD<=2. On x<=1, 0<=N<=2x; generally |N|<=I_2<4/3. All signs in (17) and item 3 of the common lemma follow.

The cotangent remainder obeys |(1-u)Q(pi u)|<=pi^3u^3/45 because (1-u)/(1-u^2/n^2)<=1. Its integral is at most 2h^4/(45pi). Gaussian extension past T has the stated absolute polynomial majorant. The four tail formulas yield precisely the prefactor 2/pi^2+1/pi^3+2/(3pi)+h^2/(3pi^3)<1, so epsilon_E<=h^2G(T)<=h^2E_h. Together with the middle, the extra exponential error is <=5h^-2E_h<=h^4/200000. Hence the common total is below h^4/50. These estimates are independent of sigma and x in the stipulated range.

## 5. Head, reflected trigonometry and the common lemma

The crude plus-head bound uses k_+^-<=1+xi and I_4=3I_0, I_6=15I_0. Since I_0/pi=phi0, its result is exactly phi0(1+xi)(h^3/4+15h^4/16).

For w<=1/2, rho(1-w)=(2w^2/pi)sum(n^2-w^2)^-1<=4pi w^2/9. Expanding sin(beta-beta w) and cos(beta-beta w), applying |sin(beta w)|<=beta w, and retaining |sin beta| and |cos beta| separately gives the stated three-term kernel bound for both signs. Integrating w,w^2,w^3 against G with w=hs/pi yields (20), in particular the coefficient 8xi h^4/(9pi^2). Completion of the square with Q=h^2/pi^2 and b=phi0 h^3(xi+4/9)/pi yields b^2/(2Q), exactly the square term in (22). No unfavorable sine term was dropped.

For the sharper minus-head bound, -k_-<=xi-1+u+(xs)^2/2; its right side is nonnegative when xi>=1, so it bounds k_-^-. Multiplying the low-frequency defect by each of these three terms gives, using I_5=8, I_7=48, I_6=15I_0, I_8=105I_0,

    phi0(xi-1)(h^3/4+15h^4/16)
    +2h^4/(3pi^2)+3h^5/pi^2
    +(5/8)phi0 xi^2h^5+(105/32)phi0 xi^2h^6.

Thus all six numbered items in COMMON_SIGNED_LEMMA.md pass, including their advertised signs and parameter domains.

## 6. Small signed interval budget

On h<=x<=1, the Gaussian Taylor bounds and D<=x, N<=2x give the leading term -phi0(6xi^2+xi-5)/12 after division by h^3. Since 6xi^2+xi-5-2xi^2=(xi-1)(4xi+5)>=0, division by xi^2 bounds it above by -phi0/6<-1/16. The fourth-power Gaussian correction is <=1/20. Each other term divided by h^3xi^2 is bounded respectively by h times

    1/9, 2/27, 1/15, 3/4, (2/25)(13/9)^2, 8/81, 1/50.

In particular, the cubic Gaussian correction uses x<=1 and the sixth-moment head uses (1+xi)/xi^2<=2. Independent exact addition gives C=10429/8100<2. The resulting negative margin is at least 1/16-1/20-2/1000=21/2000. It is uniform over xi>=1 subject to x<=1, not a grid calculation.

## 7. Large signed interval and final tail

For x>=1, exp(1/2)>=13/8 and the lower bound for B(h) imply [h phi(x)-B(h)]/h<=-15/104+h^2/15. The negative term -h^2x phi(x)/3 may be discarded. The function h log(3/h) increases on the whole range. Since e>8/3 and (8/3)^9>3000, log(3000)<9. Consequently h x_*^2<18/1000<1/10 and (h x_*)^2<18/10^6<1/10^4. The rectangle L=1/10, U=1/100 is therefore valid.

Re-expanding (22)/h gives exactly the displayed seven-term positive large budget. Its coefficients are nonnegative, so replacing h by v=1/1000, hx^2 by L and hx by U is a uniform comparison. Independent rational addition gives 29898355331/3240000000000<1/50, and its gap below 15/104 is 5686321380697/42120000000000>0.

Finally B(h)>=phi0 h(1-h^2/6)>h/3. Since x_*>1, for x>=x_* Mills' inequality gives 1-Phi(x)<=phi0 h/(3x)<h/3<B(h). Hence H(x)+H(h)>=1. The four closed regions [0,h], [h,1], [1,x_*], [x_*,infinity) cover every x>=0, with all joins included. No distributional continuity is assumed at any join.

## Final assessment

No mathematical correction is required for the audited upper proof or common signed lemma. The all-profile, all-finite-dimension, all-threshold upper-central theorem in the stated q-sector is supported by the frozen proof and explicit external Prawitz input. The proof does not depend on a numerical search, stability classification, coefficient cap proportional to h, or either reflection/bridge addendum needed for separate lower-side work.
