# Independent audit: complete outer weak-upper bound

Date: 2026-11-08. Verdict: **PASS**.

## Result and exact limits

For every finite deterministic real coefficient vector satisfying sum a_i^2=1, independent unbiased Rademacher signs, actual maximum m=max |a_i|, and x>=m, the submitted proof establishes

    P(|X|<=x) <= H(x)+H(m),   H(t)=2 Phi(t)-1,

whenever m>=3/20. The retained, independently accepted small-maximum theorem supplies 0<m<=3/20. Thus their composition establishes the **entire outer weak-upper region x>=m for every actual maximum**.

No mathematical error, false displayed identity, missing parameter region, incorrect inequality direction, or endpoint-atom loss was found. **No change to the primary proof is required.**

This is an outer-upper acceptance only. It does not establish the remaining central-upper interval 0<=x<m in the middle-maximum range, the full analytic max-coefficient Kolmogorov theorem, or any unrestricted q strengthening. In particular, a max-coefficient result cannot simply be relabeled as a q result. The new proof does not depend on the pending cap-defect reflection lemma.

Reviewed primary: frozen_sources/candidate/PROOF.md, SHA-256

    ab850f6df7bf0656a87a88bb9d96cb2de155a79cf2afbbeb58b9f515844fb12d

## 1. Integrity, accepted inputs, and independent verification

The entire new proof and its audit request were read. The actual-frequency reflection proof, its independent audit, the signed Prawitz input contract and source audit, the complete retained lower proof and audit, and the retained small-upper independent audit were also read. The lower proof is used here only for its elementary trigonometric inequalities; its lower-CDF theorem is not necessary to prove the new upper statement. The small-upper result is used only in the final composition for m<=3/20.

The external analytic smoothing input remains the cited Prawitz strict-tail theorem in Keller–Klein, Theorem 4.5, equations (39)–(40):

https://arxiv.org/html/2006.16834v4#S4.SS1.SSS1

Its proof is not reconstructed here. Its normalization and endpoint conventions are checked against the frozen source contract. Neither the half-weight interval comparison nor historical numerical pilot certificates are imported into the new outer proof.

All 40 entries in the submitted SOURCE_HASHES.json matched. The complete candidate directory, including that manifest, was frozen as 41 files under frozen_sources/candidate/. FROZEN_SOURCE_HASHES.json records the original directory and every frozen hash. INTEGRITY_CHECKS.json records the 40 comparisons.

The primary checker was neither read for its algorithm nor executed. The separately authored independent_exact_checks.py reconstructs both polynomial expressions from their mathematical definitions, converts them to Bernstein form by triangular elimination, and expands the resulting Bernstein sums back to the power basis. It verifies all 25 submitted coefficients, additional trigonometric identities, both Dawson residuals, all scalar constants, and the elementary joins. All **61 exact checks pass**. Only integers and fractions.Fraction are used. The saved primary 27-check results were inspected only after this independent reconstruction, as a completeness cross-check, not as proof evidence.

No numerical mesh, numerical quadrature, floating-point acceptance test, coefficient search, or old numerical witness is used by this audit or needed for the new proof. This is a mathematical/source audit with exact arithmetic, not proof-assistant formalization.

## 2. Weak Prawitz sign, scaling, reflection, and phase identities

Write f(t)=product cos(a_i t). The retained smoothing input is

    P(X<q) >= 1/2-J(q;T).

At q=-x, symmetry gives

    P(|X|<=x)=1-2P(X<-x) <= 2J(-x;T).

Thus the upper kernel has a **plus** sine term. The event is weak from the start: the atoms at both +/-x are retained. All thresholds in the new outer proof satisfy x>=m>0.

With T=pi/m, v=pi u, and r_i=|a_i|/m<=1, one has

    r_i v <= r_i(pi-v) <= pi-r_i v,
    |cos(r_i(pi-v))| <= cos(r_i v),   0<=v<=pi/2.

Multiplication gives |f((pi-v)/m)|<=f(v/m)=F(v), with F>=0. Pairing u with 1-u therefore bounds the integral above by the first-half integrand [k(u)+|k(1-u)|]F(pi u). Changing variables supplies the factor 2/pi, with no missing T factor.

Here is an independent derivation of both new phase identities. Set s=sin v, c=cos v, alpha=dv, beta=d(pi-v), d=x/m+1, and R=v/s-c. The first kernel becomes

    k(v/pi)=(1-v/pi)sin(alpha)/s+sin(alpha-v)/pi
            =sin(alpha)/s-[R sin(alpha)+s cos(alpha)]/pi.

For the second kernel, the angle is (d-1)(pi-v)=beta-pi+v, and cot(pi-v)=-cot v. Expanding yields

    k(1-v/pi)=[R sin(beta)-s cos(beta)]/pi.

The absolute value of its numerator is at most A=sqrt(s^2+R^2). Consequently

    k(v/pi)+|k(1-v/pi)| <= sin(alpha)/s+E_d(v)/pi,
    E_d=A-s cos(alpha)-R sin(alpha)>=0.

The last inequality is Cauchy–Schwarz for (s,R) and the unit vector (cos alpha,sin alpha). There is no assumed sign of the oscillating paired kernel.

On the half-band, all cosine factors are nonnegative and

    cos(v)^(1/m^2) <= F(v) <= exp[-v^2/(2m^2)].

The lower bound follows by summing log cos(rv)>=r^2 log cos v; the upper follows by summing log cos(rv)<=-r^2v^2/2. Endpoints follow by continuity. Near v=0, R=O(v^2), A=O(v), and sin(dv)/sin v has the finite limit d. All endpoint extensions used in (2)–(3) are legitimate.

## 3. Trigonometric inequalities and the global cosine deficit

The retained Taylor proofs of R<=2v^2/3 and v/sin v<=1+v^2/4 were checked independently by exact expansion. The remainder for the first bound has the positive rational lower margin 989/249480 when v^2<=5/2. The second bound follows from

    (1+v^2/4)S_7(v)-v
       =v^3[1/12-v^2/30+v^4(38-v^2)/20160],

where S_7 is the degree-seven sine lower polynomial. Since pi<22/7, v^2<=pi^2/4<5/2.

For the new lower bound on R, multiplication of the degree-five sine upper polynomial gives exactly

    (1+v^2/6+7v^4/360)S_5(v)-v
       =-v^7/540+7v^9/43200<=0.

Thus v/sin v>=1+v^2/6+7v^4/360. Subtracting the degree-four cosine upper polynomial gives R>=2v^2/3-v^4/45.

For the new reciprocal-sine upper bound, exact expansion gives

    (1+v^2/6+v^4/30)S_7(v)-v
       =v^5(2100-660v^2+37v^4-v^6)/151200>0.

Indeed 2100-660(5/2)-(5/2)^3>0. These uses of Taylor inequalities do not require an unproved decreasing-term assumption: the sine/cosine bounds follow by repeated integration from sin v<=v, or by the signed Taylor remainder on the indicated interval.

For the global deficit set a(v)=cos v exp(v^2/2), so 0<=a<=1. Then

    h(v)=a(v)-1+v^4/6,
    h'(v)/v^3=2/3-J(v),
    J(v)=exp(v^2/2)(sin v-v cos v)/v^3
        =integral_0^1 r^2 exp(v^2/2)sinc(vr)dr.

The integral identity follows by integrating r sin(vr). To check monotonicity, let t=vr. The derivative of t cos t-(1-t^2)sin t is t sin t+t^2 cos t>=0 on [0,pi/2], so t cot t>=1-t^2. Therefore

    d/dv log[exp(v^2/2)sinc(vr)]
      =v+r cot(vr)-1/v >= v(1-r^2)>=0.

The removable r=0 and v=0 cases follow by limits. Hence J is increasing and J(0)=1/3. The derivative of h can change sign only from positive to negative, so h has its minimum at an endpoint. The endpoint values are h(0)=0 and h(pi/2)=pi^4/96-1>0, the latter certified already by pi>157/50. Thus 1-a<=v^4/6.

For every real p>=1, convexity gives a^p>=1-p(1-a). Multiplying 1-a^p<=p(1-a) by G=exp(-pv^2/2) proves exactly

    0<=G-cos(v)^p <=(pv^4/6)G.

This holds at the cosine zero too and does not assume integer p.

## 4. Sine-sign split and both distinct exponential tails

Put a=pi/2, b=pi/d, p=1/m^2, and z=dm. On the half-band consider

    Delta=F(v)sin(dv)/sin v-G(v)sin(dv)/v.

If sin(dv)>=0, then Delta<=G(1/sin v-1/v)sin(dv). If sin(dv)<0, the lower bound F>=L and sin v<=v give

    Delta <=(G-L)|sin(dv)|/v <=(p/6)v^3G.

The negative set is contained in [b,infinity). Its resulting contribution after multiplication by 2/pi is at most

    p/(3pi) integral_b^infinity v^3G(v)dv
      =m^2[pi^2/z^2+2]exp[-pi^2/(2z^2)]/(3pi).

When d<=2, the negative set in the half-band is empty; the same positive bound is conservative.

On the positive-sine set use 1/sin v-1/v<=v/6+v^3/30. For the linear term, replace the positive-sine integral by the signed integral and add back its negative part. This costs at most

    m^2 exp[-pi^2/(2z^2)]/(3pi).

Extending the signed integral from [0,a] to [0,infinity) costs separately

    m^2 exp[-pi^2/(8m^2)]/(3pi).

The full signed linear integral is c0 m^2 z exp(-z^2/2)/6. The cubic term can be bounded on the whole half-line using |sin(dv)|<=dv; its contribution is c0 z m^4/10.

Finally the missing Gaussian sine-over-v integral has absolute value at most

    (2/pi) integral_a^infinity G(v)/v dv
      <=(2/pi)a^(-2) integral_a^infinity vG(v)dv
       =8m^2 exp[-pi^2/(8m^2)]/pi^3.

The full sine-over-v integral equals H(dm)=H(z), by differentiating in d and applying the Gaussian cosine transform. Combining these five losses gives exactly E(m,z) in (7). In particular, the tail beginning at the first negative sine interval depends on z, whereas the half-band cutoff tail depends on m. They are not conflated or omitted.

## 5. Phase majorant, nonnegative extension, and exact integration

Let s=sin v. Since A-s=R^2/(A+s)<=R^2/(2s), the trigonometric bounds give

    A-s <=2v^3/9+v^5/18.

Also s(1-cos(dv))<=v(1-cos(dv)). Combining the upper and lower bounds on R gives, for either sign of sin(dv),

    -R sin(dv) <=-(2/3)v^2 sin(dv)+(v^4/45)|sin(dv)|.

This proves (10) on the original half-band. Its first three terms are nonnegative on the entire half-line, since

    cos(dv)+(2v/3)sin(dv)
      <=sqrt(1+4v^2/9)<=1+2v^2/9.

The remaining two terms are nonnegative. Hence extending the majorant integral to infinity is valid even though the underlying trigonometric bounds on R are used only on the half-band.

The Dawson integral satisfies D'+zD=1, D(0)=0, by integration by parts. Differentiation under the Gaussian integral is justified by integrable polynomial majorants. In particular -D''=z+(1-z^2)D=N. Scaling v=ms therefore gives

    integral vG(v)(1-cos(dv))dv=m^2 zD(z),
    integral v^2G(v)sin(dv)dv=m^3 N(z).

The other moments are integral v^3G=2m^4 and integral v^5G=8m^6. Replacing |sin(dv)| by dv in its positive term contributes 8zm^5/45. The resulting bound, including its factor 2/pi^2, is exactly Q(m,z) in (8).

Although Q is expressed with a signed N term, its bracket is nonnegative: it equals the integral of the everywhere nonnegative majorant, plus the nonnegative excess introduced by |sin(dv)|<=dv. This justifies the later enlargement of its positive constant factor.

## 6. Monotonicity at fixed z and the two-boundary reduction

For fixed z>0,

    M/(c0m)=(1/m) integral_0^m f_z(t)dt,
    f_z(t)=exp(-t^2/2)-exp(-(z-t)^2/2).

On 0<=t<=z/2, f_z'(t)=-t exp(-t^2/2)-(z-t)exp(-(z-t)^2/2)<0. Its average decreases in m. Each term of E/m increases in m; the only nonpolynomial dependence requiring comment is m exp(-K/m^2), whose derivative is exp(-K/m^2)(1+2K/m^2)>0.

After differentiating the bracket of Q/m, discarding its additional nonnegative terms leaves

    q_m=zD-(4/3)mN+(4/3)m^2.

For R_-(z)=z/(1+z^2) and R_+(z)=z/(1+z^2/3), exact differentiation gives

    R_-'+zR_--1=-2z^2/(1+z^2)^2,
    R_+'+zR_+-1=2z^4/[9(1+z^2/3)^2].

The zero initial values and an integrating factor prove R_-<=D<=R_+ globally for z>=0. In particular D>0 for z>0.

If z<=1, then N>=z, so q_m is decreasing on 0<m<=z/2. At its right endpoint,

    q_(z/2)=[z(1+2z^2)D-z^2]/3
             >=z^4/[3(1+z^2)]>0.

If z>=1 and N<=0, positivity is immediate. If z>=1 and N>0, the lower bound on D gives N<=2z/(1+z^2), and completing the square gives

    q_m >=zD-N^2/3
         >=z^2(3z^2-1)/[3(1+z^2)^2]>0.

Thus Q/m increases, and B=(M-E-Q)/m strictly decreases on 0<m<=z/2.

For m<=3/5 and z<=7/4, its largest permitted m is min(z/2,3/5). This is exactly m=z/2 for z<=6/5, and m=3/5 for 6/5<=z<=7/4. No interior point of the two-dimensional domain remains to be checked after these two boundaries.

## 7. Scalar constants and the two exact polynomial identities

After factoring m^2, the coefficient of D in Q is

    z-(2/3)m(1-z^2)>0,   z>=2m>0.

For z<=1 it is at least z-(2/3)m>=2z/3, and for z>=1 it is plainly positive. Replacing D by D_+ therefore enlarges the bracket; the enlarged bracket remains nonnegative. Replacing 2/(pi^2 c0) by C=32/125 is consequently conservative. Squaring reduces the constant comparison to 2/pi^3<(32/125)^2, which follows from pi>25/8. Likewise c0>199/250 follows from pi<22/7.

On boundary (i), the common exponential tail is exp[-pi^2/(2z^2)]. Maximizing u^3 exp(-u) gives its upper bound 216z^6/(e^3 pi^6)<3z^6/250. Its combined prefactor is exactly pi/12+z^2/(3pi)+2z^2/pi^3, bounded above by 11/42+6z^2/35 using the stated rational pi bounds. The Gaussian Taylor estimates have the indicated directions. Thus L_1 is indeed a lower bound for (M-E-Q)/c0.

The independent construction verifies divisibility of (1+z^2/3)L_1 by z^3, degree eight of the quotient, and all nine printed Bernstein coefficients on [0,6/5]. Every coefficient is strictly positive. The removable value at zero is 1/12. The full power-basis and Bernstein coefficients are retained in INDEPENDENT_EXACT_RESULTS.json.

On boundary (ii), put u=pi^2/(2z^2). Differentiating u^2(2u+3)exp(-u) shows its unique positive maximum occurs at (3+sqrt(57))/4, between 21/8 and 53/20. A finite positive exponential series proves exp(21/8)>55/4. Therefore the maximum is below

    (53/20)^2(2(53/20)+3)/(55/4)
       =233147/55000<17/4.

It follows that (2u+3)exp(-u)<17z^4/pi^4<7z^4/40. Multiplication by m^2/(3pi c0), with 1/(pi c0)<2/5, gives 7m^2z^4/300.

For the second tail at m=3/5, the degree-nine positive exponential polynomial at (157/50)^2*25/72 exceeds 30, proving exp[-pi^2/(8m^2)]<1/30. Its prefactor divided by c0 is less than 7/15. This gives 7m^2/450. These are exactly (14), with no numerical normal table or exponential evaluation.

The upper bound exp(-z^2/2)<=1/(1+z^2/2+z^4/8) follows from the positive exponential series. Together with the signed Taylor bounds for the H terms it proves the claimed lower-bound direction for L_2.

Clearing the two positive denominators independently produces degree fifteen and exactly all sixteen printed Bernstein coefficients on [6/5,7/4]. Each is strictly positive. The reconstruction is an identity of rational polynomials, not agreement at sampled points. Since the Bernstein basis is nonnegative and sums to one on each closed interval, both boundary budgets are uniformly positive, including their joins. Monotonicity now proves the full stated region 0<m<=3/5, x>=m, z<=7/4.

## 8. Elementary large-z and large-maximum joins, with atoms

For 3/20<=m<=3/5 and z>=7/4, increasing H allows z to be reduced to 7/4. At that fixed z, H(m)+H(z-m) increases for m<=z/2 because its derivative is c0[exp(-m^2/2)-exp(-(z-m)^2/2)]>=0. Its minimum on the needed interval is at m=3/20. Exact evaluation of the degree-five integral Taylor lower bound gives

    (199/250)[U_5(3/20)+U_5(8/5)]-1
      =26224621137160720607/3892838400000000000000>0.

Thus the target upper bound is above one throughout this region.

For m>=3/5 and x>=9/10 the same conclusion follows from

    (199/250)[U_1(3/5)+U_1(9/10)]-1=6863/100000>0.

In the remaining large-maximum case, 3/5<=m<=x<9/10. Splitting off an attained coefficient gives X=m epsilon+Y, with sigma^2=1-m^2>0 and r=x-m>=0. Symmetry, including the possible atom at Y=0 when r=0, gives the exact identity

    P(|X|<=x)=[P(|Y|<=x+m)+P(|Y|<=r)]/2.

The fourth moment is E Y^4=3sigma^4-2 sum_{remaining i}a_i^4<=3sigma^4. Let A={Y^2>r^2}, a **strict** event. Since

    sigma^2 <=r^2+E[Y^2 1_A],
    E[Y^2 1_A] <=sqrt(E Y^4) sqrt(P(A)),

one obtains P(A)>=(1-r^2/sigma^2)^2/3. This argument bounds the strict complement of the weak event and preserves every atom at |Y|=r.

The ratio (9/10-m)^2/(1-m^2) has derivative

    2(9/10-m)((9/10)m-1)/(1-m^2)^2<0

on [3/5,9/10). Its value at 3/5 is 9/64. Hence

    P(|X|<=x) <=1-(55/64)^2/6=21551/24576.

The Gaussian target is at least 2H(3/5), and the independent exact margin is

    2(199/250)U_1(3/5)-21551/24576
      =8054617/384000000>0.

This proves the whole large-maximum outer branch. The case m=1 is already in the x>=9/10 trivial branch, so no division by zero occurs.

## 9. Coverage and final scope

For m>=3/20 and x>=m:

1. If m<=3/5 and z=x+m<=7/4, use the two-boundary analytic budget.
2. If m<=3/5 and z>=7/4, use the large-z trivial join.
3. If m>=3/5 and x>=9/10, use the large-x trivial join.
4. If m>=3/5 and x<9/10, use the strict-complement fourth-moment argument.

These cases exhaust the requested domain. The joins m=3/5, z=6/5, z=7/4, x=9/10, and x=m are included. The retained small-maximum upper theorem covers 0<m<=3/20 for every x>=0; the closed join m=3/20 is therefore covered twice. Normalization excludes m=0. Signs and zero coefficients cause no change in the argument.

The new Prawitz branch is weak-upper throughout. The elementary probability branch uses the strict complement |Y|>r. There is no replacement by a half-weight event, no removal of boundary atoms, and no distributional continuity assumption.

**Final verdict: PASS for the complete outer weak-upper theorem. With the accepted small-maximum input, outer upper is established for all actual maxima. The central-upper obligation and the unrestricted q conjecture remain separate.**
