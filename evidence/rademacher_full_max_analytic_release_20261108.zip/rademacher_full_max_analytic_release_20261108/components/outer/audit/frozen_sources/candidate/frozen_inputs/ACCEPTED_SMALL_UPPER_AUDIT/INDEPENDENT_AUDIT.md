# Independent audit: weak upper-central extension through 3/20

Date: 2026-11-07. Auditor: /root/audit_math_progress/audit_upper_point_fifteen.

## Verdict and exact scope

PASS for the actual frozen package `/workspace/shared/keller_klein_upper015_20261107`, with input hashes recorded in `AUDIT_VERDICT.json`.

For every finite independent Rademacher sum X with sum b_i^2=1, every 0<a<=3/20 satisfying max |b_i|<=a, and every x>=0, the proof establishes P(|X|<=x)<=H(x)+H(a). On 0<=x<=a it establishes the stronger subtraction (a^3+x*a^2)/50. Arbitrary unequal coefficients, an arbitrarily small positive a, and atoms are included.

This verdict does not establish strict lower-central or full-CDF bounds on a>1/10, accept complementary numerical witnesses, or make a priority claim. It is an independent mathematical/source audit with exact arithmetic, not proof-assistant formalization. It relies on the stated Keller–Klein/Prawitz smoothing theorem; that external theorem is not reproved here.

## Files and execution

Read the complete extension, base proof, base symbolic checker, affine checker, budget checker, and saved outputs. The copied base proof and symbolic checker are byte-identical to the previously audited reconstructed release. Reviewed the affine source diff: mathematical changes are precisely u=3/20, eta=10^-80, and AG/A1 threshold u/50; the interval arithmetic engine is unchanged. Reviewed all new budget-checker source.

Fresh executions used Python -B and PYTHONDONTWRITEBYTECODE=1. The base symbolic checker passed 93 checks; the affine checker passed 14; the new budget checker passed 23 in addition to replaying both prior groups. Both extension stdout JSONs matched the submitted saved JSONs byte-for-byte. All seven submitted source/result SHA-256 values matched before and after execution. No downloaded mathematical-author code was executed and no submitted file was modified.

The separately written `additional_checks.py` checks rational budgets, expanded large-interval formulas, tail prefactors, monotonicity, Taylor sums, absence of float literals, and all source hashes. Its fresh result is `ADDITIONAL_CHECKS.json`. The base and new output captures are in this audit directory.

## Analytic audit

### Affine interval and uniformity

The absolute-value Hölder reduction uses positive measure and exponents 1/b_i^2; its coefficient-profile cover has no grid or dimension restriction. The two profile intervals [a/2,9a/10] and [9a/10,a], together with the Gaussian branch, cover every nonzero coefficient. Central/reflected polynomial weights, truncation extension and the corrective central A tail remain valid at the enlarged endpoint. Their derivations do not use the old 1/10 cutoff.

Gaussian moment identities and the favorable discarded remainders are unchanged. Each retained nonconstant gap coefficient is nonpositive, so the new endpoint controls the whole interval. The positive tail Laurent powers have minima -5,-4,-5. For each summand a^q exp(-kappa^2/(2a^2)), differentiation gives the sign q+kappa^2/a^2. The new reflected endpoint margin exceeds 0.4154207962, so all tails increase up to 3/20 and vanish as a decreases to zero.

Fresh affine lower bounds include AG>0.1826952532 and A1>0.1757627315, each above u/50=0.003; BG>0.1127165234, B1>0.1201148871, A2>0.0239829934, and B2>0.021531349091266367, each above 1/50. Central tail/a^3<5.018860674608364e-91<1e-80. The normalized A thresholds correctly imply the common a^3/50 improvement. Concavity of H completes 0<=x<=a, including x=0 and x=a.

### Signed smoothing and enlarged tail budget

Reviewed the inherited plus-sign smoothing decomposition, D1 moments, reflected alias estimate and completion of the square. Signs and the weak-central event are unchanged. The Gaussian/log-cos and kernel inequalities do not impose the old cutoff; their only enlarged-domain dependencies are checked explicitly.

From c_a>=phi0*a*(1-a^2/6)>a/3 and 6a<=9/10, x_E^2<=2log(3/a)<=6/a<=a^-2, hence xi<=a^-2 wherever needed. The epsilonE and epsilonD prefactors are respectively bounded by 5203/10800<1 and, after multiplication by a^2, 43327/240000<4. D2 uses 20u^2/27<4 and pi^2/8>1/2. These are absolute error bounds and require no oscillatory cancellation.

Combined errors divided by a^4 are <=14a^-6 exp(-1/(2a^2)); its derivative is positive throughout the enlarged interval. At u, 1/(2u^2)=200/9>22, and e>8/3 yields the exact rational upper bound 4708235109375/9007199254740992<1/1500. Together with 2/(45pi)<16/1125, the remaining slack below c_R=3/200 is 1/9000. The obsolete 1/10000 remainder budget is not reused.

### Small and large signed regions

For a<=x<=1 the inherited plus-sign polynomial is valid. After division by xi^2 its negative constant is at most -3/16. The upper bound for all positive terms at u gives exact margin 300833/8640000>0. No minus-sign acceptance is inferred.

For 1<=x<=3/2, ax^2<=27/80 and ax<=9/40. The inherited baseline 15/104 and large upper budget yield margin 34933891/936000000>0.

For x>=3/2 up to x_E, the positive degree-four exponential sum at 9/8 is 100331/32768>3. Thus the baseline improves to 1/4, using phi0>3/8. The positive degree-eight sum at 3 is 89641/4480>20, so log20<3. Monotonicity of a log(3/a) yields ax^2<9/10; then (ax)^2<=u*(9/10)<(3/8)^2. The expanded positive budget gives margin 5335099/96000000>0. All rectangle substitutions preserve upper-bound directions because the budget coefficients are nonnegative.

### Cutoff, atoms and joins

The explicit c_a<3/50 gives x_E>1. Consequently for x>=x_E, Mills gives 1-Phi(x)<=phi(x)/x<=phi0*c_a/x<=c_a. The target right-hand side is therefore >=1, and probability<=1 closes the tail without distributional assumptions.

The affine, small signed, two large signed, and trivial tail regions include all their joins x=a,1,3/2,x_E; empty intervals cause no gap. The weak event is preserved from the smoothing input throughout. In particular, zero atoms and nonzero endpoint atoms are not dropped. No lower interval comparison, Hoeffding argument, or conversion to a full-CDF claim is needed for this extension. No positive lower cutoff on a is introduced.

## Conclusion

The actual extension bytes named in the verdict receive final independent PASS within the exact upper-central scope above. All previously provisional checks have now been tied to the frozen files and fresh execution evidence.
