# Independent audit request

Requested NEW scope: weak upper-central inequality for all actual m>=3/20 and all x>=m. Retaining the accepted m<=3/20 theorem would give the entire outer upper region. Do not extend acceptance to the remaining middle-max central interval x<m or to the q-conjecture.

Please review independently:

1. Upper Prawitz sign, normalization and phase identities (2)-(3), retaining weak atoms.
2. The global cosine-to-Gaussian deficit bound (5), including the one-turn derivative argument for h.
3. Every sign split and Gaussian cutoff term leading to E(m,z), especially the two different exponential tails.
4. The nonnegative phase majorant on the entire half-line, justifying extension before exact integration into Q(m,z).
5. Monotonicity of [M-E-Q]/m at fixed z and the Dawson rational comparisons. This is what removes the two-dimensional domain.
6. Independently reconstruct both rational polynomial identities and their 25 positive Bernstein coefficients.
7. The large-z trivial join and the large-max Paley/Cauchy-Schwarz join, including weak central versus strict complementary events.
8. Full domain coverage and the exact remaining central-upper obligation.

Accepted sources are frozen. The new proof presently has only primary exact checks; do not infer audit acceptance from their PASS status.
