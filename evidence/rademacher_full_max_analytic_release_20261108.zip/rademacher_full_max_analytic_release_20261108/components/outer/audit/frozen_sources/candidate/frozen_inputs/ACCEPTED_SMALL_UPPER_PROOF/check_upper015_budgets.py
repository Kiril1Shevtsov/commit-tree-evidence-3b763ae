#!/usr/bin/env python3
"""Exact rational changes for the upper-central extension through a=3/20."""
from fractions import Fraction as Q
from math import factorial
from pathlib import Path
import runpy,io,contextlib,json
ROOT=Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):
    base=runpy.run_path(str(ROOT/"BASE_independent_exact_audit.py"))
    affine=runpy.run_path(str(ROOT/"certify_affine015.py"))
checks={}
def check(name,x):
    if not x:raise RuntimeError(name)
    checks[name]=True
u=Q(3,20)
check("base_symbolic_identities_replayed",base["checks"] and all(base["checks"].values()))
check("new_affine_intervals_pass",affine["checks"] and all(affine["checks"].values()))
check("new_affine_parameter",affine["u"].l<=u<=affine["u"].h)
check("new_affine_epsilon",affine["eps"].l<=Q(1,10**80)<=affine["eps"].h)
check("six_a_le_one",6*u<1)
check("common_tail_monotone",1-6*u*u>0)
check("c_a_gt_a_thirds",Q(3,8)*(1-u*u/6)>Q(1,3))
check("tail_exponent_floor",1/(2*u*u)>22)
tail=14/u**6*Q(3,8)**22
check("common_tail_lt_1_over1500",tail<Q(1,1500))
check("cR_budget",Q(3,200)-Q(16,1125)-Q(1,1500)==Q(1,9000))
# The endpoint remainder prefactors are valid on the enlarged domain too.
E=Q(2,9)+Q(1,27)+Q(2,9)+u*u/81
D=Q(1,6)+Q(11,18)*u*u+Q(2,9)*u**4
check("E_prefactor_lt_one",E<1);check("D_prefactor_lt_four",D<4)
check("D2_prefactor_lt_four",Q(20,27)*u*u<4)
check("tail_combination",6*u**4+4*u*u+4<14)
cu=Q(29,81)+Q(2,25)*Q(13,9)**2+Q(3,200)
Su=u*cu+Q(1,20)+u/15+u*u/20+Q(5,12)*u*u+Q(8,45)*u**3+Q(7,6)*u**4
small=Q(3,16)-Su
check("upper_small_margin",small>0)
exp3=sum(Q(3)**j/factorial(j) for j in range(9))
exp9=sum(Q(9,8)**j/factorial(j) for j in range(5))
check("exp3_degree8",exp3==Q(89641,4480) and exp3>20)
check("exp9over8_degree4",exp9==Q(100331,32768) and exp9>3)
def budget(L,U):
    V=u*L/2+u*u*U/3
    return u*u/15+2*u/9+4*u*u/81+U/10+2*u**3/27+u*u*U/5+8*u**5/45+V/2+7*u*u*V/5+Q(2,25)*(L+8*u*U/9+16*u**3/81)+8*u*U/81+3*u**3/200
Ln,Un=Q(27,80),Q(9,40)
Lf,Uf=Q(9,10),Q(3,8)
check("near_x_cutoff_bounds",Ln==u*Q(3,2)**2 and Un==u*Q(3,2))
check("far_ax_squared_bound",Uf*Uf>u*Lf)
check("far_L_from_log20",Lf==2*u*3)
near=Q(15,104)-budget(Ln,Un)
far=Q(1,4)-budget(Lf,Uf)
check("near_margin_exact",near==Q(34933891,936000000) and near>0)
check("far_margin_exact",far==Q(5335099,96000000) and far>0)
check("far_negative_baseline",Q(3,8)*(1-Q(1,3))==Q(1,4))
report={"status":"PASS_EXACT_UPPER015_BUDGETS","scope":"Proposed weak upper-central extension only; independent analytic audit required.",
        "number_of_checks":len(checks),"checks":checks,"base_symbolic_checks":len(base["checks"]),"affine_checks":len(affine["checks"]),
        "upper_small_margin":str(small),"upper_near_margin":str(near),"upper_far_margin":str(far),
        "common_tail_upper":str(tail),"cR_slack":str(Q(1,9000)),"E_prefactor":str(E),"scaled_D_prefactor":str(D)}
print(json.dumps(report,indent=2))

