#!/usr/bin/env python3
"""Standalone rational outward-interval certificate for the upper015 extension.
Only the Python standard library is used. This is a reconstructed version,
not a byte-identical recovery. New execution and hashes are required."""
from fractions import Fraction as Q
from math import isqrt
from decimal import Decimal, localcontext, ROUND_FLOOR, ROUND_CEILING
import json
BITS=1024
SCALE=1<<BITS
def down(q):
    q=Q(q)
    return Q((q.numerator*SCALE)//q.denominator,SCALE)
def up(q): return -down(-Q(q))
class I:
    def __init__(self,lower,upper=None):
        self.l=down(Q(lower)); self.h=up(Q(lower if upper is None else upper))
        if self.l>self.h: raise ValueError("Reversed interval")
    def __add__(self,o):
        o=iv(o); return I(self.l+o.l,self.h+o.h)
    __radd__=__add__
    def __neg__(self): return I(-self.h,-self.l)
    def __sub__(self,o): return self+-iv(o)
    def __rsub__(self,o): return iv(o)+-self
    def __mul__(self,o):
        o=iv(o); p=[self.l*o.l,self.l*o.h,self.h*o.l,self.h*o.h]
        return I(min(p),max(p))
    __rmul__=__mul__
    def __truediv__(self,o):
        o=iv(o)
        if o.l<=0<=o.h: raise ValueError("Zero denominator")
        return self*I(1/o.h,1/o.l)
    def __rtruediv__(self,o): return iv(o)/self
    def __pow__(self,n):
        if not isinstance(n,int): raise TypeError("Only integer powers")
        if n<0:return 1/(self**(-n))
        r=I(1);b=self
        while n:
            if n%2:r=r*b
            n//=2
            if n:b=b*b
        return r
    def sqrt(self):
        if self.l<0:raise ValueError("Negative sqrt")
        lo=self.l*SCALE*SCALE; hi=self.h*SCALE*SCALE
        l=isqrt(lo.numerator//lo.denominator)
        h=isqrt(hi.numerator//hi.denominator)+1
        return I(Q(l,SCALE),Q(h,SCALE))
    def exp_neg(self):
        """Positive Taylor exp(y), y=x/1024, terms through degree100.
        Tail<=t101/(1-y/102). Reciprocal and power1024 give exp(-x)."""
        y=self/1024
        if not 0<=y.l<=y.h<1:raise ValueError("Unsupported exp argument")
        term=I(1); total=I(1)
        for n in range(1,101):
            term=term*y/n;total=total+term
        rem=(term*y/101)/(1-y/102)
        ex=I(total.l,total.h+rem.h)
        return (1/ex)**1024
    def report(self):
        def decimal(q,mode):
            with localcontext() as ctx:
                ctx.prec=80;ctx.rounding=mode
                return str(Decimal(q.numerator)/Decimal(q.denominator))
        return {"lower":decimal(self.l,ROUND_FLOOR),"upper":decimal(self.h,ROUND_CEILING),
                "exact_lower":str(self.l),"exact_upper":str(self.h)}
def iv(v):return v if isinstance(v,I) else I(v)
def atan_partial(q,n):
    q=Q(q)
    return sum((Q((-1)**j,2*j+1)*q**(2*j+1) for j in range(n)),Q(0))
def scaled_tail(d,n):
    if n<1:raise ValueError("Need S0,S1")
    v=[1/d,I(1)]
    for k in range(2,n+1):v.append(d**(k-1)+(k-1)*v[k-2])
    return v
checks={}
def require(name,condition):
    if not condition:raise RuntimeError("Failed interval check: "+name)
    checks[name]=True
pilo=16*atan_partial(Q(1,5),160)-4*atan_partial(Q(1,239),159)
pihi=16*atan_partial(Q(1,5),159)-4*atan_partial(Q(1,239),160)
require("strict_Machin_enclosure_width",pilo<pihi)
require("pi_lower_gt_three",pilo>3)
require("pi_upper_lt_twenty_two_over_seven",pihi<Q(22,7))
pi=I(pilo,pihi); c=(2/pi).sqrt(); u=I(Q(3,20));r=I(Q(1,2));s=I(Q(9,10))
eps=I(Q(1,10**80));mu=Q(1,50)
p2=pi*pi;u2=u*u;r2=r*r;r4=r**4;s2=s*s;s4=s**4
T=pi/u;D=pi/(9*u)
ST=scaled_tail(T,9);SD=scaled_tail(D,12)
central_exp=(T*T/2).exp_neg();reflected_exp=(D*D/2).exp_neg()
central_tail=2/(p2*u)*central_exp*(1+u**4*ST[9]/288)
reflection_A=2/p2*reflected_exp*(1+s4*u**4*SD[9]/288)
reflection_B=2/(3*pi)*reflected_exp*(SD[2]+s4*u**4*SD[10]/288
    +4*u2/(3*p2)*(SD[4]+s4*u**4*SD[12]/288))
values={
"AG":2/p2-c*u/6-eps,
"BG":c/6-4*u/(3*p2),
"A1":2/p2-c*(Q(1,6)-r2/4)*u-4*r2*u2/(3*p2)-35*c*r4*u**3/96-reflection_A-eps,
"B1":c*(r2/4+Q(1,6))-4*u/(3*p2)-c*(35*r4/96+5*r2/12)*u2
       -80*r4*u**5/(9*p2)-reflection_B,
"A2":c*(s2/4-Q(1,6))-35*c*s4*u2/96-8*(1-s4)*u**3/(3*p2)-eps,
"B2":c*(s2/4-Q(1,6))-c*(35*s4/96+4/(3*p2))*u2
       -8*(1-s2)*u**3/(3*p2)-35*c*(1-s4)*u**4/32-385*c*u**6/(24*p2)}
slacks={name:value-(mu*Q(3,20) if name in ("AG","A1") else mu)
        for name,value in values.items()}
pi_square_margin=10-p2
central_monotonicity_margin=T*T-5
reflected_monotonicity_margin=D*D-5
require("pi_squared_below_ten",pi_square_margin.l>0)
require("central_tail_monotonicity",central_monotonicity_margin.l>0)
require("reflected_tail_monotonicity",reflected_monotonicity_margin.l>0)
require("central_tail_strictly_positive",central_tail.l>0)
require("central_tail_below_epsilon",(eps-central_tail).l>0)
for name,slack in slacks.items():require("positive_slack_"+name,slack.l>0)
report={"status":"PASS_INDEPENDENT_RATIONAL_INTERVALS",
"version":"upper015_extension_exact_rational",
"scope":"Finite affine endpoint constants for 0<a<=3/20; analytic reductions require separate audit.",
"precision_absolute_dyadic_bits":BITS,"exp_degree":100,"exp_rescaling":1024,
"Machin_atan_lower_even_terms":160,"Machin_atan_upper_odd_terms":159,
"inputs":{"u":"3/20","r":"1/2","s":"9/10","mu":"1/50","epsilon":"1/10^80"},
"number_of_checks":len(checks),"checks":checks,"pi":pi.report(),"sqrt_two_over_pi":c.report(),
"pi_square_margin_below_ten":pi_square_margin.report(),
"central_monotonicity_margin":central_monotonicity_margin.report(),
"reflected_monotonicity_margin":reflected_monotonicity_margin.report(),
"central_tail_over_a3":central_tail.report(),"first_reflection_A_over_a2":reflection_A.report(),
"first_reflection_B_over_a2":reflection_B.report(),
"normalized_gap_lower_bounds":{k:v.report() for k,v in values.items()},
"slacks_above_required_margin":{k:v.report() for k,v in slacks.items()},"passed":True}
print(json.dumps(report,indent=2))

