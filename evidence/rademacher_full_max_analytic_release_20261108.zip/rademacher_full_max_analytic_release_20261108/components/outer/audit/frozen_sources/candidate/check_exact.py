#!/usr/bin/env python3
"""Exact primary algebra only. Standard library; no grids or quadrature."""
from fractions import Fraction as F
from math import comb, factorial
import json

checks=[]
def ck(name,b,detail=None):
    assert b,name
    checks.append({'name':name,'status':'PASS','detail':str(detail) if detail is not None else None})

def trim(p):
    p=list(map(F,p))
    while len(p)>1 and not p[-1]:p.pop()
    return p

def add(a,b):
    q=[F(0)]*max(len(a),len(b))
    for i,v in enumerate(a):q[i]+=v
    for i,v in enumerate(b):q[i]+=v
    return trim(q)
def neg(a):return [-v for v in a]
def sub(a,b):return add(a,neg(b))
def scale(a,c):return trim([v*c for v in a])
def mul(a,b):
    q=[F(0)]*(len(a)+len(b)-1)
    for i,v in enumerate(a):
        for j,w in enumerate(b):q[i+j]+=v*w
    return trim(q)
def pw(a,n):
    q=[F(1)]
    for _ in range(n):q=mul(q,a)
    return q

def U(a,n):
    q=[F(0)]
    for k in range(n+1):q=add(q,scale(pw(a,2*k+1),F((-1)**k,2**k*factorial(k)*(2*k+1))))
    return q

def bern(p,a,b):
    n=len(p)-1
    aa=[sum(p[j]*comb(j,k)*a**(j-k)*(b-a)**k for j in range(k,n+1)) for k in range(n+1)]
    return [sum(aa[k]*F(comb(j,k),comb(n,k)) for k in range(j+1)) for j in range(n+1)]

z=[F(0),F(1)];z2=pw(z,2);den=add([1],scale(z2,F(1,3)));de=add(add([1],scale(z2,F(1,2))),scale(pw(z,4),F(1,8)))
C=F(32,125)
def phase_num(m):
    # (1+z²/3) times the bracket of Q using D+=z/(1+z²/3).
    term=mul(mul(pw(m,2),sub(z,scale(mul(m,sub([1],z2)),F(2,3)))),z)
    term=sub(term,scale(mul(mul(pw(m,3),z),den),F(2,3)))
    rest=add(add(scale(pw(m,4),F(4,9)),scale(mul(z,pw(m,5)),F(8,45))),scale(pw(m,6),F(4,9)))
    return add(term,mul(rest,den))

m=scale(z,F(1,2))
base=sub(scale(U(m,3),2),U(z,4))
base=sub(base,scale(mul(pw(z,3),add(sub([1],scale(z2,F(1,2))),scale(pw(z,4),F(1,8)))),F(1,24)))
base=sub(base,scale(pw(z,5),F(1,160)))
base=sub(base,scale(mul(add([F(11,42)],scale(z2,F(6,35))),pw(z,6)),F(3,199)))
P1=sub(mul(base,den),scale(phase_num(m),C))
ck('diagonal_divisible_z3',all(v==0 for v in P1[:3]))
P1=trim(P1[3:])
B1=[F(1,12),F(593,7500),F(42433,560000),F(21272898517,292530000000),F(20190630563,292530000000),F(154580224633,2437750000000),F(197165105447,3656625000000),F(2418447827,65296875000),F(972919317,174125000000)]
ck('P1_Bernstein_identity',bern(P1,F(0),F(6,5))==B1)
ck('P1_positive_coefficients',all(v>0 for v in B1),min(B1))

m=[F(3,5)]
base=sub(add(U(m,3),U(sub(z,m),3)),U(z,4))
base=sub(base,scale(mul(z,pw(m,4)),F(1,10)))
base=sub(base,scale(mul(pw(m,2),pw(z,4)),F(7,300)))
base=sub(base,scale(pw(m,2),F(7,450)))
P2=mul(mul(base,den),de)
P2=sub(P2,scale(mul(mul(pw(m,2),z),den),F(1,6)))
P2=sub(P2,scale(mul(phase_num(m),de),C))
B2=[F(31650029591,1220703125000),F(6227427693989,146484375000000),F(373289752955369,6152343750000000),F(34295992298550533,426562500000000000),F(16007574343110667,157500000000000000),F(2035421678903465117,16380000000000000000),F(2310202138849555337,15600000000000000000),F(1797366513725811099,10400000000000000000),F(222438105360351333949,1123200000000000000000),F(561421349814364778677,2515968000000000000000),F(114876660698882773577,464486400000000000000),F(5578726893567828713387,20702822400000000000000),F(22267963180755661814699,77290536960000000000000),F(1719521299781415414827,5707608883200000000000),F(499532169214327384507,1630745395200000000000),F(10428401970429210521,34789235097600000000)]
ck('P2_Bernstein_identity',bern(P2,F(6,5),F(7,4))==B2)
ck('P2_positive_coefficients',all(v>0 for v in B2),min(B2))
ck('degrees',len(P1)==9 and len(P2)==16)

pl=F(157,50);pu=F(22,7)
ck('pi_lower_quartic96',pl**4>96)
ck('pi_upper_square10',pu**2<10)
ck('c0_lower',F(199,250)**2<F(7,11))
ck('alpha_upper',F(32,125)**2==2/F(25,8)**3)
ck('csc_lower_tail_sign',-F(1,540)+7*F(5,2)/43200<0)
ck('csc_upper_Taylor_positive',2100-660*F(5,2)-F(5,2)**3>0)
# Exact polynomial products proving the two new trigonometric statements.
S5=sub(add(z,scale(pw(z,5),F(1,120))),scale(pw(z,3),F(1,6)))
csc_lower=add(add([1],scale(z2,F(1,6))),scale(pw(z,4),F(7,360)))
expected=add(sub(z,scale(pw(z,7),F(1,540))),scale(pw(z,9),F(7,43200)))
ck('csc_lower_product_identity',mul(csc_lower,S5)==expected)
S7=sub(S5,scale(pw(z,7),F(1,5040)))
csc_upper=add(add([1],scale(z2,F(1,6))),scale(pw(z,4),F(1,30)))
expected=scale(mul(pw(z,5),[2100,0,-660,0,37,0,-1]),F(1,151200))
ck('csc_upper_product_identity',sub(mul(csc_upper,S7),z)==expected)
ck('diagonal_exp_constant',216/(F(8,3)**3*pl**6)<F(3,250))
ck('diagonal_tail_coefficient',1/(3*pl)+2/pl**3<F(6,35))
ck('diagonal_pi_coefficient',pu/12==F(11,42))
ck('root_interval',F(15,2)**2<57<F(38,5)**2)
ck('exp_21_over8',sum(F(21,8)**k/factorial(k) for k in range(9))>F(55,4))
ck('max_u_polynomial_bound',F(53,20)**2*(2*F(53,20)+3)/(F(55,4))==F(233147,55000)<F(17,4))
ck('negative_tail_coefficient',17/pl**4<F(7,40))
a=pl**2*F(25,72)
ck('cutoff_exp30',sum(a**k/factorial(k) for k in range(10))>30)
ck('cutoff_prefactor',F(2,5)*(8/F(25,8)**2+F(1,3))<F(7,15))

def uint(t,n):return U([t],n)[0]
v=F(199,250)*(uint(F(3,20),5)+uint(F(8,5),5))-1
ck('large_z_join',v==F(26224621137160720607,3892838400000000000000) and v>0,v)
v=F(199,250)*(uint(F(3,5),1)+uint(F(9,10),1))-1
ck('large_m_trivial_join',v==F(6863,100000) and v>0,v)
v=2*F(199,250)*uint(F(3,5),1)-F(21551,24576)
ck('large_m_Paley_margin',v==F(8054617,384000000) and v>0,v)
ck('Paley_endpoint',1-(1-F(9,64))**2/6==F(21551,24576))
report={'status':'PRIMARY_EXACT_ALGEBRA_PASS_NOT_INDEPENDENT_AUDIT','count':len(checks),'checks':checks,'parameter_grids_used':False,'quadrature_used':False,'third_party_packages_used':False}
print(json.dumps(report,indent=2))
