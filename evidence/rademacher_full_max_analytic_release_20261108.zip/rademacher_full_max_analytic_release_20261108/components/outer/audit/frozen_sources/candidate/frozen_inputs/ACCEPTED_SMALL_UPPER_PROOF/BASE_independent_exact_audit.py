#!/usr/bin/env python3
"""Independent exact algebra audit, reconstructed after environment loss.
Not byte-identical to lost source. Uses SymPy exact arithmetic only.
Analytic implications require separate human-readable audit.
"""
import json,math
import sympy as S
R=S.Rational
a,v,p,c,t,z,xi,f,K=S.symbols("a v p c t z xi f K",positive=True)
checks={}; details={}
def check(n,b):
    if b is not True and b!=S.true: raise RuntimeError(n+": "+str(b))
    checks[n]=True
def eq(n,x,y): check(n,S.expand(x-y)==0)
def pos(n,x): check(n,x>0)
def moment(n):
    if n%2:return S.Integer(2)**((n-1)//2)*S.factorial((n-1)//2)
    return S.factorial2(n-1)*p*c/2 if n else p*c/2
def integral(poly): return S.expand(sum(coef*moment(mon[0]) for mon,coef in S.Poly(S.expand(poly),v).terms()))
def P(e): return 1-e**2*v**4/12+e**4*v**8/288
T=p/a
ca=S.expand(2/T*integral((1-v/T)*P(t*a)))
cb=S.expand(2*integral((1/p-p*v**2/(3*T**2)+p*v**3/(3*T**3))*P(t*a)))
ca_claim=c*a*(1-t*t*a*a/4+35*t**4*a**4/96)-2*a*a/p**2*(1-2*t*t*a*a/3+4*t**4*a**4/3)
cb_claim=c-c*(t*t/4+R(1,3))*a*a+4*a**3/(3*p**2)+c*(35*t**4/96+5*t*t/12)*a**4-8*t*t*a**5/(3*p**2)-35*c*t**4*a**6/32+80*t**4*a**7/(9*p**2)
eq("central_A_from_integral",ca,ca_claim);eq("central_B_from_integral",cb,cb_claim)
ra0=S.expand(2/T**2*integral(v*P(a)))
rb0=S.expand(2*p/3*integral((v**2/T**2-v**3/T**3+R(4,3)*v**4/T**4)*P(a)))
r=R(1,2);s=R(9,10);u=R(1,10);mu=R(1,50)
A2=S.expand(ca.subs(t,s)+ra0);B2=S.expand(cb.subs(t,s)+rb0)
A2_claim=c*a-c*s*s*a**3/4+4*(s*s-1)*a**4/(3*p**2)+35*c*s**4*a**5/96+8*(1-s**4)*a**6/(3*p**2)
B2_claim=c-c*s*s*a*a/4+c*(35*s**4/96+5*(s*s-1)/12+4/(3*p**2))*a**4+8*(1-s*s)*a**5/(3*p**2)+c*(35*(1-s**4)/32-35/(9*p**2))*a**6+80*(s**4-1)*a**7/(9*p**2)+385*c*a**8/(24*p**2)
eq("last_A_from_independent_integrals",A2,A2_claim);eq("last_B_from_independent_integrals",B2,B2_claim)
Hlo=c*(a-a**3/6)
gaps={"AG":(Hlo-ca.subs(t,0))/a**2,"BG":(Hlo/a-cb.subs(t,0))/a**2,"A1":(Hlo-ca.subs(t,r))/a**2,"B1":(Hlo/a-cb.subs(t,r))/a**2,"A2":(Hlo-A2)/a**3,"B2":(Hlo/a-B2)/a**2}
kept={
"AG":2/p**2-c*a/6,
"BG":c/6-4*a/(3*p**2),
"A1":2/p**2-c*(R(1,6)-r*r/4)*a-4*r*r*a*a/(3*p**2)-35*c*r**4*a**3/96,
"B1":c*(r*r/4+R(1,6))-4*a/(3*p**2)-c*(35*r**4/96+5*r*r/12)*a*a-80*r**4*a**5/(9*p**2),
"A2":c*(s*s/4-R(1,6))-35*c*s**4*a*a/96-8*(1-s**4)*a**3/(3*p**2),
"B2":c*(s*s/4-R(1,6))-c*(35*s**4/96+4/(3*p**2))*a*a-8*(1-s*s)*a**3/(3*p**2)-35*c*(1-s**4)*a**4/32-385*c*a**6/(24*p**2)}
remainders={"AG":0,"BG":0,"A1":a**4/(6*p*p),"B1":35*c*a**4/512+2*a**3/(3*p*p),"A2":19*a/(75*p*p),"B2":3439*a**5/(1125*p*p)+35*c*a**4/(9*p*p)+19*c*a*a/240}
for n in gaps:
    eq("favorable_remainder_"+n,gaps[n]-kept[n],remainders[n])
    for (deg,),coef in S.Poly(kept[n],a).terms():
        if deg:check("endpoint_substitution_"+n+"_"+str(deg),coef.is_negative)
    for (deg,),coef in S.Poly(remainders[n],a).terms():check("remainder_nonnegative_"+n+"_"+str(deg),coef.is_nonnegative)
details["affine_favorable_remainders"]={k:str(S.expand(vv)) for k,vv in remainders.items()}
D=S.symbols("D",positive=True);Sp=[1/D,S.Integer(1)]
for n in range(2,13):Sp.append(S.expand(D**(n-1)+(n-1)*Sp[n-2]))
eq("odd_tail_S9",Sp[9],D**8+8*D**6+48*D**4+192*D**2+384)
laurents={
"central":2/(p*p*a)*(1+a**4*Sp[9].subs(D,p/a)/288),
"reflection_A":2/p**2*(1+s**4*a**4*Sp[9].subs(D,p/(9*a))/288),
"reflection_B":(2/(3*p)*(Sp[2]+s**4*a**4*Sp[10]/288+4*a*a/(3*p*p)*(Sp[4]+s**4*a**4*Sp[12]/288))).subs(D,p/(9*a))}
mins={"central":-5,"reflection_A":-4,"reflection_B":-5}
for n,pol in laurents.items():
    terms=[]
    for term in S.Add.make_args(S.expand(pol)):
        deg=term.as_powers_dict().get(a,S.Integer(0));coef=S.simplify(term/a**deg);terms.append((deg,coef))
    check("minimum_tail_power_"+n,min(deg for deg,_ in terms)==mins[n])
    check("positive_Laurent_coefficients_"+n,all(coef.is_positive for _,coef in terms))
    details[n+"_laurent"]=str(S.expand(pol))
def gm(n):return moment(n).subs(c,2*f)
def gi(poly):return S.expand(sum(coef*gm(mon[0]) for mon,coef in S.Poly(S.expand(poly),v).terms()))
kappa=(xi-1)+a*v/p+a*a*v*v*(xi*xi/2+xi/3)
D1=gi(a/p*kappa*(a*a*v**4/12+K*a**4*v**6))
D1display=f*(xi-1)*a**3/4+2*a**4/(3*p*p)+15*f*K*(xi-1)*a**5+48*K*a**6/(p*p)+(xi*xi/2+xi/3)*(5*f*a**5/4+105*f*K*a**7)
eq("D1_reconstructed_all_moments",D1,D1display)
def ref_t_mom(n):return gm(n)*(a/p)**(n+1)
eq("alias_cos_term",ref_t_mom(1),a*a/(p*p))
eq("alias_sin_term",(p*xi+4*p/9)*ref_t_mom(2),f*a**3/p*(xi+R(4,9)))
eq("alias_cubic_term",4*p*p*xi/9*ref_t_mom(3),8*xi*a**4/(9*p*p))
common=f*a**3*(R(1,6)-xi*xi/2)+f*a**5*xi**4/8+a**4*xi**2/(p*p)+D1+f*f/2*(xi+R(4,9))**2*a**4+8*xi*a**4/(9*p*p)+R(3,200)*a**4
upper=S.expand((common-f*a**3*xi/3+f*a**5*xi**3/6+2*a**4*xi/(3*p*p))/a**3)
lower=S.expand((common+f*a**3*xi/3)/a**3)
P1base=(xi**2+R(8,9)*xi+R(2,3))/p**2+f*f/2*(xi+R(4,9))**2+R(3,200)
P2base=f*xi**4/8+15*f*K*(xi-1)+R(5,4)*f*(xi**2/2+xi/3)
base=a*P1base+a*a*P2base+a**3*48*K/p**2+a**4*105*f*K*(xi**2/2+xi/3)
eq("upper_small_polynomial_collection",upper,-f*(6*xi**2+xi+1)/12+base+2*a*xi/(3*p*p)+f*a*a*xi**3/6)
eq("lower_small_polynomial_collection",lower,-f*(6*xi**2-7*xi+1)/12+base)
def atan_partial(q,n):return sum((R((-1)**j,2*j+1)*q**(2*j+1) for j in range(n)),S.Integer(0))
pl=16*atan_partial(R(1,5),12)-4*atan_partial(R(1,239),11)
ph=16*atan_partial(R(1,5),11)-4*atan_partial(R(1,239),12)
pos("Machin_interval_width",ph-pl)
pos("pi_gt_25_over_8",pl-R(25,8));pos("pi_lt_22_over_7",R(22,7)-ph)
pos("phi0_gt_3_over_8",1-2*ph*R(3,8)**2);pos("phi0_lt_2_over_5",2*pl*R(2,5)**2-1)
pos("pi_squared_lt_ten",10-ph*ph)
pos("reflected_tail_monotone",pl*pl/(81*u*u)-5);pos("central_tail_monotone",pl*pl/(u*u)-5)
coslo=sum((R((-1)**j,math.factorial(2*j)) for j in range(4)),S.Integer(0))
eq("cos1_alternating_value",coslo,R(389,720))
exp37=sum((R(37,60)**j/math.factorial(j) for j in range(6)),S.Integer(0))
pos("exp37_degree5_gt_reciprocal_cos_lower",exp37-1/coslo)
eq("log_cos_K_endpoint",R(37,60)-R(1,2)-R(1,12),R(1,30))
exp35=sum((R(7,2)**j/math.factorial(j) for j in range(11)),S.Integer(0))
eq("exp35_degree10_value",exp35,R(1951237723,58982400));pos("log30_lt_3p5",exp35-30)
pos("six_a0_lt_one",1-6*u);pos("common_tail_monotone",1-6*u*u)
pos("c_a_gt_a_over_3",R(3,8)*(1-u*u/6)-R(1,3))
tail=14*10**6*R(3,8)**50
pos("common_tail_lt_1e_minus4",R(1,10000)-tail)
pos("common_cR_slack",R(3,200)-R(2,135)-R(1,10000))
pos("epsilonE_prefactor_lt_one",1-R(1,3)*(1+R(2,3)+u*u/27))
pos("epsilonD_prefactor_lt_four",4-(1+u+2*u*u)/3)
pos("kappa_s_coefficient",1-u**3/3);pos("kappa_s2_coefficient",R(1,2)-u*u/3)
pos("D2_prefactor_lt_four",4-R(8,9));pos("D2_exponent_ge_common",pl*pl/8-R(1,2))
cu=R(29,81)+R(2,25)*R(13,9)**2+R(3,200)
cl=R(23,81)+R(2,25)*R(13,9)**2+R(3,200)
rest=u*u/20+R(5,12)*u*u+R(8,45)*u**3+R(7,6)*u**4
Su=u*cu+R(1,20)+u/15+rest
Slnear=u*cl+9*u*u/20+rest;Slfar=u*cl+R(1,20)+rest
margins={"upper_small":R(3,16)-Su,"lower_near":R(49,648)-Slnear,"lower_far":R(11,96)-Slfar}
eq("lower_near_negative_budget",R(3,8)*(6-7/R(9,5)+1/R(9,5)**2)/12,R(49,648))
eq("lower_far_negative_budget",R(3,8)*(6-R(7,3))/12,R(11,96))
L=R(7,10);U=R(27,100);V=u*L/2+u*u*U/3
pos("ax_cutoff_squared",U*U-u*L)
large_terms={
"gaussian_correction":u*u/15,"xD":2*u/9,"N":4*u*u/81,"D1_constant_xi":U/10,
"D1_linear_s":2*u**3/27,"D1_Kconstant_xi":u*u*U/5,"D1_Klinear_s":R(8,45)*u**5,
"D1_quadratic":V/2,"D1_Kquadratic":R(7,5)*u*u*V,
"alias_square":R(2,25)*(L+R(8,9)*u*U+R(16,81)*u**3),
"alias_cubic":R(8,81)*u*U,"remainder":R(3,200)*u**3}
Bu=sum(large_terms.values());Bl=Bu+16*u/195
margins.update(upper_large=R(15,104)-Bu,lower_large=R(15,104)-Bl)
wanted={"upper_small":R(116443,1620000),"upper_large":R(12427271,877500000),"lower_near":R(31703,1620000),"lower_far":R(10559,810000),"lower_large":R(5227271,877500000)}
for n in margins:
    eq("exact_margin_"+n,margins[n],wanted[n]);pos("positive_margin_"+n,margins[n])
bridge=2-R(9,5)-(4*R(9,5)**3+1)*u*u/3
eq("bridge_exact",bridge,R(4459,37500));pos("bridge_positive",bridge)
eq("bridge_evaluation_point_upper",R(18,5)*u,R(9,25));pos("bridge_below_one",1-R(18,5)*u)
b=R(27,40);fhelper=R(19947,50000)
pos("helper_phi0_lower",1-2*ph*fhelper*fhelper)
poly=b-b**3/6+b**5/40-b**7/336
pos("helper_integrated_Taylor_positive",poly)
hlo=2*fhelper*poly
eq("helper_H_cutoff_value",hlo,R(229520461865155173,458752000000000000));pos("helper_H_gt_half",hlo-R(1,2))
Ucentral,Lcentral,H,C=S.symbols("Ucentral Lcentral H C",real=True)
eq("positive_CDF_error",(1+Ucentral)/2-(1+H)/2,(Ucentral-H)/2)
eq("negative_CDF_error",(1-Lcentral)/2-(1-H)/2,(H-Lcentral)/2)
details.update(margins={k:str(q) for k,q in margins.items()},bridge=str(bridge),tail_upper=str(tail),large_positive_terms={k:str(q) for k,q in large_terms.items()},helper_H_lower=str(hlo),helper_margin=str(hlo-R(1,2)),pi_interval=[str(pl),str(ph)])
print(json.dumps({"status":"PASS_EXACT_RECONSTRUCTION","version":"reconstructed_after_environment_loss","number_of_checks":len(checks),"checks":checks,"details":details,"scope":"Finite identities and constants only. Main theorem 0<a<=1/10 requires accompanying analytic audit. Separate large-a helper is weak upper-central only."},indent=2))

