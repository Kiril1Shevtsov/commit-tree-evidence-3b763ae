# Complete outer weak-upper bound from an actual-frequency phase envelope

Date: 2026-11-08. Status: PRIMARY CANDIDATE, pending independent audit.

## Scope and accepted inputs

Let X=sum a_i epsilon_i, with independent unbiased signs, sum a_i^2=1, and actual maximum m=max|a_i| in (0,1]. Put H=2Phi-1 and c0=sqrt(2/pi).

This note proves, subject to independent audit of its new steps,

    P(|X|<=x)<=H(x)+H(m),     x>=m, m>=3/20.           (1)

Combined with the already accepted analytic small-max upper theorem m<=3/20, it covers the whole outer weak-upper region x>=m. It does NOT prove the central interval 0<=x<m in the middle-max range. It uses no new quantitative cap-defect reflection lemma and makes no q claim.

Accepted analytic inputs are the signed weak-upper Prawitz inequality, actual-frequency reflection at T=pi/m, and the first-half head bounds. They are frozen with their previously accepted audit. The elementary bound R(v)<=2v^2/3 below is also contained in the now accepted full-lower proof, frozen here. All new scalar budget decisions are two printed one-variable polynomial identities, not parameter meshes or quadrature.

The endpoints in (1) are WEAK. No atom is removed.

## 1. An all-threshold upper phase envelope

Set

    p=1/m^2, d=x/m+1, z=dm=x+m,
    R(v)=v/sin v-cos v,
    A(v)=sqrt(sin^2 v+R(v)^2),  0<=v<=pi/2.

For the upper Prawitz kernel

    k(u)=(1-u)cos(pi xu/m)
              +[(1-u)cot(pi u)+1/pi]sin(pi xu/m),

direct trigonometry gives

    k(v/pi)=sin(dv)/sin v
                 -[R(v)sin(dv)+sin v cos(dv)]/pi,

    k(1-v/pi)=[R(v)sin(d(pi-v))-sin v cos(d(pi-v))]/pi.

Thus k(v/pi)+|k(1-v/pi)| is at most

    sin(dv)/sin v+E_d(v)/pi,
    E_d(v)=A(v)-sin v cos(dv)-R(v)sin(dv)>=0.          (2)

The nonnegativity is Cauchy-Schwarz. Write

    F(v)=product cos(a_i v/m),
    L(v)=cos(v)^p, G(v)=exp[-v^2/(2m^2)].

The accepted reflection and head bounds give

    P(|X|<=x)<=(2/pi) integral_0^(pi/2)
                       [sin(dv)/sin v+E_d(v)/pi]F(v)dv,
    0<=L(v)<=F(v)<=G(v).                              (3)

All signs in this formula are retained.

## 2. Elementary trigonometric bounds used in the budget

Throughout 0<=v<=pi/2,

    0<=R(v)<=2v^2/3,
    R(v)>=2v^2/3-v^4/45,
    1/sin v<=1/v+v/6+v^3/30,
    v/sin v<=1+v^2/4.                                (4)

The first and fourth estimates are accepted in the full-lower proof, whose displayed Taylor proofs are frozen. For completeness, the two additional estimates need only short Taylor checks. The upper degree-5 sine bound implies

    (1+v^2/6+7v^4/360)sin v
       <=v-v^7/540+7v^9/43200<=v,

since v^2<5/2. Hence v/sin v>=1+v^2/6+7v^4/360. Subtracting cos v<=1-v^2/2+v^4/24 proves the lower R bound.

The lower degree-7 sine bound gives, with w=v^2<=5/2,

    (1+v^2/6+v^4/30)sin v-v
       >=v^5(2100-660w+37w^2-w^3)/151200>0.

The last numerator is at least 2100-660(5/2)-(5/2)^3>0.

We also need, for every real p>=1,

    0<=G(v)-cos(v)^p <=(p v^4/6)G(v).                (5)

Here G(v)=exp(-pv^2/2). To prove this, put a(v)=cos v exp(v^2/2), which lies in [0,1]. We claim 1-a(v)<=v^4/6. For

    h(v)=a(v)-1+v^4/6,

its derivative divided by v^3 is 2/3-J(v), where

    J(v)=exp(v^2/2)(sin v-v cos v)/v^3
        =integral_0^1 r^2 exp(v^2/2)sinc(vr)dr.

J is increasing on [0,pi/2]. Indeed z cot z>=1-z^2 there: the derivative of z cos z-(1-z^2)sin z is z sin z+z^2 cos z>=0. Therefore the logarithmic derivative in v of exp(v^2/2)sinc(vr) is at least v(1-r^2)>=0. Since J(0)=1/3, h first increases and can then only decrease. Its minimum is at an endpoint; h(0)=0 and

    h(pi/2)=pi^4/96-1>0

using pi>157/50. Thus 1-a<=v^4/6. Finally 1-a^p<=p(1-a), by convexity of a^p for p>=1. This proves (5).

## 3. A global explicit upper budget

Define Dawson's integral in the normalization

    D(z)=integral_0^infinity exp(-s^2/2)sin(zs)ds,
    N(z)=z+(1-z^2)D(z).

We will show that (3) implies

    P(|X|<=x)<=H(z)+E(m,z)+Q(m,z),                    (6)

where

    E(m,z)=c0 m^2 z exp(-z^2/2)/6+c0 z m^4/10
       +m^2[pi^2/z^2+3]exp[-pi^2/(2z^2)]/(3pi)
       +m^2[8/pi^3+1/(3pi)]exp[-pi^2/(8m^2)],          (7)

    Q(m,z)=(2/pi^2)[m^2 zD(z)-(2/3)m^3 N(z)
                       +4m^4/9+8zm^5/45+4m^6/9].    (8)

### The main sine term

Where sin(dv)>=0, F<=G gives an upper excess over G sin(dv)/v bounded by G(1/sin v-1/v)sin(dv). Where sin(dv)<0, F>=L and sin v<=v instead give an upper excess at most

    [G(v)-L(v)]|sin(dv)|/v.

By (5), the latter loss, enlarged from the negative intervals to the whole tail beginning at v0=pi/d, is at most

    (p/(3pi)) integral_v0^infinity v^3 G(v)dv
      =m^2[pi^2/z^2+2]exp[-pi^2/(2z^2)]/(3pi).        (9)

To bound the positive sine contribution from the geometric factor in (4), use v/6+v^3/30. The v/6 term is integrated with its sign over the whole half-band, then its negative part is added back. That addition is at most

    m^2 exp[-pi^2/(2z^2)]/(3pi).

Extending the signed v/6 integral to infinity costs at most

    m^2 exp[-pi^2/(8m^2)]/(3pi).

The full signed integral equals c0 m^2 z exp(-z^2/2)/6. The v^3/30 term is bounded using |sin(dv)|<=dv; its integral is at most c0 z m^4/10.

Finally, comparing the Gaussian sine integral on the half-band with its full value H(z) costs at most

    (2/pi) integral_(pi/2)^infinity G(v)/v dv
       <=8m^2 exp[-pi^2/(8m^2)]/pi^3.

Combining these estimates proves exactly (7). The extension from an empty negative interval is harmless when d<=2.

### The phase term

Since E_d>=0, F<=G can be used in its integral. From (4),

    E_d(v)<=v(1-cos(dv))-(2/3)v^2 sin(dv)
               +2v^3/9+(v^4/45)|sin(dv)|+v^5/18.     (10)

The first three terms on the right have nonnegative sum for EVERY v>=0. Divide by v and use

    cos(dv)+(2v/3)sin(dv)<=sqrt(1+4v^2/9)<=1+2v^2/9.

The remaining terms are nonnegative. Thus the entire right side of (10) may be integrated against G on [0,infinity). Use

    integral vG(v)(1-cos(dv))dv=m^2 zD(z),
    integral v^2G(v)sin(dv)dv=m^3 N(z),
    integral v^3G(v)dv=2m^4,
    integral v^5G(v)dv=8m^6,
    |sin(dv)|<=dv.

Multiplication by 2/pi^2 proves (8). All Gaussian integrals in this section are exact identities or elementary tail bounds.

## 4. Monotonicity reduces the whole budget to two boundary intervals

Let

    M(m,z)=H(m)+H(z-m)-H(z),
    B(m,z)=[M(m,z)-E(m,z)-Q(m,z)]/m.

For fixed z>0, B is strictly decreasing in m on 0<m<=z/2.

First, M/(c0m) is the average on [0,m] of

    f_z(t)=exp(-t^2/2)-exp(-(z-t)^2/2).

Its derivative is -t exp(-t^2/2)-(z-t)exp(-(z-t)^2/2)<0 for 0<=t<=z/2. Hence the average decreases in m. Every term of E/m increases in m.

For Q/m, differentiating its bracket leaves, apart from additional nonnegative terms,

    q_m=zD(z)-(4/3)mN(z)+(4/3)m^2.                   (11)

We use the global rational comparison

    z/(1+z^2)<=D(z)<=z/(1+z^2/3).                    (12)

To verify it, D'+zD=1, D(0)=0. The lower rational comparison has residual R'+zR-1=-2z^2/(1+z^2)^2<=0; the upper has residual 2z^4/[9(1+z^2/3)^2]>=0. Integrating factors prove both comparisons.

If 0<z<=1, then N>=z, so (11) decreases in m up to z/2. At that endpoint it is

    [z(1+2z^2)D(z)-z^2]/3
       >=z^4/[3(1+z^2)]>0.

If z>=1 and N<=0, (11) is positive immediately. If z>=1 and N>0, then (12) gives N<=2z/(1+z^2). The minimum of (11) on the whole real m-line is therefore at least

    zD-N^2/3 >= z^2(3z^2-1)/[3(1+z^2)^2]>0.

Thus Q/m increases, proving the claimed decrease of B.

For m<=3/5 and x>=m, we have m<=z/2. Whenever z<=7/4, it is enough to check only

    (i) m=z/2, 0<z<=6/5;
    (ii) m=3/5, 6/5<=z<=7/4.                        (13)

This is a continuous monotonicity reduction, not a parameter subdivision certificate.

## 5. The two exact polynomial identities

Write

    U_j(t)=sum_(k=0)^j (-1)^k t^(2k+1)/[2^k k!(2k+1)],
    D_+(z)=z/(1+z^2/3), N_+(z)=z+(1-z^2)D_+(z),
    C=32/125.

We use c0>199/250, 2/(pi^2 c0)<C, pi>157/50, pi<22/7, and e>8/3. These inequalities follow from elementary classical pi bounds and the exponential series.

In (8), the coefficient of D after factoring m^2 is z-(2/3)m(1-z^2)>0 for z>=2m. Hence replacing D by D_+ gives an upper bound. Its bracket is nonnegative, because it bounds the integral of the nonnegative majorant (10). Therefore replacing 2/(pi^2 c0) by C preserves the upper bound.

### Boundary (i)

For m=z/2 define

    L_1(z)=2U_3(z/2)-U_4(z)
       -z^3(1-z^2/2+z^4/8)/24-z^5/160
       -(250/199)(11/42+6z^2/35)(3z^6/250)
       -C[m^2 zD_+-(2/3)m^3N_++4m^4/9
                                      +8zm^5/45+4m^6/9].

This is a lower bound for [M-E-Q]/c0. The Gaussian Taylor bounds are global. For the common exponential tail, use

    exp[-pi^2/(2z^2)]<=216z^6/(e^3 pi^6)<3z^6/250,

which follows from max u^3 exp(-u)=27/e^3. The combined tail coefficient at m=z/2 is

    pi/12+z^2/(3pi)+2z^2/pi^3 <11/42+6z^2/35.

The polynomial

    P_1(z)=(1+z^2/3)L_1(z)/z^3

has degree 8. On 0<=z<=6/5 its Bernstein coefficients, with parameter s=5z/6, are

    (1/12,
     593/7500,
     42433/560000,
     21272898517/292530000000,
     20190630563/292530000000,
     154580224633/2437750000000,
     197165105447/3656625000000,
     2418447827/65296875000,
     972919317/174125000000).

That is P_1(z)=sum_(j=0)^8 binom(8,j)b_j s^j(1-s)^(8-j). Every coefficient is positive, including the removable value at z=0.

### Boundary (ii)

Set m=3/5. The two tail terms, after division by c0, are at most

    7m^2 z^4/300 + 7m^2/450.                         (14)

For the first, put u=pi^2/(2z^2). The function u^2(2u+3)exp(-u) has its positive maximum at (3+sqrt(57))/4, between 21/8 and 53/20. Since exp(21/8)>55/4,

    u^2(2u+3)exp(-u)<233147/55000<17/4.

It follows that (2u+3)exp(-u)<17z^4/pi^4<7z^4/40. Also 1/(pi c0)=phi(0)<2/5, proving the first term of (14).

For the second, exp[-pi^2/(8m^2)]<1/30 when m=3/5. This follows from the degree-9 positive exponential Taylor polynomial at (157/50)^2*25/72, which exceeds 30. Moreover

    [8/pi^3+1/(3pi)]/c0 <(2/5)[8/(25/8)^2+1/3]<7/15.

This proves the second term of (14).

Define

    L_2(z)=U_3(m)+U_3(z-m)-U_4(z)
       -m^2 z/[6(1+z^2/2+z^4/8)]-zm^4/10
       -7m^2 z^4/300-7m^2/450
       -C[m^2 zD_+-(2/3)m^3N_++4m^4/9
                                      +8zm^5/45+4m^6/9].

Here exp(-z^2/2)<=1/(1+z^2/2+z^4/8). Consequently L_2 is a lower bound for [M-E-Q]/c0.

The polynomial

    P_2(z)=(1+z^2/3)(1+z^2/2+z^4/8)L_2(z)

has degree 15. On 6/5<=z<=7/4, use s=(z-6/5)/(11/20). Its Bernstein coefficients are

    (31650029591/1220703125000,
     6227427693989/146484375000000,
     373289752955369/6152343750000000,
     34295992298550533/426562500000000000,
     16007574343110667/157500000000000000,
     2035421678903465117/16380000000000000000,
     2310202138849555337/15600000000000000000,
     1797366513725811099/10400000000000000000,
     222438105360351333949/1123200000000000000000,
     561421349814364778677/2515968000000000000000,
     114876660698882773577/464486400000000000000,
     5578726893567828713387/20702822400000000000000,
     22267963180755661814699/77290536960000000000000,
     1719521299781415414827/5707608883200000000000,
     499532169214327384507/1630745395200000000000,
     10428401970429210521/34789235097600000000).

Again the identity is P_2=sum binom(15,j)b_j s^j(1-s)^(15-j), and every coefficient is positive. The accompanying rational checker reconstructs both polynomials from their definitions, rather than evaluating them on sample points.

Together with Section 4, these identities prove (1) whenever 0<m<=3/5, x>=m, and z=x+m<=7/4.

## 6. The remaining regions are elementary

### Large z in the middle-max range

Suppose m>=3/20, m<=3/5, x>=m, and z=x+m>=7/4. Since H is increasing, it suffices to take z=7/4. For fixed z, the function H(m)+H(z-m) increases with m<=z/2. Consequently

    H(m)+H(x)>=H(3/20)+H(8/5)>1.

An exact verification using c0>199/250 and the lower degree-5 exponential integral is

    (199/250)[U_5(3/20)+U_5(8/5)]-1
      =26224621137160720607/3892838400000000000000>0.

Thus (1) is automatic in this region.

### Every m>=3/5, x>=m

If x>=9/10, then H(m)+H(x)>1, because

    (199/250)[U_1(3/5)+U_1(9/10)]-1=6863/100000>0.

Otherwise m<=x<9/10. Split off an attained maximal coefficient:

    X=m epsilon+Y,  sigma^2=E Y^2=1-m^2>0,
    r=x-m>=0.

By symmetry, including all endpoint atoms,

    P(|X|<=x)
      =[P(|Y|<=x+m)+P(|Y|<=x-m)]/2
      <=1/2+P(|Y|<=r)/2.

The fourth moment satisfies E Y^4<=3sigma^4. Cauchy-Schwarz on the STRICT event Y^2>r^2 gives

    P(|Y|>r)>=(1-r^2/sigma^2)^2/3.

Here r^2/sigma^2<=(9/10-m)^2/(1-m^2)<=9/64; the last function decreases for 3/5<=m<9/10. Therefore

    P(|X|<=x)<=1-(55/64)^2/6=21551/24576.

On the other hand,

    H(x)+H(m)>=2H(3/5)
      >2(199/250)U_1(3/5),

and the exact difference from 21551/24576 is 8054617/384000000>0. This proves (1) throughout the large-max outer region.

## 7. Composition and remaining obligation

The proof covers all x>=m and all m>=3/20, with closed joins at m=3/5, z=6/5 and 7/4, x=9/10, and x=m. The accepted analytic small-max upper theorem supplies m<=3/20 if a statement covering all m is desired. The Prawitz majorant is weak-upper throughout; the final fourth-moment argument uses a strict complementary event, so atoms are not lost.

This candidate has no dependency on the new, still-pending cap-defect reflection lemma. The remaining middle-max central region 0<=x<m must be established separately before the complete analytic max-coefficient Kolmogorov theorem is claimed. The main places requiring independent review are the upper sine-sign split, the global deficit bound (5), the phase integral extension, monotonicity of Q/m, the two rational polynomial identities, and the endpoint conventions in Section 6.
