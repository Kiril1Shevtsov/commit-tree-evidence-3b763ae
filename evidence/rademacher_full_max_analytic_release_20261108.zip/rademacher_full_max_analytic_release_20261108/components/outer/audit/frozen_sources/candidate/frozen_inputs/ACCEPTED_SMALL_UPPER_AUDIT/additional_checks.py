"""Independent Fraction checks and source checks; no external code downloaded."""
from fractions import Fraction as F
from math import factorial
from pathlib import Path
import ast,json,hashlib
p=Path('/workspace/shared/keller_klein_upper015_20261107')
u=F(3,20); tests={}
def ck(name,v):
    assert v,name
    tests[name]=True
for name in ['BASE_independent_exact_audit.py','certify_affine015.py','check_upper015_budgets.py']:
    tree=ast.parse((p/name).read_text())
    ck('no_float_literals_'+name,not any(isinstance(n,ast.Constant) and isinstance(n.value,float) for n in ast.walk(tree)))
# Each cutoff/tail issue checked independently of the submitted code.
ck('cutoff_coefficients',F(3,8)*(1-u*u/6)>F(1,3) and 6*u<1)
ck('common_tail_derivative',1-6*u*u>0)
ck('reflected_tail_derivative_using_pi_lower',F(25,8)**2/(81*u*u)>5)
ck('central_tail_derivative_using_pi_lower',F(25,8)**2/(u*u)>5)
ck('e_gt_8over3',sum((F(1,factorial(j)) for j in range(5)),F(0))>F(8,3))
ck('common_exponent',1/(2*u*u)>22)
tail=14*u**-6*F(3,8)**22
ck('tail_value',tail==F(4708235109375,9007199254740992))
ck('tail_threshold',tail<F(1,1500))
ck('tail_absorption',F(3,200)-F(16,1125)-F(1,1500)==F(1,9000))
ck('tail_combination',6*u**4+4+4*u*u<14)
E=F(2,9)+F(1,27)+F(2,9)+u*u/81
D=F(1,6)+F(11,18)*u*u+F(2,9)*u**4
ck('E_prefactor_value',E==F(5203,10800) and E<1)
ck('D_prefactor_value',D==F(43327,240000) and D<4)
ck('D2_prefactor',20*u*u/27<4)
small=F(3,16)-(u*(F(29,81)+F(2,25)*F(13,9)**2+F(3,200))+F(1,20)+u/15+u*u/20+5*u*u/12+8*u**3/45+7*u**4/6)
ck('small_margin_value',small==F(300833,8640000) and small>0)
# Expanded budget, independent of the submitted V helper.
def budget(L,U):
    return u*u/15+2*u/9+4*u*u/81+U/10+2*u**3/27+u*u*U/5+8*u**5/45+u*L/4+u*u*U/6+7*u**3*L/10+7*u**4*U/15+2*L/25+16*u*U/225+32*u**3/2025+8*u*U/81+3*u**3/200
near=F(15,104)-budget(F(27,80),F(9,40))
far=F(1,4)-budget(F(9,10),F(3,8))
ck('near_margin',near==F(34933891,936000000) and near>0)
ck('far_margin',far==F(5335099,96000000) and far>0)
ck('near_rectangle',u*F(3,2)**2==F(27,80) and u*F(3,2)==F(9,40))
ck('far_rectangle',2*u*3==F(9,10) and u*F(9,10)<F(3,8)**2)
for name,z,k,value,threshold in [('e3',F(3),8,F(89641,4480),20),('e9over8',F(9,8),4,F(100331,32768),3)]:
    q=sum((z**j/factorial(j) for j in range(k+1)),F(0))
    ck(name,q==value and q>threshold)
ck('new_baseline',F(3,8)*F(2,3)==F(1,4))
ck('mills_cutoff_ca_bound',F(2,5)*u==F(3,50) and F(3,50)<F(1,2))
ck('affine_threshold_AG_A1',u/50==F(3,1000))
for line in (p/'INPUT_SHA256SUMS').read_text().splitlines():
    h,name=line.split()
    ck('hash_'+name,hashlib.sha256((p/name).read_bytes()).hexdigest()==h)
print(json.dumps({'status':'PASS','number_of_checks':len(tests),'checks':tests,'scope':'Independent finite rational/source/hash checks; analytic review is separate.'},indent=2))
