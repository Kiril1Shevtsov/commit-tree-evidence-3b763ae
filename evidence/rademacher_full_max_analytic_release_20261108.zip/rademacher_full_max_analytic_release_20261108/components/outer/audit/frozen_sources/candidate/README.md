# Whole outer weak-upper candidate

Status: PRIMARY CANDIDATE, pending independent audit.

The new PROOF.md covers P(|X|<=x)<=H(x)+H(m) for every normalized finite independent Rademacher sum, every actual m>=3/20, and every x>=m. The accepted analytic small-max upper result already handles m<=3/20, so acceptance would finish the entire outer upper region. The central upper interval 0<=x<m in the middle-max range is explicitly NOT claimed here.

The proof uses only accepted actual-frequency reflection/Prawitz, new elementary phase estimates, a monotonicity reduction at fixed z=x+m, two polynomial identities (degrees 8 and 15, 25 positive Bernstein coefficients), and a maximum-coefficient split followed by the fourth-moment bound. It does not use the currently pending sharp cap-defect reflection lemma or any unrestricted q assertion.

Read PROOF.md and AUDIT_REQUEST.md. Run `python -I -S -B check_exact.py` for 27 primary rational checks. They are not a substitute for independent analytic review. No quadrature or parameter mesh is used by the checker or claimed proof.

Frozen inputs retain their original bytes and statuses. Historical pending headers in source proofs are superseded only by the adjacent already accepted verdicts, not by this candidate. The old small-upper sources contain only the accepted analytic constant checks; no large coefficient certificate has been copied or replayed.

SOURCE_HASHES.json binds every file in this candidate directory except itself.
