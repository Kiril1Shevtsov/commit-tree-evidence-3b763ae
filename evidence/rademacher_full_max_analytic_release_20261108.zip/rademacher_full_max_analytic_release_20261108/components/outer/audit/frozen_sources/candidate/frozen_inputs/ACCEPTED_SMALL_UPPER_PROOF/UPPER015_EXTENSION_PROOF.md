# Weak upper-central extension through 3/20

## Exact statement and scope

Let X = sum b_i epsilon_i be a finite Rademacher sum with sum b_i^2 = 1, where the epsilon_i are independent uniform signs. If 0 < a <= 3/20 is any upper bound for max_i |b_i|, then, for every x >= 0,

    P(|X| <= x) <= H(x) + H(a),  H(t) = 2 Phi(t) - 1.

Moreover, for 0 <= x <= a,

    P(|X| <= x) <= H(x) + H(a) - (a^3 + x a^2)/50.

The events are weak at both endpoints. This is only the upper-central statement. In particular, this file does not prove the strict lower-central estimate, or the full two-sided Kolmogorov bound, for a > 1/10. It does not certify the remaining author witnesses. No priority assertion is made.

This is an extension of the separately audited reconstructed proof through 1/10. Its exact base text is included as BASE_RECONSTRUCTED_PROOF.md (SHA-256 07bd75b6e73e85f962e8efd7e10259f3a394d520d5afc84644d5f8e8b25fb2be), together with its symbolic identities in BASE_independent_exact_audit.py. References below to a base formula mean the displayed formula in that immutable file, not a proposed replacement of the entire base theorem. Its historical pre-audit status paragraph is retained as provenance; the current new extension has its own audit.

The smoothing input is Keller and Klein, Proof of Tomaszewski's Conjecture on Randomly Signed Sums, Theorem 4.5, equations (39)-(40), and Section 4.1.2:
https://arxiv.org/html/2006.16834v4#S4.SS1.SSS1
It includes the weak upper-central event even when X has an atom. The coefficient signs may be absorbed into the signs and zero coefficients deleted.

## 1. The central affine bound survives on the enlarged interval

Use all definitions and displayed central/reflected majorants from the base section “The small central interval,” with T = pi/a. Put

    u = 3/20, r = 1/2, s = 9/10, eta = 10^-80, mu = 1/50.

The profile monotonicity, nonnegative weights, Hölder argument, polynomial majorant P_e, and Gaussian moment identities do not assume a <= 1/10. They hold throughout the present range. In the three positive Laurent-Gaussian tail majorants, the least powers of a are -5, -4 and -5. Thus each is increasing on (0,u] because

    (pi/(9u))^2 - 5 > 0,

and the central-tail version has an even larger margin. They tend to zero as a decreases to zero. The separate exact rational outward-interval computation certify_affine015.py verifies this monotonicity margin, the six base gap formulas AG, BG, A1, B1, A2, B2 with these new parameters, and central_tail/a^3 < eta. It proves AG,A1 > u/50 and BG,B1,A2,B2 > 1/50. In particular, B2 > 0.021531349091266367, and central_tail/a^3 < 5.018861 * 10^-91 < eta. The endpoint comparisons are exact rational comparisons; displayed decimals are summaries only.

The derivation of the base six gap formulas drops only positive remainders, leaving nonpositive nonconstant coefficients. Endpoint evaluation at u is therefore still uniform over all 0<a<=u. The differing normalizations of AG,A1 (a^2) and A2 (a^3) explain the two different thresholds.

It follows, exactly as in the base proof, that A_e <= H(a)-a^3/50 and B_e <= H(a)/a-a^2/50 for every 0<e<=a. Concavity of H on [0,infinity) gives the claimed strengthened estimate on 0<=x<=a. No nonatomic approximation is used.

## 2. Signed estimate and common tail budget

Keep K=1/30 and c_R=3/200. All algebraic identities in the base sections “The signed smoothing estimates outside the small interval” and “Exact polynomial sign checks” remain unchanged. We use only the plus sign. In particular, for a<=x<=x_E, with xi=x/a and x_E=sqrt(2 log(1/c_a)), c_a=H(a)/2, the upper error F_+ satisfies the base master inequality, provided its remainders are absorbed into c_R a^4.

The reductions preceding that master inequality are independent of the old 1/10 cutoff, except for the explicit tail/cutoff budgets checked here. Since phi_0>3/8 and u=3/20,

    c_a >= phi_0 a (1-a^2/6) > a/3,
    x_E^2 <= 2 log(3/a) <= 6/a <= 1/a^2.

The last step is valid because 6a<=9/10<1. Hence xi<=a^-2 on x<=x_E. The base absolute-tail derivations consequently yield

    epsilon_E <= 6a^2 exp(-1/(2a^2)),
    epsilon_D <= 4a^-2 exp(-1/(2a^2)),
    D2 <= 4 exp(-1/(2a^2)).

For clarity, their more precise prefactors remain valid at the new endpoint: using pi>3, the epsilon_E coefficient is at most

    2/9 + 1/27 + 2/9 + u^2/81 = 5203/10800 < 1;

and the epsilon_D coefficient after multiplication by a^2 is at most

    1/6 + 11u^2/18 + 2u^4/9 = 43327/240000 < 4.

The D2 coefficient is at most 20u^2/27<4. Their sum divided by a^4 is bounded by 14a^-6 exp(-1/(2a^2)). This increases on (0,u] because 1-6u^2>0. As 1/(2u^2)=200/9>22 and e>8/3,

    14u^-6 (3/8)^22 = 4708235109375/9007199254740992 < 1/1500.

Using pi>25/8,

    2/(45pi) + 1/1500 < 16/1125 + 1/1500
                              = 3/200 - 1/9000 < c_R.

This replaces, rather than reuses, the old 1/10000 tail budget.

## 3. The interval a<=x<=1

Apply the unchanged plus-sign polynomial from the base proof and divide by xi^2. Its negative constant is at most -3/16. The same positive bound is

    S = u[29/81 + (2/25)(13/9)^2 + 3/200] + 1/20 + u/15
        + u^2/20 + 5u^2/12 + 8u^3/45 + 7u^4/6.

The exact margin at the new endpoint is

    3/16 - S = 300833/8640000 > 0.

Thus F_+<0 on the whole of this interval. This step does not assert the corresponding minus-sign budget.

## 4. Split the large-x estimate at 3/2

For bounds ax^2<=L and ax<=U, set V=uL/2+u^2U/3. The base large-x upper budget is

    B(L,U) = u^2/15 + 2u/9 + 4u^2/81 + U/10 + 2u^3/27
           + u^2U/5 + 8u^5/45 + V/2 + 7u^2V/5
           + (2/25)[L + 8uU/9 + 16u^3/81] + 8uU/81 + 3u^3/200.

All terms are nonnegative, so the following rectangle bounds are legitimate.

On 1<=x<=min(3/2,x_E), take L=27/80 and U=9/40. These follow directly from a<=u. The base negative estimate from exp(1/2)>=13/8 is -15/104+u^2/15; the u^2/15 term is already included in B. Exact arithmetic gives

    15/104 - B(27/80,9/40) = 34933891/936000000 > 0.

On 3/2<=x<=x_E, improve the negative constant. The degree-four positive exponential sum gives

    exp(9/8) > sum_(j=0)^4 (9/8)^j/j! = 100331/32768 > 3.

Hence (a phi(x)-c_a)/a <= -(2/3)phi_0+phi_0 u^2/6
                                  < -1/4 + u^2/15.

For the cutoff rectangle, the degree-eight positive sum is

    exp(3) > sum_(j=0)^8 3^j/j! = 89641/4480 > 20.

Thus log20<3. The function a log(3/a) increases on (0,u], so ax^2 <= 2a log(3/a) < 2u*3 = 9/10. Also (ax)^2 <= u*(9/10)=27/200 < (3/8)^2. Take L=9/10 and U=3/8. The exact margin is

    1/4 - B(9/10,3/8) = 5335099/96000000 > 0.

If a displayed interval is empty there is nothing to prove on it. Otherwise these two intervals meet at 3/2 and cover [1,x_E].

## 5. Cutoff, endpoints and uniformity

Since c_a<=phi_0 a<3/50, x_E>1. For example e^(1/2)<2 implies exp(-1/2)>1/2>3/50. For x>=x_E, Mills gives

    1-Phi(x) <= phi(x)/x <= phi_0 c_a/x <= c_a.

Therefore H(x)+H(a)>=1, and the upper-central estimate follows from probability <=1. The intervals [0,a], [a,1], [1,3/2], [3/2,x_E] when nonempty, and [x_E,infinity) cover all nonnegative x with their endpoints. All inequalities used the weak central event; no mass is lost at zero or another atom. The proof is uniform for every positive a, including arbitrarily small a; no limiting theorem at a=0 is needed.

## Exact checks and limitations

Run from this directory:

    python3 certify_affine015.py
    python3 check_upper015_budgets.py

The first uses Python standard-library Fraction arithmetic with outward dyadic rounding, exact Machin bounds for pi, integer-square-root bounds, and a positive exponential series with an explicit remainder. It makes 14 exact interval decisions. The second independently replays the 93 unchanged symbolic checks in the base file, those 14 interval decisions, and 23 new exact budget checks. SymPy is used for exact symbolic algebra in the copied base checker. Neither checker uses floating-point acceptance.

The written analytic derivations and external smoothing theorem still require an independent mathematical review. That review and its exact artifact hashes are recorded in a separate audit directory. This extension alone never permits the claim that the full Keller-Klein conjecture is solved.
