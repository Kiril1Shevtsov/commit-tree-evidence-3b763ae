# Independent outer-upper audit

Verdict: PASS for the submitted outer weak-upper theorem, with no primary correction required.

Accepted new scope: P(|X|<=x)<=H(x)+H(m) for every normalized finite independent Rademacher sum with actual m>=3/20 and every x>=m. With the retained small-maximum theorem this covers all actual m in the outer region.

This does not accept the remaining central-upper region, a full max-coefficient Kolmogorov theorem, or the unrestricted q conjecture.

- INDEPENDENT_AUDIT.md: complete mathematical review.
- AUDIT_VERDICT.json: exact scope and reviewed SHA-256.
- independent_exact_checks.py: independently authored rational reconstruction.
- INDEPENDENT_EXACT_RESULTS.json: 61 exact checks and complete polynomial coefficients.
- frozen_sources/candidate/: immutable snapshot of the submitted packet.
- FROZEN_SOURCE_HASHES.json and INTEGRITY_CHECKS.json: 41 frozen files and 40 verified source-manifest entries.
- SHA256SUMS: hashes for this audit package, excluding this hash file itself.

Reproduce the exact checks with:

    python -I -S -B independent_exact_checks.py

No primary checker, numerical mesh, numerical quadrature, or floating-point acceptance test is used.
