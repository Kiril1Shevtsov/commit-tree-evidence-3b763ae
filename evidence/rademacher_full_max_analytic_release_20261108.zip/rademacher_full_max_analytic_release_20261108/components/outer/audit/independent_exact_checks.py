#!/usr/bin/env python3
"""Independently reconstruct the submitted analytic identities using rationals.

No primary code is imported or executed. No sampling, quadrature, or floating
point operation is used. Bernstein conversion uses triangular elimination.
"""
from fractions import Fraction as F
from math import comb, factorial
from pathlib import Path
import json


def trim(p):
    p = list(map(F, p))
    while len(p) > 1 and p[-1] == 0:
        p.pop()
    return p


def add(a, b):
    return trim([(a[i] if i < len(a) else 0) +
                 (b[i] if i < len(b) else 0)
                 for i in range(max(len(a), len(b)))])


def scale(a, q):
    return trim([F(q)*v for v in a])


def sub(a, b):
    return add(a, scale(b, -1))


def mul(a, b):
    p = [F(0)] * (len(a)+len(b)-1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            p[i+j] += x*y
    return trim(p)


def power(a, n):
    p = [F(1)]
    for _ in range(n):
        p = mul(p, a)
    return p


def compose(a, b):
    p = [F(0)]
    for q in reversed(a):
        p = add(mul(p, b), [q])
    return p


def derivative(a):
    return trim([i*a[i] for i in range(1, len(a))] or [0])


def evaluate(a, x):
    return compose(a, [F(x)])[0]


def U(t, j):
    p = [F(0)]
    for k in range(j+1):
        p = add(p, scale(power(t, 2*k+1),
                         F((-1)**k, 2**k*factorial(k)*(2*k+1))))
    return p


def exp_partial(x, n):
    return sum((x**k/F(factorial(k)) for k in range(n+1)), F(0))


def bernstein(p, a, b):
    n = len(p)-1
    affine = compose(p, [a, b-a])
    remainder = list(affine)
    coefficients = []
    reconstruction = [F(0)]
    for j in range(n+1):
        basis = scale(mul([0]*j+[1], power([1,-1], n-j)), comb(n,j))
        bj = remainder[j]/comb(n,j) if j < len(remainder) else F(0)
        coefficients.append(bj)
        contribution = scale(basis, bj)
        reconstruction = add(reconstruction, contribution)
        remainder = sub(remainder, contribution)
    if trim(remainder) != [0] or trim(reconstruction) != trim(affine):
        raise ValueError('Bernstein reconstruction failure')
    return coefficients


checks = []


def check(name, condition, details=None):
    if not condition:
        raise RuntimeError(name)
    checks.append({'name': name, 'pass': True, 'details': details})


z = [F(0),F(1)]
one = [F(1)]
z2 = power(z,2)
denD = add(one,scale(z2,F(1,3)))
denE = add(add(one,scale(z2,F(1,2))),scale(power(z,4),F(1,8)))
C = F(32,125)


def bracket_numerator(m):
    # D_+ = z / denD, N_+ = z + (1-z^2) z / denD.
    Nnum = add(mul(z,denD),mul(sub(one,z2),z))
    p = mul(mul(power(m,2),z),z)
    p = sub(p,scale(mul(power(m,3),Nnum),F(2,3)))
    rest = add(scale(power(m,4),F(4,9)),
               scale(mul(z,power(m,5)),F(8,45)))
    rest = add(rest,scale(power(m,6),F(4,9)))
    return add(p,mul(denD,rest))


m = scale(z,F(1,2))
A1 = sub(scale(U(m,3),2),U(z,4))
A1 = sub(A1,scale(mul(power(z,3),[1,0,F(-1,2),0,F(1,8)]),F(1,24)))
A1 = sub(A1,scale(power(z,5),F(1,160)))
tail1 = scale(mul([F(11,42),0,F(6,35)],power(z,6)),F(250,199)*F(3,250))
A1 = sub(A1,tail1)
P1numer = sub(mul(denD,A1),scale(bracket_numerator(m),C))
check('P1 divisibility by z^3',P1numer[:3] == [0,0,0])
P1 = trim(P1numer[3:])
check('P1 degree 8',len(P1)-1 == 8)
expected1 = list(map(F,[
    '1/12','593/7500','42433/560000','21272898517/292530000000',
    '20190630563/292530000000','154580224633/2437750000000',
    '197165105447/3656625000000','2418447827/65296875000',
    '972919317/174125000000']))
b1 = bernstein(P1,F(0),F(6,5))
check('P1 Bernstein identity',b1 == expected1)
for i,b in enumerate(b1):
    check('P1 positive Bernstein coefficient '+str(i),b>0,str(b))

m = [F(3,5)]
A2 = sub(add(U(m,3),U(sub(z,m),3)),U(z,4))
A2 = sub(A2,scale(mul(z,power(m,4)),F(1,10)))
A2 = sub(A2,scale(mul(power(m,2),power(z,4)),F(7,300)))
A2 = sub(A2,scale(power(m,2),F(7,450)))
P2 = mul(mul(denD,denE),A2)
P2 = sub(P2,scale(mul(denD,mul(power(m,2),z)),F(1,6)))
P2 = sub(P2,scale(mul(denE,bracket_numerator(m)),C))
check('P2 degree 15',len(P2)-1 == 15)
expected2 = list(map(F,[
    '31650029591/1220703125000','6227427693989/146484375000000',
    '373289752955369/6152343750000000','34295992298550533/426562500000000000',
    '16007574343110667/157500000000000000','2035421678903465117/16380000000000000000',
    '2310202138849555337/15600000000000000000','1797366513725811099/10400000000000000000',
    '222438105360351333949/1123200000000000000000','561421349814364778677/2515968000000000000000',
    '114876660698882773577/464486400000000000000','5578726893567828713387/20702822400000000000000',
    '22267963180755661814699/77290536960000000000000','1719521299781415414827/5707608883200000000000',
    '499532169214327384507/1630745395200000000000','10428401970429210521/34789235097600000000']))
b2 = bernstein(P2,F(6,5),F(7,4))
check('P2 Bernstein identity',b2 == expected2)
for i,b in enumerate(b2):
    check('P2 positive Bernstein coefficient '+str(i),b>0,str(b))

# New and inherited trigonometric polynomial identities.
sine5=[0,1,0,F(-1,6),0,F(1,120)]
sine7=add(sine5,[0]*7+[F(-1,5040)])
sine11=add(sine7,[0]*9+[F(1,362880),0,F(-1,39916800)])
prod=sub(mul([1,0,F(1,6),0,F(7,360)],sine5),z)
check('lower v/sin polynomial',prod == [0]*7+[F(-1,540),0,F(7,43200)])
check('lower v/sin remainder negative',F(-1,540)+F(7,43200)*F(5,2)<0)
prod=sub(mul([1,0,F(1,6),0,F(1,30)],sine7),z)
check('upper 1/sin polynomial',prod == scale([0]*5+[2100,0,-660,0,37,0,-1],F(1,151200)))
check('upper 1/sin positive margin',2100-660*F(5,2)-F(5,2)**3>0)
Rlower=sub([1,0,F(1,6),0,F(7,360)],[1,0,F(-1,2),0,F(1,24)])
check('lower R polynomial',Rlower == [0,0,F(2,3),0,F(-1,45)])
Rupper=add(sub(scale(mul(z2,sine7),F(2,3)),z),scale(compose(sine11,scale(z,2)),F(1,2)))
check('upper R polynomial',Rupper == [0]*5+[F(1,45),0,F(-1,140),0,F(13,22680),0,F(-4,155925)])
check('upper R positive remainder',F(1,45)-F(5,2)/140-F(4,155925)*F(5,2)**3 == F(989,249480))
prod=sub(mul([1,0,F(1,4)],sine7),z)
check('upper v/sin polynomial',prod == [0]*3+[F(1,12),0,F(-1,30),0,F(38,20160),0,F(-1,20160)])

# ODE residuals for Dawson rational comparisons, after multiplication by denominator squared.
for a,expected,label in [(F(1),[0,0,-2],'lower'),(F(1,3),[0,0,0,0,F(2,9)],'upper')]:
    den=[1,0,a]
    residual=add(sub(den,mul(z,derivative(den))),sub(mul(z2,den),power(den,2)))
    check('Dawson '+label+' rational residual',residual == trim(expected))

# Exact scalar inequalities used to replace pi, Gaussian and exponential terms.
piL=F(157,50)
piU=F(22,7)
cL=F(199,250)
check('c0 lower from pi upper',F(2)/piU>cL**2)
check('C upper from pi lower',F(2)/F(25,8)**3 == C**2)
check('pi lower implies phi(0)<2/5',F(1)/(2*F(25,8)) == F(2,5)**2)
check('pi^2/4<5/2',piU**2/4<F(5,2))
check('deficit endpoint pi^4/96>1',piL**4/96>1)
check('boundary 1 exponential majorant',F(216)/(F(8,3)**3*piL**6)<F(3,250))
check('boundary 1 tail coefficient constant',piU/12 == F(11,42))
check('boundary 1 tail coefficient quadratic',F(1)/(3*piL)+F(2)/piL**3<F(6,35))
check('tail maximizer lower root bracket',4*F(21,8)-3>0 and (4*F(21,8)-3)**2<57)
check('tail maximizer upper root bracket',(4*F(53,20)-3)**2>57)
check('exp(21/8)>55/4',exp_partial(F(21,8),10)>F(55,4))
tailbound=F(53,20)**2*(2*F(53,20)+3)/F(55,4)
check('tail maximum rational bound',tailbound == F(233147,55000) and tailbound<F(17,4))
check('17/pi^4<7/40',F(17)/piL**4<F(7,40))
check('degree 9 exp at fixed cutoff exceeds 30',exp_partial(piL**2*F(25,72),9)>30)
check('fixed cutoff coefficient bound',F(2,5)*(F(8)/F(25,8)**2+F(1,3))<F(7,15))
check('e>8/3 via positive Taylor sum',exp_partial(F(1),4)>F(8,3))

join1=cL*(evaluate(U(z,5),F(3,20))+evaluate(U(z,5),F(8,5)))-1
check('large z join rational identity',join1 == F(26224621137160720607,3892838400000000000000) and join1>0)
join2=cL*(evaluate(U(z,1),F(3,5))+evaluate(U(z,1),F(9,10)))-1
check('large x join rational identity',join2 == F(6863,100000) and join2>0)
check('Paley variance ratio anchor',(F(9,10)-F(3,5))**2/(1-F(3,5)**2) == F(9,64))
paley=1-F(55,64)**2/6
check('Paley upper rational identity',paley == F(21551,24576))
join3=2*cL*evaluate(U(z,1),F(3,5))-paley
check('large max join rational identity',join3 == F(8054617,384000000) and join3>0)

data = {
    'status':'PASS', 'arithmetic':'integer and fractions.Fraction only',
    'check_count':len(checks), 'checks':checks,
    'P1_power_coefficients':[str(v) for v in P1],
    'P2_power_coefficients':[str(v) for v in P2],
    'P1_Bernstein_coefficients':[str(v) for v in b1],
    'P2_Bernstein_coefficients':[str(v) for v in b2],
}
out=Path(__file__).with_name('INDEPENDENT_EXACT_RESULTS.json')
out.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({'status':'PASS','check_count':len(checks),'output':str(out)}))
