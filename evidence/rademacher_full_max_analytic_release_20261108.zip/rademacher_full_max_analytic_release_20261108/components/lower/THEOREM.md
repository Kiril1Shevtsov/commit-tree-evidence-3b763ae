# Full analytic strict lower-central theorem

Let X = sum_i a_i epsilon_i be any finite sum of independent unbiased signs,
with sum_i a_i^2 = 1. Put m = max_i |a_i| and H(x) = 2 Phi(x) - 1.
Then, for every x >= 0,

    P(|X| < x) >= H(x) - H(m).

There is no additional restriction on m, dimension, coefficient shape,
parity or lattice structure. The event is strict. The inequality can be an
equality, in particular at x=m for odd flat profiles.

The proof uses the published Prawitz inequality, an accepted actual-frequency
reflection and central rectangle, a new global phase envelope, a Gaussian
integral budget, concavity, three exact polynomial positivity identities,
and elementary second-moment tail comparisons. The finite arithmetic scripts
verify displayed identities; they do not enumerate coefficient arrays or
perform numerical quadrature.

This is the entire LOWER-CENTRAL side of the maximum-coefficient theorem.
The weak upper-central side in the middle maximum range remains open
analytically. This package does not prove the unrestricted full Kolmogorov
theorem analytically or the stronger fourth-moment q conjecture.

The independent audit is internal mathematical checking, not external peer
review or proof-assistant formal verification. No novelty claim is made.
