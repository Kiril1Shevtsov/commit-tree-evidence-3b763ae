#!/usr/bin/env python3
"""Offline payload integrity and exact-arithmetic replay, not formal proof."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent

def need(ok, message):
    if not ok:
        raise RuntimeError(message)

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def verify(root):
    manifest = json.loads((root / 'MANIFEST.json').read_text())
    need(manifest['schema'] == 'analytic-full-lower-v1', 'wrong schema')
    records = manifest['files']
    actual = set()
    for p in root.rglob('*'):
        need(not p.is_symlink(), 'symlink forbidden')
        if p.is_file():
            actual.add(p.relative_to(root).as_posix())
    need(actual == set(records) | {'MANIFEST.json'}, 'inventory mismatch')
    for rel, expected in records.items():
        pp = PurePosixPath(rel)
        need(not pp.is_absolute() and '..' not in pp.parts and str(pp) == rel, 'unsafe path')
        need(digest(root / rel) == expected, 'hash mismatch: ' + rel)
    status = json.loads((root / 'STATUS.json').read_text())
    need(status['accepted_scope'] == 'all finite normalized Rademacher sums, all 0<m<=1, all x>=0, strict lower-central side', 'scope drift')
    need(status['full_analytic_upper_side'] is False, 'upper scope drift')
    need(status['unrestricted_q_theorem'] is False, 'q scope drift')
    need(status['formal_proof_assistant_verification'] is False, 'formal verification drift')
    need(digest(root / 'primary/PROOF.md') == 'a01325278bbcfaaae016dcfe1b18df39431573a9d7a13c50abfa792324988d8d', 'wrong primary version')
    source_map = json.loads((root / 'SOURCE_MAP.json').read_text())
    for record in source_map['sources']:
        need(digest(root / record['archive_relative_path']) == record['sha256'], 'source map mismatch')
    primary_hashes = json.loads((root / 'primary/SOURCE_HASHES.json').read_text())['files']
    for rel, expected in primary_hashes.items():
        need(digest(root / 'primary' / rel) == expected, 'primary source mismatch')
    frozen = json.loads((root / 'audit/FROZEN_SOURCE_HASHES.json').read_text())['files']
    for record in frozen:
        need(digest(root / 'audit' / record['frozen_path']) == record['sha256'], 'audit frozen mismatch')
        need(digest(root / 'primary' / record['relative_path']) == record['sha256'], 'audit/primary mismatch')
    expected = (root / 'audit/INDEPENDENT_EXACT_RESULTS.json').read_bytes()
    with tempfile.TemporaryDirectory(prefix='full_lower_exact_') as td:
        script = Path(td) / 'independent_exact_checks.py'
        shutil.copyfile(root / 'audit/independent_exact_checks.py', script)
        run = subprocess.run([sys.executable, '-I', '-S', str(script)], capture_output=True, text=True)
        need(run.returncode == 0, 'independent checker failed: ' + run.stderr)
        observed = script.with_name('INDEPENDENT_EXACT_RESULTS.json').read_bytes()
        need(observed == expected, 'exact output mismatch')
    result = json.loads(expected)
    need(result['status'] == 'PASS' and result['checks_count'] == 56, 'wrong exact check result')
    need(sum(len(b['coefficients']) for b in result['bernstein']) == 25, 'wrong Bernstein count')
    return {'status':'PASS', 'files':len(records), 'independent_exact_checks':56,
            'positive_Bernstein_coefficients':25, 'exact_output_byte_identical':True,
            'primary_checker_executed':False, 'old_numerical_certificates_executed':False}

def negative_controls(root):
    outcomes = []
    for mode in ('modified_proof', 'missing_status', 'unexpected_file'):
        with tempfile.TemporaryDirectory(prefix='full_lower_negative_') as td:
            dest = Path(td) / 'release'
            shutil.copytree(root, dest)
            if mode == 'modified_proof':
                p = dest / 'primary/PROOF.md'
                p.write_bytes(p.read_bytes() + b'\nmodified\n')
            elif mode == 'missing_status':
                (dest / 'STATUS.json').unlink()
            else:
                (dest / 'UNEXPECTED.txt').write_text('unexpected')
            try:
                verify(dest)
            except RuntimeError:
                outcomes.append({'control':mode, 'result':'REJECTED_AS_EXPECTED'})
            else:
                raise RuntimeError('negative control accepted: ' + mode)
    return outcomes

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--negative-controls', action='store_true')
    args = parser.parse_args()
    result = verify(ROOT)
    if args.negative_controls:
        result['negative_controls'] = negative_controls(ROOT)
    print(json.dumps(result, indent=2))
