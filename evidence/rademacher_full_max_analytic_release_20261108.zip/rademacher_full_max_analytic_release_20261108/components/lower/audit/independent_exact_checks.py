#!/usr/bin/env python3
"""Independent rational reconstruction of the displayed finite identities.
No primary checker is imported or executed. No floating arithmetic, mesh,
quadrature, or numerical coefficient certificate is used.
"""
from fractions import Fraction as F
from math import comb, factorial
import json
from pathlib import Path

checks=[]
def record(name, actual, expected=None, positive=False):
    if expected is not None:
        assert actual==expected,(name,actual,expected)
    if positive:
        assert actual>0,(name,actual)
    checks.append({'name':name,'result':'PASS','value':str(actual)})
    return actual

def add_term(poly, key, value):
    poly[key]=poly.get(key,F(0))+value
    if not poly[key]: del poly[key]

def uni_add(a,b):
    ans=dict(a)
    for k,v in b.items(): add_term(ans,k,v)
    return ans

def uni_scale(a,c):
    return {k:v*c for k,v in a.items() if v*c}

def uni_mul(a,b):
    ans={}
    for i,x in a.items():
        for j,y in b.items(): add_term(ans,i+j,x*y)
    return ans

def uni_pow(a,n):
    ans={0:F(1)}
    for _ in range(n): ans=uni_mul(ans,a)
    return ans

# P(m,y) from its integral definition, with keys (degree_m, degree_y).
P={}
for r in range(4):
    add_term(P,(2*r+1,0),F((-1)**r,2**r*factorial(r)*(2*r+1)))
for r in range(5):
    c=F((-1)**r,2**r*factorial(r))
    for j in range(2*r+1):
        add_term(P,(j+1,2*r-j),-c*F(comb(2*r,j),j+1))
add_term(P,(2,1),-F(1,4))
for jm in range(3):
    add_term(P,(2+jm,2-jm),-F(32,125)*comb(2,jm)*F(2,3)**jm)
add_term(P,(6,0),-F(57,500))
add_term(P,(2,4),-F(1,198))

qdiag={}
for (dm,dy),c in P.items(): add_term(qdiag,dm+dy,c)
assert all(d>=3 for d in qdiag)
qdiag={d-3:c for d,c in qdiag.items()}
record('P(y,y)/y^3 expanded polynomial',qdiag,{
    0:F(3564000,4752000),1:-F(3379200,4752000),
    2:-F(3564000,4752000),3:-F(565728,4752000),
    4:F(1782000,4752000),6:-F(702625,4752000)})

def specialize_m(m):
    q={}
    for (dm,dy),c in P.items(): add_term(q,dy,c*m**dm)
    return q

submitted=[
[F(3,4),F(73,108),F(4025,6912),F(1896667,4055040),F(16277801,48660480),F(1837985,9732096),F(318195043,9965666304)],
[F(64837151,2433024000),F(388211699,9732096000),F(1828700011,34062336000),F(898744123,13624934400),F(634655809,8515584000),F(5266501193,68124672000),F(2458386589,34062336000),F(539461661,9732096000),F(8099161,486604800)],
[F(39774380375,5102421147648),F(376329364925,40819369181184),F(1502047332355,142867792134144),F(29967996047845,2571620258414592),F(24329176440605,1928715193810944),F(103156268402575,7714860775243776),F(482518988593625,34716873488596992),F(140560921640215,9919106711027712),F(52669963368845,3719665016635392)]
]
bernstein_results=[]
for label,q,a,b,expected in zip(['a','b','c'],[qdiag,specialize_m(F(1,2)),specialize_m(F(5,8))],[F(0),F(1,2),F(5,8)],[F(5,8),F(3,2),F(5,6)],submitted):
    n=max(q)
    # First substitute y=a+(b-a)s directly in each monomial.
    substituted={}
    for d,c in q.items():
        substituted=uni_add(substituted,uni_scale(uni_pow({0:a,1:b-a},d),c))
    # Triangular basis elimination, not the usual binomial-conversion formula.
    remainder=dict(substituted)
    coeff=[]
    reconstructed={}
    for j in range(n+1):
        bj=remainder.get(j,F(0))/comb(n,j)
        coeff.append(bj)
        basis=uni_mul({j:F(comb(n,j))},uni_pow({0:F(1),1:F(-1)},n-j))
        term=uni_scale(basis,bj)
        reconstructed=uni_add(reconstructed,term)
        remainder=uni_add(remainder,uni_scale(term,-1))
    record('Bernstein '+label+' complete expansion',reconstructed,substituted)
    record('Bernstein '+label+' eliminated remainder',remainder,{})
    for j,(actual,wanted) in enumerate(zip(coeff,expected)):
        record('Bernstein '+label+' coefficient '+str(j),actual,wanted,positive=True)
    assert len(coeff)==len(expected)
    bernstein_results.append({'label':label,'interval':[str(a),str(b)],'degree':n,'coefficients':[str(c) for c in coeff],'minimum':str(min(coeff))})

# Independent exact trigonometric lower-polynomial constructions.
sin7={2*r+1:F((-1)**r,factorial(2*r+1)) for r in range(4)}
sin2_11={2*r+1:F((-1)**r*2**(2*r+1),factorial(2*r+1)) for r in range(6)}
trig1=uni_add(uni_add(uni_mul({2:F(2,3)},sin7),{1:F(-1)}),uni_scale(sin2_11,F(1,2)))
record('R upper-bound sine Taylor identity',trig1,{5:F(1,45),7:-F(1,140),9:F(13,22680),11:-F(4,155925)})
record('R upper-bound bracket uniform margin',F(1,45)-F(5,2)/140-4*F(5,2)**3/155925,F(989,249480),positive=True)
trig2=uni_add(uni_mul({0:F(1),2:F(1,4)},sin7),{1:F(-1)})
record('v/sine upper-bound Taylor identity',trig2,{3:F(1,12),5:-F(1,30),7:F(38,20160),9:-F(1,20160)})
record('v/sine bracket nonnegative affine part at endpoint',F(1,12)-F(5,2)/30,F(0))
record('pi/2 squared upper bound below 5/2',F(5,2)-F(11,7)**2,positive=True)

# Gaussian moments: integral v^(2k+1) exp(-v^2/(2m^2)) dv
# has coefficient 2^k k! times m^(2k+2).
record('Gaussian third moment coefficient',2**1*factorial(1),2)
record('Gaussian fifth moment coefficient',2**2*factorial(2),8)
record('c0 lower-bound squared margin',F(7,11)-F(199,250)**2,positive=True)
record('phase coefficient squared anchor',2*F(8,25)**3,F(32,125)**2)
record('sixth-order coefficient upper margin',F(57,500)-F(4,9)*F(32,125),F(1,4500),positive=True)
record('negative-sine loss rational comparison',7*25**5-8*250*8**5,positive=True)
record('negative-sine normalized budget comparison',F(1,198)-F(1,199),positive=True)

def exp_partial(x,n): return sum((x**k/F(factorial(k)) for k in range(n+1)),F(0))
record('e squared greater than 7',exp_partial(F(2),5)-7,positive=True)
record('e greater than 8/3',exp_partial(F(1),4)-F(8,3),positive=True)
record('exp(9/8) greater than 3',exp_partial(F(9,8),4)-3,positive=True)
record('exp(3/2) greater than 3',exp_partial(F(3,2),2)-3,positive=True)
record('unbounded lower Gaussian bracket',F(23,24)-F(1,3),F(5,8))
margin=F(5,8)*F(199,250)-F(4,23)-48/(23*F(199,250)*F(25,8)**2)-1/(36*F(25,8)**2)-24/(23*F(199,250)*F(8,3)*F(25,8)**3)
record('unbounded-y margin',margin,F(14895943,411930000),positive=True)

def taylor_gaussian_integral(a,b,degree):
    return sum((F((-1)**r,2**r*factorial(r)*(2*r+1))*(b**(2*r+1)-a**(2*r+1)) for r in range(degree+1)),F(0))
join_a=F(4,5)*taylor_gaussian_integral(F(1,2),F(4,3),4)
record('Join A Taylor integral',join_a,F(26586523759,60949905408))
record('Join A positive margin',F(7,16)-join_a,F(79059857,60949905408),positive=True)
join_b=F(4,5)*taylor_gaussian_integral(F(5,8),F(5,4),2)
record('Join B Taylor integral',join_b,F(65129,196608))
record('Join B positive margin',F(9,25)-join_b,F(141247,4915200),positive=True)
record('Join B variance threshold',1/(4*F(5,8)**2),F(16,25))
record('Middle-range y coverage endpoint',F(4,3)-F(1,2),F(5,6))

out={'status':'PASS','method':'Independent Python Fraction polynomial construction and triangular Bernstein basis elimination; no primary checker execution, floating arithmetic, grid, or quadrature.','checks_count':len(checks),'checks':checks,'bernstein':bernstein_results,'P_terms':[{'m_degree':dm,'y_degree':dy,'coefficient':str(c)} for (dm,dy),c in sorted(P.items())]}
Path(__file__).with_name('INDEPENDENT_EXACT_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'checks_count':len(checks),'Bernstein_coefficients':sum(len(x['coefficients']) for x in bernstein_results)},indent=2))
