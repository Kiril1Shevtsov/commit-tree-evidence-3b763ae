# Independent audit: full lower-central phase closure

Verdict: **PASS**, 2026-11-08.

For every finite normalized sum of independent unbiased Rademacher signs with deterministic coefficients and actual maximum 0<m<=1,

    P(|X|<x)>=H(x)-H(m) for every x>=0.

The event is strict. The accepted x<=2m theorem is retained; the new x>2m argument is independently accepted here. This does not close the weak upper-central middle range or the full unrestricted max/q theorems.

- `AUDIT.md`: complete independent proof review, event conventions and parameter coverage.
- `VERDICT.json`: precise accepted scope and exclusions.
- `independent_exact_checks.py`: independently authored rational checker.
- `INDEPENDENT_EXACT_RESULTS.json`: 56 passing exact checks, all 25 Bernstein coefficients.
- `FROZEN_SOURCE_HASHES.json`: 44 frozen files including the candidate source manifest.
- `INHERITED_INTEGRITY.json`: 55 additional accepted-package integrity comparisons.
- `FINAL_INTEGRITY.json`: final original/frozen source verification.
- `AUDIT_MANIFEST.json`: hashes of this completed package, excluding itself.

Reproduce the finite algebra with:

    python -I -S -B independent_exact_checks.py

The primary checker was not executed. There is no grid, quadrature, floating acceptance test, or old numerical certificate dependency. The primary files were not edited.
