# Independent mathematical audit

Date: 2026-11-08. Verdict: **the stated mathematical reductions and adaptive obstruction are valid; the identified Section 3.1 domain wording issue has been corrected. They do not prove the original global theorem.**

Reviewed source is frozen as `REVIEWED_PROOF.md`, SHA-256 `f5dafe6ac8c97884f4a6d7d1009a539ee8095c4def32ba1b64558b96f9ebf829`. I did not inspect or execute the primary `check_exact.py`. My independently written `independent_checks.py` passed; output is in `CHECK_OUTPUT.txt`.

## Wording correction, now applied

The initial Section 3.1 conclusion used the unqualified “full weak upper-side max-coefficient inequality.” The corrected reviewed version explicitly says “the weak upper-central inequality (equivalently the weak upper CDF inequality at nonnegative endpoints),” resolving this issue. The proof deliberately uses x >= 0, and its curvature argument need not hold for x < 0. For a symmetric random variable, at y > 0,

    F(-y) - Phi(-y) = Phi(y) - P(X < y).

Thus negative weak-upper endpoints are exactly the positive strict-lower endpoints covered separately by Section 3.2. The two reductions together cover the full Kolmogorov problem, but Section 3.1 alone does not. This is a scope wording correction, not a failure of its nonnegative-endpoint argument.

## Section 1: adaptive obstruction verified

The strategy is predictable, has pathwise total squared increments 18 before normalization, and has maximum normalized increment 1/sqrt(18). Sign reversal preserves the branch condition, proving symmetry. Orthogonality of martingale differences gives variance one. Conditioning independently on the sixteen-sign prefix gives

    ordinary atom = 12155/65536,
    adaptive atom = 195481/1048576.

The extra contribution is exactly 2 binom(16,10)/2^24 = 1001/1048576. No ordinary atom contribution is removed on the modified branches.

Integrating exp(-t^2/2) <= 1 - t^2/2 + t^4/8 from 0 to 1/sqrt(18) gives the displayed Gaussian bound. The newly supplied Machin/arctangent estimate is correct: its rational lower bound exceeds 157/50 by 107/179250. The resulting rational upper bound for H is strictly below the adaptive atom by

    15395383/796262400000.

Consequently the central Kolmogorov deficit exceeds B(m). The finite-tree Bellman contradiction follows directly by backward induction and needs no integrability or regularity premise beyond the displayed finite values. Its scope is exactly the adaptive, arbitrary-midpoint-step relaxation; it does not refute the independent-sign conjecture or every possible Bellman formulation.

## Section 2: cancellation verified

Both translation-operator factorizations hold identically. The two-sign/eight-half-sign atom kernel at prefix values 0, +/-2, +/-4 is respectively -29/128, -9/64, 1/256. Independent prefix convolution gives 389389/4194304 for the static replacement, a change of -388531/4194304 from the ordinary atom. Thus selective adaptive use really does retain only the favorable part of a signed kernel. No universal CDF sign inference follows from the identity.

## Section 3.1: rational rays verified on x >= 0

Each fixed-endpoint domain x >= 0 is compact. The weak count is upper semicontinuous, so a maximizer exists. The arrangement fixes the count and makes m a fixed linear functional on each stratum. Every stratum of linear dimension at least two admits a two-sided great-circle variation inside that same stratum. Direct differentiation gives

    G_+'' = x phi(x)(1 + (x')^2) + m phi(m)(1 + (m')^2) > 0.

The strict sign uses m > 0 and x >= 0. This excludes a maximum in such a stratum, including strata where x is identically zero. The remaining one-dimensional cones are rational rays because the arrangement has rational normals. Finiteness holds only after n is fixed. No uniform-in-n list or Boolean-count estimate has been proved.

## Section 3.2: stationary reduction verified

The updated compactness argument is sound: p_- >= 1/2 at x > 0 implies any positive deficit has x > m, and m >= 1/sqrt(n). It therefore suffices to maximize on the compact domain x >= m. At a positive maximizer, this added inequality is inactive within its arrangement stratum.

Spherical stationarity is exactly phi(x)u - phi(m)v = lambda a with lambda = x phi(x) - m phi(m). If lambda is nonzero, a lies in the rational linear span of u and v. This is not a two-block coefficient classification, nor a claim that a itself has rational entries.

For independent u,v, Q is positive on the entire real line, and differentiation independently confirms

    (log r - N/(2Q))' = 1/r - (AD-C^2)[Cr^2-(A+D)r+C]/Q^2.

Its numerator after multiplication by r Q^2 is a nonzero quartic with leading coefficient A^2. Rolle's theorem gives at most five positive scalar roots. Orientation, r > 1, x > m > 0, and membership in the original cone remain necessary separate filters.

For lambda = 0, u = r v with r > 1, so x = r m and the proposed critical magnitude m^2 = 2 log(r)/(r^2-1) follows. The exception is handled correctly: stationarity does not force a into span(u,v). The scalar level may meet a higher-dimensional family, and actual cone feasibility must be checked. Parallel cases with lambda nonzero still belong to the earlier span reduction.

## Section 3.3: uniqueness verified

When dim L >= 3 and u,v are independent, a tangent direction orthogonal to both gives second variation -lambda. A local maximum therefore cannot have lambda < 0; lambda = 0 contradicts independence. Hence lambda > 0 and the plus orientation is mandatory. Positivity of m gives 1 < r < C/A, forcing C > A and D > A.

The convex quadratic K is strictly negative at both endpoints of this interval, hence throughout. The scalar equation's left-minus-right function is therefore strictly increasing. Its endpoint values are -(D-A)/2 and log(C/A)-(AD-C^2)/(2A), exactly as stated. An interior scalar root exists iff the latter is positive, and it is unique. A root is not automatically cone-feasible or a local maximum. The equality case reaches m = 0 and is inadmissible.

## Remaining gap

The audit establishes a genuine adaptive obstruction and finite-dimensional structural reductions. It does not supply the missing dimension-independent comparison of dyadic endpoint counts with Gaussian values at resonance rays or stationary candidates. The full analytic max-coefficient theorem and any unrestricted fourth-mass strengthening remain open within this branch.
