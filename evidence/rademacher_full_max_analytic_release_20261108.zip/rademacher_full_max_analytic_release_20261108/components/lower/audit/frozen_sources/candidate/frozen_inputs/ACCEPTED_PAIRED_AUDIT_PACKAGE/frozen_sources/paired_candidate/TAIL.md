# A complete Chebyshev tail bridge for m>=2/3

Date: 2026-11-08. Primary analytic proof; independent audit pending.

Let X be any random variable with E X^2=1. For every m in [2/3,1] and x>=2m,

    P(|X|<x)>=H(x)-H(m), H=2Phi-1.                     (1)

No independence, Rademacher factorization, or actual coefficient cap is needed for this tail statement.

## 1. A Gaussian derivative bound

For every t>0, t^3 phi(t)<1. Indeed t^3 exp(-t^2/2) is maximized at t=sqrt(3). Using sqrt(3)<2, phi(0)<2/5, and exp(3/2)>3,

    sup t^3 phi(t)=3sqrt(3)phi(0)exp(-3/2)<4/5<1.

The exponential bound follows from the first three positive series terms.

## 2. A single rational anchor

Define

    F(m)=H(m)+1-H(2m)-1/(4m^2).

Then

    F'(m)=2phi(m)+4[(2m)^(-3)-phi(2m)]>0.

At m=2/3, monotonicity of the Gaussian density gives

    H(4/3)-H(2/3)<= (4/3)phi(2/3)
                  < (8/15)exp(-2/9)
                  < (8/15)/(1+2/9)=24/55.

Hence

    F(2/3)>7/16-24/55=1/880>0.

Therefore F(m)>0 for every m>=2/3.

## 3. All larger thresholds and endpoint convention

For fixed m, let

    G_m(x)=H(m)+1-H(x)-1/x^2.

Its derivative is 2[x^(-3)-phi(x)]>0. Thus x>=2m implies G_m(x)>=F(m)>0. Markov's inequality for the WEAK event |X|>=x gives

    P(|X|<x)>=1-1/x^2>H(x)-H(m).

This proves (1), including x=2m, with no atom-continuity assumption.

## Conditional full-theorem consequence

If the independent audit accepts PROOF.md in this directory, its paired-integral result plus the previously accepted near-threshold bridge prove the lower-central target for all x<=2m. The present tail then proves the entire lower-central side for m>=2/3.

The existing separately audited elementary upper helper proves the weak upper-central side for m>=27/40: conditioning on the largest sign gives P(|X|<=x)<=1/2 for x<m, while H(27/40)>1/2; for x>=m the right side H(x)+H(m)>1. Thus, after the pending new audit, the full original max-coefficient theorem is computer-free for m>=27/40.

This does not prove the full analytic theorem in the remaining middle range 3/20<m<27/40, nor the unrestricted fourth-mass strengthening. The elementary Gaussian constant H(27/40)>1/2 and the upper helper are retained accepted analytic inputs, not inferred from a new numerical evaluation.
