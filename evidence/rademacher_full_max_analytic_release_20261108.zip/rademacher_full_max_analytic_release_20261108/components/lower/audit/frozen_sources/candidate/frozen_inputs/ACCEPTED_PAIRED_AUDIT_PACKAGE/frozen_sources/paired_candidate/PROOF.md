# Analytic closure of the paired lower-CDF rectangle

Date: 2026-11-08. Status: new primary proof, awaiting independent audit.

## Statement and scope

Retain the audited kernel

    k_xi(u)=(1-u)cos(pi xi u)
       -[(1-u)cot(pi u)+1/pi]sin(pi xi u),
    c_xi(u)=k_xi(u)+|k_xi(1-u)|.

For every real p>=1 and 7/6<=xi<=2, this note claims the strict inequality

    (2/pi) integral_0^(pi/2) W_xi(v)cos(v)^p dv
       > H(xi/sqrt(p))-H(1/sqrt(p)),                    (T)
    W_xi(v)=-c_xi(v/pi), H=2Phi-1.

All parameter ranges are continuous. No quadrature, coefficient grid, dimension bound or old large certificate is used. The two polynomial positivity checks below are displayed finite algebraic identities, not sampled inequalities.

Combined with the independently audited actual-frequency pairing and near-threshold bridge, (T) proves the original strict lower-central target for every normalized finite independent Rademacher sum with maximum m and every 0<=x<=2m. This is not the full lower side, not the upper side, and not the unrestricted q theorem.

## 1. A positive phase remainder in the paired kernel

Put delta=xi-1 in [0,1], v in (0,pi/2), w=pi/2-v, and

    R(v)=v/sin(v)-cos(v)>=0,
    C_delta=2sin(pi delta/2)/pi,
    D_delta=2cos(pi delta/2)/pi.

Let F_delta(v)=k_xi(1-v/pi)-k_xi(v/pi), and E_delta(v)=-k_xi(v/pi)-k_xi(1-v/pi). Then W=min(F,E). Direct trigonometric expansion gives

    F_delta(v)=sin(delta v)/sin v
       -C_delta R(v)cos(delta w)
       +C_delta sin v sin(delta w),                    (1)

    E_delta(v)=sin(delta v)/sin v
       +D_delta[R(v)sin(delta w)+sin v cos(delta w)].   (2)

### A monotone quotient

For 0<delta<=1 define

    N(v)=sin(delta v)-delta sin v cos v,
    Q(v)=v-sin v cos v.

Both vanish at zero and Q'(v)=2sin^2(v)>0. Their derivative quotient is

    N'(v)/Q'(v)
      =delta[1-(sin(delta v/2)/sin v)^2].

The ratio sin(delta v/2)/sin v is increasing on (0,pi/2): its logarithmic derivative has the sign of

    (delta v/2)cot(delta v/2)-v cot v>0,

because z cot z is decreasing on (0,pi/2). Therefore N'/Q' is decreasing. Expressing N(v)/Q(v) as the Q'-weighted average of N'/Q' on [0,v] proves that N/Q is decreasing. Hence

    N(v)/Q(v)>=N(pi/2)/Q(pi/2)=C_delta.

Equivalently,

    sin(delta v)/sin v-C_delta R(v)>=delta cos v.       (3)

All endpoint cases follow by continuity, and delta=0 is immediate.

Substitute (3) into (1), use R>=0, and use concavity sin(delta w)>=delta sin w=delta cos v. This gives

    F_delta(v)>=delta cos v
                   +delta C_delta sin v cos v.        (4)

Every extra term in (2) is nonnegative, and sin(delta v)>=delta sin v, so E_delta(v)>=delta. Consequently, for all delta in [0,1],

    W_xi(v)>=delta cos v.                              (5)

For delta<=1/2, the independently audited sign pattern has k_xi(1-u)<=0, so W=F. Since sinc decreases,

    C_delta/delta >= 2sqrt(2)/pi > 49/55 > 8/9.

Here sqrt(2)>7/5 and pi<22/7 suffice. Thus the stronger bound is

    W_xi(v)>=delta cos v+(8/9)delta^2 sin v cos v,
                          0<=delta<=1/2.              (6)

The endpoints v=0,pi/2 are retained by continuity. The endpoint xi=1 is not needed in (T).

## 2. A uniform elementary Gamma-ratio lower bound

Define

    A(p)=(2/pi) integral_0^(pi/2) cos(v)^(p+1) dv
        =Gamma((p+2)/2)/[sqrt(pi)Gamma((p+3)/2)].

For every p>=1,

    A(p)>=sqrt(2/(pi p)) [1-3/(4p)+1/(3p^2)].           (7)

Here are analytic and algebraic details of the bound.

For z>=1 put R_G(z)=sqrt(z)Gamma(z)/Gamma(z+1/2). The standard Euler-Gamma logarithmic derivative integral gives

    log R_G(z)=(1/2) integral_0^infinity
                     e^(-zt) tanh(t/4)/t dt.           (8)

One may obtain (8) by differentiating: psi(z+1/2)-psi(z) is the integral of e^(-zt)/(1+e^(-t/2)), so (log R_G)'=-(1/2) integral e^(-zt)tanh(t/4)dt; integration to infinity uses the usual Gamma-ratio limit R_G(infinity)=1. Both are standard analytic Gamma identities, with no numerical approximation.

For u>=0, tanh u>=u-u^3/3. Indeed the derivative of tanh u-u+u^3/3 is u^2-tanh^2 u>=0. Thus (8) gives

    log R_G(z)>=a-b,
    a=1/(8z), b=1/(192z^3).

For z>=1, b<=a/24, so (a-b)^2/2>=529/(73728z^2)>=b, the last inequality being 529z>=384. Since a-b>0,

    R_G(z)>=exp(a-b)>=1+(a-b)+(a-b)^2/2>=1+a.

Apply this with z=(p+2)/2. It follows that

    A(p)sqrt(pi p/2)
       >=sqrt(p/(p+2))[1+1/(4(p+2))].                 (9)

The right side in (7) is positive for p>=1. Squaring the proposed comparison between (9) and the bracket in (7), their squared difference is

    N_1(p)/[72p^4(p+2)^3],
    N_1(p)=60p^5+225p^4+10p^3-324p^2+192p-64.

Writing t=p-1>=0,

    N_1(1+t)=60t^5+525t^4+1510t^3+1656t^2+774t+99>0.

This proves (7).

## 3. Gaussian increment bound

Write c0=sqrt(2/pi). For delta>0, the Gaussian increment divided by delta is

    [H((1+delta)/sqrt(p))-H(1/sqrt(p))]/delta
      =c0/sqrt(p) * average_{1<=r<=1+delta} exp(-r^2/(2p)).

The global inequality exp(-y)<=1-y+y^2/2 implies, for 0<=delta<=1/2,

    average exp(-r^2/(2p))
      <=1-mu2(delta)/(2p)+mu4(delta)/(8p^2),            (10)

where

    mu2=1+delta+delta^2/3,
    mu4=1+2delta+2delta^2+delta^3+delta^4/5.

For delta>=1/2, this average is decreasing in delta, because its integrand is decreasing in r. Its value is therefore at most the value at delta=1/2. At that endpoint,

    mu2=19/12, mu4=211/80.

## 4. Closure for 1/2<=delta<=1

By (5), the left side of (T) is at least delta A(p). By (7), (10), and the preceding average monotonicity, its difference from the target is at least

    c0 delta/sqrt(p) [1/(24p)+7/(1920p^2)]>0.

This proves the entire range 3/2<=xi<=2 for all real p>=1.

## 5. Closure for 1/6<=delta<=1/2

Integrating (6) gives the exact extra phase contribution

    LHS(T)>=delta A(p)+16delta^2/[9pi(p+2)],            (11)

since integral_0^(pi/2) sin v cos(v)^(p+1)dv=1/(p+2).

Define

    a(delta)=1/4-delta/2-delta^2/6,
    b(delta)=1/3-mu4(delta)/8.

By (7) and (10), LHS minus RHS in (T) is at least

    c0 delta/sqrt(p) [-a(delta)/p+b(delta)/p^2]
                    +16delta^2/[9pi(p+2)].            (12)

Throughout delta<=1/2, b(delta)>=7/1920>0. If delta>=7/16 then a(delta)<=a(7/16)=-1/1536<0, so (12) is positive immediately.

It remains to consider 1/6<=delta<=7/16. For fixed p>=1 put

    Z_p(delta)=[a(delta)p-b(delta)]/delta.

Direct differentiation gives

    Z_p'(delta)=-(6p-5)/(24delta^2)
                   +(1/4-p/6)+delta/4+3delta^2/40.

This is decreasing in p. At p=1 its expression is increasing in delta, and its value at delta=7/16 is

    -15991/1505280<0.

Therefore Z_p is decreasing on the required interval, and

    Z_p(delta)<=Z_p(1/6)=6(a0 p-b0),
    a0=35/216, b0=8249/51840.

Consequently (12) is positive if

    16/[9pi(p+2)]
       >6sqrt(2/pi)(a0p-b0)/p^(5/2).                 (13)

The right side is positive for p>=1, since a0-b0=151/51840>0. Squaring, and using pi<22/7, reduces (13) to a single polynomial inequality N_2(p)>0, where

    256p^5-(5832*22/7)(p+2)^2(a0p-b0)^2
       =N_2(p)/1612800,

    N_2(p)=412876800p^5-776160000p^4-1580224800p^3
              +2244514789p^2+3103636756p-2994024044.

For p>=2, set t=p-2>=0. Direct expansion gives

    N_2(2+t)=412876800t^5+3352608000t^4+8725567200t^3
              +7165469989t^2+1312022312t+343007824>0.

For 1<=p<=2, set t=p-1 in [0,1]. The exact Bernstein identity is

    N_2(1+t)=sum_{j=0}^5 binom(5,j) B_j t^j(1-t)^(5-j),

with

    (B_0,...,B_5)=
    (410619501, 3864833439/5, 1665757427/2,
     5347458981/10, 403016808/5, 343007824).

All six coefficients are positive. This proves (13), then (12), on the entire remaining continuous parameter rectangle. No parameter mesh or numerical integral is involved.

## 6. Consequence and remaining full-theorem obligations

The actual-frequency reflection/Prawitz proof already established

    P(|X|<x)>=-2J_pair(m,x/m)

and c_xi<=0 for 1<=xi<=2. Set p=1/m^2 in (T). It follows that the desired strict lower-central estimate holds for 7m/6<=x<=2m. Together with the accepted near-threshold bridge, it holds for every 0<=x<=2m, uniformly in dimension and actual maximum m in (0,1].

This does not yet cover x>2m or the weak upper-central side. No full max-coefficient theorem or unrestricted q theorem is claimed. The conditional Laplace A/B route is superseded for this rectangle and is not used in this proof.

The source identities (1)-(2), the monotone-quotient comparison, the Gamma integral, and both polynomial identities require independent mathematical review before this primary proof is accepted.
