# Independent audit request

Candidate: PROOF.md in this directory, presently pending.

Requested claimed scope: all finite normalized independent Rademacher sums, all actual maxima 0<m<=1, all thresholds x>=0, strict central inequality P(|X|<x)>=H(x)-H(m). No upper-central, full middle Kolmogorov, or unrestricted q claim.

Please review the mathematical reductions independently, not only by executing the primary checker:

1. Actual-frequency paired Prawitz sign and normalization, then the all-delta phase envelope (2).
2. The two elementary trigonometric estimates and the integrated phase error.
3. The positive/negative sine split in (10), including the Gaussian cutoff remainder and the negative-interval loss.
4. The Gamma-ratio normalization p=1/m^2, z=p/2, giving A0>=c0 m exp(-m^2/4).
5. Concavity in m of the normalized Gaussian budget and its reduction to three exact one-variable boundaries.
6. Independently reconstruct the 25 Bernstein coefficients and all displayed rational margins.
7. The unbounded y>=3/2 argument, especially the use of a necessary condition for the simple Chebyshev bound not to finish.
8. The two second-moment joins and complete coverage in Section 6, preserving strict central versus weak tail events.

Accepted inputs are frozen without changes. Their audit status does not extend to this new proof until your review passes. The main candidate has no parameter mesh, numerical quadrature, or old coefficient-certificate dependency.
