#!/usr/bin/env python3
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,tempfile,shutil
ROOT=Path(__file__).resolve().parent

def require(ok,msg):
 if not ok:raise RuntimeError(msg)

def verify(root):
 manifest=json.loads((root/'MANIFEST.json').read_text())
 expected=set(manifest['files'])|{'MANIFEST.json'}
 actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
 require(actual==expected,'payload inventory mismatch')
 for path,sha in manifest['files'].items():
  require(hashlib.sha256((root/path).read_bytes()).hexdigest()==sha,'hash mismatch: '+path)
 status=json.loads((root/'STATUS.json').read_text())
 require(status['full_analytic_max_theorem']=='NOT_PROVED','scope mismatch')
 require(status['unrestricted_q_theorem']=='NOT_PROVED','scope mismatch')
 for path,sha in status['reviewed_source_hashes'].items():
  require(manifest['files'].get(path)==sha,'reviewed source binding mismatch')
 require(F(203,1408)-F(2,15)==F(229,21120)>0,'bridge margin')
 require(F(2,1)*(F(3,4)-F(3,4)**3/6)==F(87,64),'bridge integral')
 require(F(13,8)+F(1,42)==F(277,168)<F(5,3),'exponential bound')
 require(F(16)*F(5,3)<27,'derivative obstruction margin')
 require(F(16)*(F(1,5)-F(1,375))-F(4,239)-F(157,50)==F(107,179250)>0,'pi lower bound')
 return len(manifest['files'])

count=verify(ROOT)
negative=[]
for mode in ('alter','delete','extra'):
 with tempfile.TemporaryDirectory(prefix='max_bridge_verify_') as tmp:
  dest=Path(tmp)/'packet';shutil.copytree(ROOT,dest)
  target=dest/'primary/BRIDGE.md'
  if mode=='alter':target.write_bytes(target.read_bytes()+b'\nchanged\n')
  elif mode=='delete':target.unlink()
  else:(dest/'unexpected.txt').write_text('unexpected')
  try:verify(dest)
  except RuntimeError:negative.append(mode)
  else:raise RuntimeError('negative control accepted: '+mode)
print(json.dumps({'status':'PASS_SCOPED_ANALYTIC_RELEASE_INTEGRITY','payload_files':count,
 'exact_bridge_margin':'229/21120','negative_controls_rejected':negative,
 'full_analytic_max_theorem':'NOT_PROVED','unrestricted_q_theorem':'NOT_PROVED'},sort_keys=True,indent=2))
