# Independent analytic sign-pattern audit

Date: 2026-11-08. Verdict: PASS for the claims in the frozen SIGN_PATTERN_REVIEWED.md. This is not a proof of the full max-coefficient CDF theorem.

Reviewed the displayed kernel definitions in PROOF.md and independently checked the trigonometric derivation. No exploratory quadrature or computational certificate was inspected or run.

## Checked inequalities

Write δ=ξ−1, v=πu, A=δv and B=δ(π−v). Direct substitution into the original cotangent kernel yields both displayed formulas for k1 and k2.

For 0<v<π/2 and δ>0, the weighted sine difference equals δv(π−v)/π times [sinc(A)−sinc(B)]. This is nonnegative, and strictly positive when v<π/2, because sinc is strictly decreasing on (0,π). Indeed sin z−z cos z has derivative z sin z>0 and vanishes at zero. The other difference term has the asserted nonnegative cosine factor. Therefore k1−k2<0 for δ>0 and 0<v<π/2.

For the sum estimate, the invoked concavity means separately sin(δv)≥δ sin v and sin(δ(π−v))≥δ sin(π−v)=δ sin v. Weighting proves the stated inequality. The angle θ=(1+δ)v−δπ/2 lies in [−δπ/2,π/2], where sine is increasing. Multiplication by 2 cos(δπ/2)≥0 gives the asserted lower bound −sin(δπ). Hence k1+k2≤−δ+sin(δπ)/π<0 for δ>0. At δ=0, k1=k2=−sin v/π, so c=0 exactly.

It follows that c≤0 throughout the closed rectangle, and in fact c<0 for ξ>1 and 0≤u<1/2. At u=1/2, symmetry forces c=0 since k1=k2<0.

## Endpoint checks and switch

The removable limits at u=0 are k1=−δ and k2=0: the two constant terms in the formula for k2 cancel. Thus c(0)=−δ. At u=1/2, k1=k2=−sin(δπ/2)/2−cos(δπ/2)/π<0.

For 0≤δ≤1/2, the rearrangement −πk2=sin B[v/sin v−cos v]+sin v cos B is correct and nonnegative; it is strictly positive for v>0. The needed v−sin v cos v is positive for v>0, since its derivative is 2 sin²v.

For 1/2<δ<1, the sign-controlling function F(v)=cot B−R(v), R(v)=cot v−v csc²v, is continuous and strictly increasing on (0,π/2). Indeed (cot B)'=δ csc²B>0, while R'=2 csc²v(v cot v−1)<0; sin v−v cos v>0 proves the last inequality. The removable limit R(0)=0 follows, for example, from R=(sin v cos v−v)/sin²v. Thus F(0+)=cot(δπ)<0 and F(π/2)=cot(δπ/2)+π/2>0. Exactly one interior switch follows, with k2 positive before it and negative afterwards.

For δ=1, k2=−u+sin(2πu)/π. The ratio sin(2πu)/(πu)=2 sinc(2πu) strictly decreases from 2 to 0, so it crosses 1 once. The alternative cotangent argument also remains valid on the open interval, with F(0+)=−∞. There is no interior switch at δ=1/2.

## Scope of monotonicity

Because c≤0, the lower-envelope branch is valid throughout 1≤ξ≤2. For each fixed ξ, J_pair is nondecreasing in finite p≥1, and strictly increasing if ξ>1; at ξ=1 it is identically zero. This pointwise comparison needs no differentiation under the integral.

No normalized Gaussian-deficit monotonicity follows from this observation. The final two-parameter integral comparison remains unproved, as the reviewed source explicitly states. Thresholds ξ>2 and the upper-central side are not resolved by this audit.
