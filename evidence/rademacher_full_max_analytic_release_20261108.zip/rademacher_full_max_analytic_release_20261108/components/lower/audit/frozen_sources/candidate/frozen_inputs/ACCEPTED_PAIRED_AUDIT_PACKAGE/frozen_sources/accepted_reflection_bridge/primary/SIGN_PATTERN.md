# Complete paired-kernel sign pattern for 1<=xi<=2

Date: 2026-11-08. Primary analytic derivation, not independently audited.

Use k_xi and c_xi from PROOF.md. Put delta=xi-1 in [0,1], v=pi u in [0,pi/2], and abbreviate k1=k_xi(u), k2=k_xi(1-u).

## 1. Exact formulas

Direct cancellation gives

    k1=-(1-u)sin(delta v)/sin(v)-sin((1+delta)v)/pi,
    k2=-u sin(delta(pi-v))/sin(v)-sin(v-delta(pi-v))/pi.

The endpoints are interpreted by continuity. In particular k1<=0 throughout the stated domain.

## 2. Both k1-k2 and k1+k2 are nonpositive

Let A=delta v and B=delta(pi-v). Since A<=B<=pi and sinc decreases on [0,pi],

    (1-u)sin A >= u sin B.

Also

    sin(v+A)-sin(v-B)
      =2 cos((1+delta)v-delta pi/2) sin(delta pi/2) >=0,

because the cosine argument lies between -delta pi/2 and pi/2. Substitution proves k1-k2<=0.

For the sum, concavity of sine on [0,pi] gives

    (1-u)sin A+u sin B >= delta sin v.

The remaining sine sum is

    sin(v+A)+sin(v-B)
      =2 sin((1+delta)v-delta pi/2) cos(delta pi/2)
      >=-sin(delta pi).

Therefore

    k1+k2 <= -delta+sin(delta pi)/pi <=0.

At delta=0 the sum may also be checked directly as -2sin(v)/pi. Thus

    c_xi(u)=max(k1+k2,k1-k2)<=0

for every 1<=xi<=2 and 0<=u<=1/2.

Consequently the paired upper envelope is exactly

    J_pair(m,xi)=integral_0^{1/2} c_xi(u)cos(pi u)^p du,
    p=1/m^2,

with no Gaussian upper branch in this entire threshold range.

## 3. The absolute-value switch is unique

For delta<=1/2, k2<=0 everywhere. Indeed set B=delta(pi-v)<=pi/2. Rearranging its formula gives

    -pi k2
      =sin B [v/sin v-cos v]+sin v cos B >=0.

Here v>=sin v cos v. Thus c_xi=k1-k2 on 1<=xi<=3/2.

For 1/2<delta<1, k2 changes sign exactly once on 0<u<1/2. Since sin B>0 and sin v>0, its sign is determined by

    -pi k2/(sin B sin v)
      =cot B-cot v+v csc(v)^2.

As v increases from 0 to pi/2, cot B is strictly increasing, while

    R(v)=cot v-v csc(v)^2

is strictly decreasing: R'(v)=2 csc(v)^2[v cot v-1]<0. The limit of cot B-R(v) at v=0 is cot(delta pi)<0; at pi/2 it is positive. It therefore vanishes exactly once. Before the switch k2>0, and after the switch k2<0.

The endpoint delta=1 has the explicit formula k2=-u+sin(2pi u)/pi. It has the same unique interior sign change: sin(2pi u)/(pi u) decreases strictly from 2 to 0 on (0,1/2). Equivalently the cot argument above has an infinite negative limit at v=0 and the same strictly increasing difference.

Hence on 3/2<xi<=2, c_xi is k1+k2 before one explicitly characterized switch and k1-k2 afterwards. This is an exact sign description, not a grid observation.

## 4. What monotonicity does and does not follow

For each fixed xi in [1,2], J_pair is nondecreasing as p increases, because c_xi<=0 and cos(pi u)^p decreases. Equivalently -J_pair decreases.

This does not prove the needed normalized deficit is monotone: its Gaussian target also depends on p. The remaining sufficient comparison after the proven near-threshold bridge is

    2 integral_0^{1/2} [-c_xi(u)]cos(pi u)^p du
       >= H(xi/sqrt(p))-H(1/sqrt(p)),
       p>=1, 7/6<=xi<=2.

No proof of this last two-parameter comparison, or of its proposed normalized-p monotonicity, is supplied here. Thresholds xi>2 and the upper-central side also remain separate.
