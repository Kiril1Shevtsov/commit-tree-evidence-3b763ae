#!/usr/bin/env python3
"""Primary exact algebra checks. No third-party packages, sampling or quadrature."""
from fractions import Fraction as F
from math import comb, factorial
import json
from pathlib import Path

checks = []
def check(name, condition, detail=None):
    if not condition:
        raise AssertionError(name)
    checks.append({'name': name, 'status': 'PASS', 'detail': str(detail) if detail is not None else None})

# P is stored by the powers of (m,y).
P = {}
def add(i,j,c):
    P[i,j] = P.get((i,j),F(0)) + F(c)
for r in range(4):
    add(2*r+1,0,F((-1)**r,2**r*factorial(r)*(2*r+1)))
for r in range(5):
    for k in range(2*r+1):
        add(k+1,2*r-k,-F((-1)**r*comb(2*r,k),2**r*factorial(r)*(k+1)))
add(2,1,-F(1,4))
add(2,2,-F(32,125))
add(3,1,-F(128,375))
add(4,0,-F(128,1125))
add(6,0,-F(57,500))
add(2,4,-F(1,198))
P={k:v for k,v in P.items() if v}

def at_m(m):
    out={}
    for (i,j),c in P.items():out[j]=out.get(j,F(0))+c*m**i
    return out

def diagonal():
    out={}
    for (i,j),c in P.items():out[i+j-3]=out.get(i+j-3,F(0))+c
    return {k:v for k,v in out.items() if v}

def bernstein(poly,a,b):
    n=max(poly)
    aa=[sum(c*comb(j,k)*a**(j-k)*(b-a)**k for j,c in poly.items() if j>=k) for k in range(n+1)]
    return [sum(aa[k]*F(comb(j,k),comb(n,k)) for k in range(j+1)) for j in range(n+1)]

expected_diag = [F(3,4),F(73,108),F(4025,6912),F(1896667,4055040),F(16277801,48660480),F(1837985,9732096),F(318195043,9965666304)]
expected_half = [F(64837151,2433024000),F(388211699,9732096000),F(1828700011,34062336000),F(898744123,13624934400),F(634655809,8515584000),F(5266501193,68124672000),F(2458386589,34062336000),F(539461661,9732096000),F(8099161,486604800)]
expected_five_eighths = [F(39774380375,5102421147648),F(376329364925,40819369181184),F(1502047332355,142867792134144),F(29967996047845,2571620258414592),F(24329176440605,1928715193810944),F(103156268402575,7714860775243776),F(482518988593625,34716873488596992),F(140560921640215,9919106711027712),F(52669963368845,3719665016635392)]
for name,poly,a,b,expected in [
    ('diagonal',diagonal(),F(0),F(5,8),expected_diag),
    ('m_one_half',at_m(F(1,2)),F(1,2),F(3,2),expected_half),
    ('m_five_eighths',at_m(F(5,8)),F(5,8),F(5,6),expected_five_eighths)]:
    actual=bernstein(poly,a,b)
    check(name+'_exact_identity',actual==expected)
    check(name+'_all_coefficients_positive',all(v>0 for v in actual),min(actual))

expected_diag_poly={6:-F(702625,4752000),4:F(1782000,4752000),3:-F(565728,4752000),2:-F(3564000,4752000),1:-F(3379200,4752000),0:F(3564000,4752000)}
check('displayed_diagonal_polynomial',diagonal()==expected_diag_poly)

# Trigonometric Taylor polynomial identities: powers of v, exact fractions.
def add_poly(out,k,c):out[k]=out.get(k,F(0))+c
trig1={}
for k in range(4):add_poly(trig1,2*k+3,F(2,3)*F((-1)**k,factorial(2*k+1)))
add_poly(trig1,1,-F(1))
for k in range(6):add_poly(trig1,2*k+1,F((-1)**k*2**(2*k),factorial(2*k+1)))
trig1={k:v for k,v in trig1.items() if v}
check('R_Taylor_identity',trig1=={5:F(1,45),7:-F(1,140),9:F(13,22680),11:-F(4,155925)})
check('R_Taylor_positive',F(1,45)-F(5,2)/140-4*F(5,2)**3/155925>0,F(1,45)-F(5,2)/140-4*F(5,2)**3/155925)
trig2={}
for k in range(4):
    c=F((-1)**k,factorial(2*k+1))
    add_poly(trig2,2*k+1,c)
    add_poly(trig2,2*k+3,c/4)
add_poly(trig2,1,-F(1))
trig2={k:v for k,v in trig2.items() if v}
check('csc_Taylor_identity',trig2=={3:F(1,12),5:-F(1,30),7:F(38,20160),9:-F(1,20160)})
check('csc_Taylor_positive',F(1,12)-F(5,2)/30==0 and 38-F(5,2)>0)
check('pi_upper_square',F(22,7)**2<10)
check('c0_lower',F(199,250)**2<F(7,11))
check('alpha_upper_squared',F(32,125)**2==2/F(25,8)**3)
check('beta_upper',F(128,1125)<F(57,500))
check('negative_sine_error_constant',8*250*8**5<7*25**5)
check('negative_sine_normalized',1/F(199)<1/F(198))
check('e2_greater7',sum(F(2)**k/factorial(k) for k in range(5))==7)
check('e_greater_eight_thirds',sum(F(1,factorial(k)) for k in range(4))==F(8,3))
check('exp_nine_eighths_greater3',sum(F(9,8)**k/factorial(k) for k in range(5))>3)
lo=F(5,8)*F(199,250)
hi=F(4,23)+48/(23*F(199,250)*F(25,8)**2)+1/(36*F(25,8)**2)+24/(23*F(199,250)*F(8,3)*F(25,8)**3)
check('unbounded_y_budget_margin',lo-hi==F(14895943,411930000) and lo>hi,lo-hi)

def gaussian_taylor_integral(a,b,order):
    return F(4,5)*sum(F((-1)**k,2**k*factorial(k)*(2*k+1))*(b**(2*k+1)-a**(2*k+1)) for k in range(order+1))
a=gaussian_taylor_integral(F(1,2),F(4,3),4)
check('join_A_integral_identity',a==F(26586523759,60949905408))
check('join_A_margin',F(7,16)-a==F(79059857,60949905408) and F(7,16)>a,F(7,16)-a)
b=gaussian_taylor_integral(F(5,8),F(5,4),2)
check('join_B_integral_identity',b==F(65129,196608))
check('join_B_margin',F(9,25)-b==F(141247,4915200) and F(9,25)>b,F(9,25)-b)

report={'status':'PRIMARY_EXACT_ALGEBRA_PASS_NOT_INDEPENDENT_AUDIT','checks':checks,'count':len(checks),'parameter_grids_used':False,'quadrature_used':False,'third_party_packages_used':False}
print(json.dumps(report,indent=2))
