# Analytic max-coefficient reflection and threshold bridge

Research date: 2026-11-08. Scope: independently AI-audited analytic ingredients, not the complete original theorem.

For X=sum a_i epsilon_i with sum a_i^2=1 and actual maximum m=max|a_i|, this release accepts:

1. Actual-frequency reflection: |f(pi/m-t)|<=f(t), 0<=t<=pi/(2m).
2. The paired signed Prawitz functional, including its exact cancellation at x=m and the rigorous negative-right-derivative obstruction to using that sufficient functional immediately above x=m.
3. The dimension-uniform bound P(|X|<2m)>=87m/(64pi), and hence the original lower-central target P(|X|<x)>=H(x)-H(m) for every 0<=x<=7m/6.
4. The complete paired-kernel sign pattern on 1<=xi=x/m<=2, including at most one absolute-value switch. The functional there uses only the cosine lower envelope. Raw monotonicity in p=1/m^2 is proved; normalized deficit monotonicity is not.

No coefficient family or dimension cutoff is assumed. These results do not prove the remaining integral comparison, the upper-central side, the full computer-free max theorem, or the unrestricted fourth-mass strengthening.

## Reading order

- EXTERNAL_INPUTS.md states the two retained published analytic inputs precisely.
- primary/REFLECTION.md establishes reflection, the functional, and its exact near-boundary obstruction.
- primary/BRIDGE.md supplies the positive uniform bridge.
- primary/SIGN_PATTERN.md determines all kernel signs on 1<=xi<=2.
- audit/ contains independent mathematical reviews. The sign audit strengthens nonpositivity to strict negativity away from the endpoints for xi>1.

Primary source bytes are preserved unchanged, including their historical pending-audit captions. The corresponding final audit and STATUS.json determine acceptance. References in frozen files to the original workspace are provenance only: every result required for the accepted scope is stated in this packet, and replay uses relative paths only.

The reflection audit additionally proves a non-independent-law corollary for an earlier adaptive example. Its complete primary proof and independent audit are included under provenance/ so that this incidental part of the audit has no missing dependency. The geometry in that historical note is not part of this release's new positive CDF scope.

The two historical source-audit records under provenance/ are included only to preserve the verified Prawitz normalization and half-weight endpoint conventions. Their old numerical pilot/full-run claims are NOT replayed or used in the new analytic bridge. No old large computational certificate is included or needed.

## Portable integrity and exact arithmetic checks

Run:

    python3 -I -S -B verify.py

The standard-library verifier checks a closed payload inventory, every file hash, exact frozen-source bindings, the bridge rational margin, and the elementary exponential margin used by the obstruction. It then performs alteration, deletion and extra-file negative controls in temporary copies. These checks validate packaging and short arithmetic only. The universal inequalities depend on the written proofs and their independent mathematical audits, not on sample points or the verifier.

The proof imports Prawitz smoothing and Keller-Klein's analytic interval-comparison lemma as stated in EXTERNAL_INPUTS.md. Their full proofs are not reconstructed here. No external human peer review, formal proof-assistant verification, or novelty/priority claim is made.
