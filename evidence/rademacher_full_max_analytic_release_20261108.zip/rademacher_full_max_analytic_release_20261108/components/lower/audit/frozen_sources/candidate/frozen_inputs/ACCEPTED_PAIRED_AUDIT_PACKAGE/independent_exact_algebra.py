#!/usr/bin/env python3
"""Independent finite algebra only. No parameter grid, quadrature, or primary checker.
Ascending polynomial coefficients are exact fractions. Displayed coefficients are
reconstructed from the analytic expressions, then compared with frozen claims.
"""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import hashlib, json

def trim(a):
    a=list(map(F,a))
    while len(a)>1 and a[-1]==0:a.pop()
    return a

def add(a,b):
    r=[F(0)]*max(len(a),len(b))
    for i,x in enumerate(a):r[i]+=x
    for i,x in enumerate(b):r[i]+=x
    return trim(r)

def scale(a,s):return trim([F(s)*x for x in a])

def mul(a,b):
    r=[F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):r[i+j]+=x*y
    return trim(r)

def powp(a,n):
    r=[F(1)]
    for _ in range(n):r=mul(r,a)
    return r

def sub(a,b):return add(a,scale(b,-1))
def ev(a,x):return sum(c*F(x)**j for j,c in enumerate(a))

def shift(a,h):
    return [sum(a[j]*comb(j,k)*F(h)**(j-k) for j in range(k,len(a))) for k in range(len(a))]

def bernstein(a):
    n=len(a)-1
    return [sum(a[j]*F(comb(k,j),comb(n,j)) for j in range(k+1)) for k in range(n+1)]

checks=[]
def require(name,condition):
    if not condition:raise RuntimeError('FAIL: '+name)
    checks.append(name)

def as_strings(xs):return list(map(str,xs))

p=[F(0),F(1)]; one=[F(1)]; pp2=[F(2),F(1)]
# D = p(4p+9)^2/[16(p+2)^3] - (12p^2-9p+4)^2/[144p^4].
# Multiplication by 72p^4(p+2)^3 yields the following N1.
n1=scale(sub(scale(mul(powp(p,5),powp([9,4],2)),9),mul(powp([4,-9,12],2),powp(pp2,3))),F(1,2))
require('N1 reconstructed from squared Gamma comparison',n1==list(map(F,[-64,192,-324,10,225,60])))
n1shift=shift(n1,1)
require('N1(1+t) displayed coefficients',n1shift==list(map(F,[99,774,1656,1510,525,60])))
require('N1(1+t) coefficients strictly positive',all(c>0 for c in n1shift))

mu2=[F(1),F(1),F(1,3)]
mu4=[F(1),F(2),F(2),F(1),F(1,5)]
a=[F(1,4),F(-1,2),F(-1,6)]
b=sub([F(1,3)],scale(mu4,F(1,8)))
require('mu2 at half',ev(mu2,F(1,2))==F(19,12))
require('mu4 at half',ev(mu4,F(1,2))==F(211,80))
require('large-delta first margin',F(-3,4)+ev(mu2,F(1,2))/2==F(1,24))
require('large-delta second margin and minimum b',ev(b,F(1,2))==F(7,1920))
require('a(7/16)',ev(a,F(7,16))==F(-1,1536))
a0=ev(a,F(1,6));b0=ev(b,F(1,6))
require('a0',a0==F(35,216))
require('b0',b0==F(8249,51840))
require('a0-b0',a0-b0==F(151,51840))
d=F(7,16)
zd1=-F(1,24)/d**2+F(1,12)+d/4+3*d*d/40
require('Z derivative at p=1, delta=7/16',zd1==F(-15991,1505280))

n2=scale(sub(scale(powp(p,5),256),scale(mul(powp(pp2,2),powp([-b0,a0],2)),F(5832*22,7))),1612800)
require('N2 reconstructed from squared phase comparison',n2==list(map(F,[-2994024044,3103636756,2244514789,-1580224800,-776160000,412876800])))
n2shift=shift(n2,2)
require('N2(2+t) displayed coefficients',n2shift==list(map(F,[343007824,1312022312,7165469989,8725567200,3352608000,412876800])))
require('N2(2+t) coefficients strictly positive',all(c>0 for c in n2shift))
beta=bernstein(shift(n2,1))
require('N2 Bernstein coefficients independently reconstructed',beta==[F(410619501),F(3864833439,5),F(1665757427,2),F(5347458981,10),F(403016808,5),F(343007824)])
require('all Bernstein coefficients strictly positive',all(c>0 for c in beta))
# Explicitly reconstruct monomials from the Bernstein representation as an extra check.
back=[F(0)]
for j,bj in enumerate(beta):
    back=add(back,scale(mul(powp(p,j),powp([1,-1],5-j)),comb(5,j)*bj))
require('Bernstein reconstruction equals N2(1+t)',back==trim(shift(n2,1)))

require('sinc coefficient rational slack',F(49,55)>F(8,9))
require('Gamma log-bound square coefficient dominates b at z>=1',F(529,73728)>F(1,192))
require('Chebyshev anchor margin',F(7,16)-F(24,55)==F(1,880))
require('near-threshold bridge rational margin',F(203,1408)-F(2,15)==F(229,21120))
require('large-max threshold strictly above tail threshold',F(27,40)>F(2,3))

# Analytic Machin identity is explained in AUDIT.md. Alternating bounds contain pi.
def atan_partial(q,last):return sum(F((-1)**j,(2*j+1)*q**(2*j+1)) for j in range(last+1))
pi_lo=16*atan_partial(5,7)-4*atan_partial(239,2)
pi_hi=16*atan_partial(5,6)-4*atan_partial(239,1)
require('Machin lower bound gives pi>157/50',pi_lo>F(157,50))
require('Machin upper bound gives pi<22/7',pi_hi<F(22,7))
require('Machin upper bound gives pi<355/113',pi_hi<F(355,113))
phi_lower=F(19947,50000)
require('phi(0)>19947/50000 by exact square comparison',2*pi_hi*phi_lower**2<1)
require('simple rational phi lower slack',1-2*F(355,113)*phi_lower**2==F(320561,28250000000))
require('phi(0)<2/5 by exact square comparison',2*pi_lo*F(2,5)**2>1)
x=F(27,40)
H_lower=2*phi_lower*(x-x**3/6+x**5/40-x**7/336)
require('H(27/40) retained exact lower fraction',H_lower==F(229520461865155173,458752000000000000))
require('H(27/40)>1/2',H_lower>F(1,2))

out={
 'status':'PASS_INDEPENDENT_EXACT_FINITE_ALGEBRA',
 'checks_passed':len(checks),'checks':checks,
 'N1_ascending':as_strings(n1),'N1_shift_one_ascending':as_strings(n1shift),
 'N2_ascending':as_strings(n2),'N2_shift_two_ascending':as_strings(n2shift),
 'N2_shift_one_Bernstein':as_strings(beta),
 'Z_derivative_corner':str(zd1),'pi_Machin_bounds':[str(pi_lo),str(pi_hi)],
 'H_27_40_lower':str(H_lower),'H_27_40_slack':str(H_lower-F(1,2)),
 'parameter_sampling':False,'quadrature':False,'primary_checker_executed':False,
}
print(json.dumps(out,indent=2))
