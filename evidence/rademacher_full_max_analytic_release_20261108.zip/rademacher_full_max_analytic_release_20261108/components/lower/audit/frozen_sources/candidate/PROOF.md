# A complete analytic lower-central bound for Rademacher sums

Date: 2026-11-08. Status: PRIMARY CANDIDATE, pending independent audit.

## Statement, accepted inputs, and exact scope

Let X=sum_i a_i epsilon_i, where the signs are independent and unbiased,

    sum_i a_i^2=1,    m=max_i |a_i| in (0,1],
    H(t)=2Phi(t)-1,   c0=sqrt(2/pi).

This note claims, for every real x>=0,

    P(|X|<x) >= H(x)-H(m).                              (1)

The event on the left is STRICT. This is the entire lower-central side, uniformly in finite dimension and actual maximum m. It is not the weak upper-central side, not the full max-coefficient Kolmogorov theorem, and not the q-strengthening. In particular the analytic upper-middle range remains a separate obligation.

Already independently accepted inputs are:

1. The actual-frequency reflection and signed Prawitz pairing, frozen as ACTUAL_REFLECTION.md with its independent audit.
2. The complete lower-central estimate for 0<=x<=2m, accepted in the paired-closure audit. Its primary proof, complete audit, verdict and source manifest are frozen here.
3. The standard Euler-Gamma logarithmic-derivative integral. Its use below is spelled out.

No old numerical coefficient certificate, parameter grid, numerical quadrature, or asymptotic remainder is a proof input. The finite polynomial identities below are printed explicitly and independently reproducible using rational arithmetic.

It remains to prove (1) for x>2m. Put

    p=1/m^2,    delta=x/m-1>1,    y=delta m=x-m>m.

We will prove one global tail estimate, then close its budget using concavity, three one-variable polynomial identities, and elementary second-moment bounds.

## 1. A phase envelope valid for every delta>=0

For 0<v<pi/2, write

    R(v)=v/sin v-cos v >=0,
    A(v)=sqrt(sin^2 v+R(v)^2).

Use the accepted paired Prawitz kernel

    k_xi(u)=(1-u)cos(pi xi u)
       -[(1-u)cot(pi u)+1/pi]sin(pi xi u),
    W_xi(v)=-k_xi(v/pi)-|k_xi(1-v/pi)|,
    xi=1+delta.

The exact trigonometric identities are

    -k_xi(v/pi)=sin(delta v)/sin v
       +[sin v cos(delta v)-R(v)sin(delta v)]/pi,

    k_xi(1-v/pi)
       =-[R(v)sin(delta(pi-v))+sin v cos(delta(pi-v))]/pi.

The absolute value of the numerator in the second line is at most A(v). Consequently

    W_xi(v) >= sin(delta v)/sin v - E_delta(v)/pi,       (2)

where

    E_delta(v)=A(v)-sin v cos(delta v)+R(v)sin(delta v)
             >=0.                                    (3)

Nonnegativity follows from the Cauchy-Schwarz inequality: the subtracted scalar product has absolute value at most A. Thus (2) loses only a phase error, without asserting a sign pattern for W beyond xi=2.

### Two elementary trigonometric estimates

Throughout 0<=v<=pi/2,

    0<=R(v)<=2v^2/3,
    1<=v/sin v<=1+v^2/4.                              (4)

Here are polynomial proofs of the upper bounds. We use pi<22/7, hence z=v^2<5/2. Taylor inequalities for sine give

    (2/3)v^2 sin v-v+sin v cos v
      >=v^5 [1/45-z/140+13z^2/22680-4z^3/155925]>0.

The last bracket is at least

    1/45-(5/2)/140-4(5/2)^3/155925>0.

The displayed lower polynomial uses sin v through its negative degree-7 term and sin(2v) through its negative degree-11 term. These are global Taylor lower bounds for nonnegative arguments. Dividing by sin v proves the first upper bound in (4).

Also the degree-7 lower bound for sin v gives

    (1+v^2/4)sin v-v
      >=v^3 [1/12-z/30+z^2(38-z)/20160]>=0,

because z<=5/2. This proves the second upper bound. The lower bounds in (4) follow from sin v<=v and cos v<=1. Endpoints are understood by limits.

Since A-sin v=R^2/(A+sin v)<=R^2/(2sin v), and since

    1-cos(delta v)<=(delta v)^2/2,
    sin(delta v)<=delta v,

(3)-(4) imply, for every delta>=0,

    E_delta(v)
       <=[delta^2/2+2delta/3+2/9]v^3+v^5/18
        =(delta+2/3)^2 v^3/2+v^5/18.                  (5)

All these inequalities are pointwise and independent of dimension.

## 2. The global Gaussian tail budget

Write

    F(v)=product_i cos(a_i v/m),
    L(v)=cos(v)^p,    G(v)=exp(-p v^2/2).

On 0<=v<=pi/2, the accepted first-half-band comparison gives

    0<=L(v)<=F(v)<=G(v).                              (6)

Actual-frequency reflection and the signed Prawitz input give, preserving the strict event,

    P(|X|<x)>=(2/pi) integral_0^(pi/2) W_xi(v)F(v)dv.  (7)

From E>=0, (2), (5), and (6), the phase-error term in (7) is at most

    (2/pi^2) integral_0^(pi/2) E_delta(v)G(v)dv
      <=(2/pi^2)(delta+2/3)^2 m^4+8m^6/(9pi^2),        (8)

using the exact integrals of v^3 G and v^5 G on [0,infinity), respectively 2m^4 and 8m^6.

To estimate the main sine term, use the Gaussian identity

    H(delta m)=(2/pi) integral_0^infinity
                         G(v)sin(delta v)/v dv.

Where sin(delta v)>=0, (6) and sin v<=v give

    F(v)sin(delta v)/sin v-G(v)sin(delta v)/v
       >=-delta [G(v)-L(v)].

Where sin(delta v)<0, (6) instead gives

    F(v)sin(delta v)/sin v-G(v)sin(delta v)/v
       >=-G(v)(1/sin v-1/v)|sin(delta v)|.

The first possible negative interval begins at v=pi/delta. By (4), its total loss, enlarged to the entire tail, is at most

    (2/pi) integral_(pi/delta)^infinity (v/4)G(v)dv
       =m^2 exp[-pi^2/(2delta^2 m^2)]/(2pi).           (9)

If delta<=2, there is no negative interval inside the actual half-band, and the positive right side of (9) is still a valid upper bound. The Gaussian integral beyond pi/2 has absolute loss at most (2delta/pi) integral_(pi/2)^infinity G. Combining it with the first loss above yields

    (2/pi) integral_0^(pi/2) F(v)sin(delta v)/sin v dv
      >=H(delta m)-delta[c0 m-A0(p)]
         -m^2 exp[-pi^2/(2delta^2m^2)]/(2pi),           (10)

where

    A0(p)=(2/pi) integral_0^(pi/2) cos(v)^p dv
         =Gamma((p+1)/2)/[sqrt(pi)Gamma((p+2)/2)].

### A Gamma-ratio bound with the correct scale

For z>0 set R_G(z)=sqrt(z)Gamma(z)/Gamma(z+1/2). The standard Gamma integral is

    log R_G(z)=(1/2) integral_0^infinity
                         exp(-zt)tanh(t/4)/t dt.

Since tanh(t/4)<=t/4,

    log R_G(z)<=1/(8z).

At z=p/2 this proves

    A0(p)=c0 m/R_G(p/2) >=c0 m exp(-m^2/4).           (11)

Combining (7)-(11), and writing y=delta m, proves the following global bound:

    P(|X|<x) >= H(y)-c0 y[1-exp(-m^2/4)]
       -(2/pi^2)m^2(y+2m/3)^2-8m^6/(9pi^2)
       -m^2 exp[-pi^2/(2y^2)]/(2pi),   y=x-m>0.       (12)

Thus it suffices to show that

    M(m,y)=H(m)+H(y)-H(y+m)

pays the four explicitly displayed error terms in (12). No sign restriction on the oscillating sine outside its first positive interval was hidden in this derivation.

## 3. A polynomial lower budget and concavity

The elementary constants used here are

    25/8<pi<22/7,    e^2>7,
    199/250<c0<4/5.

The c0 lower bound follows by squaring from 2/pi>7/11>(199/250)^2; its upper bound follows from pi>25/8. Also

    2/(pi^2 c0)<32/125,
    8/(9pi^2 c0)<57/500.                              (13)

For the first comparison in (13), square both sides and use pi>25/8. The second follows from (4/9)(32/125)=128/1125<57/500.

For u>0, u^2 exp(-u)<=4/e^2. Hence

    m^2 exp[-pi^2/(2y^2)]/(2pi)
       <=8m^2 y^4/(e^2 pi^5)<m^2 y^4/250.

The last inequality follows from e^2>7 and

    8*250*8^5 < 7*25^5.

After dividing by c0, this loss is less than m^2 y^4/198. Finally 1-exp(-m^2/4)<=m^2/4. It therefore suffices, in any region where it is positive, to use the budget

    B(m,y)=(1/m) integral_0^m
                  [exp(-t^2/2)-exp(-(t+y)^2/2)]dt
       -ym/4-(32/125)m(y+2m/3)^2
       -(57/500)m^5-my^4/198.                         (14)

Indeed c0 m B is a lower bound on M minus the four losses in (12).

### Concavity eliminates the two-dimensional parameter rectangle

For fixed y>0 define f_y(t)=exp(-t^2/2)-exp(-(t+y)^2/2). Let g(t)=(t^2-1)exp(-t^2/2). Then f_y''(t)=g(t)-g(t+y)<=0 for 0<=t<=1:

- If t+y<=1, g increases on [0,1], because g'(t)=t(3-t^2)exp(-t^2/2)>=0.
- If t+y>=1, g(t)<=0<=g(t+y).

Consequently the average in (14), equal to integral_0^1 f_y(mr)dr, is concave in m on [0,1]. Each nonlinear subtracted polynomial in (14) is convex for m>=0. Thus B(m,y) is concave in m on [0,1], with

    B(0,y)=1-exp(-y^2/2)>0.                           (15)

It is enough to check the upper-m boundary of any vertical interval 0<=m<=min(M,y).

### Three exact one-variable polynomial checks

Define a two-variable polynomial P by

    P(m,y)= integral_0^m [T3(t^2/2)-T4((t+y)^2/2)]dt
       -ym^2/4-(32/125)m^2(y+2m/3)^2
       -(57/500)m^6-m^2y^4/198,

    Tj(z)=sum_(r=0)^j (-z)^r/r!.

Global Taylor inequalities T3(z)<=exp(-z)<=T4(z), z>=0, show

    m B(m,y)>=P(m,y).                                 (16)

The following three polynomial identities prove all needed boundary signs. For each listed polynomial Q on [a,b], put s=(y-a)/(b-a). If its degree is n and the list is (b0,...,bn), the identity means

    Q(y)=sum_(j=0)^n binom(n,j) bj s^j(1-s)^(n-j).

Every listed coefficient is strictly positive.

(a) Q(y)=P(y,y)/y^3, on 0<=y<=5/8, degree 6. Its removable value at zero is used. Explicitly

    Q(y)=-(702625y^6-1782000y^4+565728y^3
              +3564000y^2+3379200y-3564000)/4752000.

Its Bernstein coefficients are

    (3/4,
     73/108,
     4025/6912,
     1896667/4055040,
     16277801/48660480,
     1837985/9732096,
     318195043/9965666304).

(b) Q(y)=P(1/2,y), on 1/2<=y<=3/2, degree 8. Its coefficients are

    (64837151/2433024000,
     388211699/9732096000,
     1828700011/34062336000,
     898744123/13624934400,
     634655809/8515584000,
     5266501193/68124672000,
     2458386589/34062336000,
     539461661/9732096000,
     8099161/486604800).

(c) Q(y)=P(5/8,y), on 5/8<=y<=5/6, degree 8. Its coefficients are

    (39774380375/5102421147648,
     376329364925/40819369181184,
     1502047332355/142867792134144,
     29967996047845/2571620258414592,
     24329176440605/1928715193810944,
     103156268402575/7714860775243776,
     482518988593625/34716873488596992,
     140560921640215/9919106711027712,
     52669963368845/3719665016635392).

These are three single polynomial identities on whole intervals, not parameter subdivisions or sampled checks. The provided standard-library rational checker reconstructs P from its definition and verifies all coefficients and inequalities exactly.

From (15)-(16), concavity and (a)-(c), we have proved B(m,y)>0 throughout both regions

    D1: 0<m<=1/2,    m<=y<=3/2;
    D2: 0<m<=5/8,    m<=y<=5/6.                       (17)

For D1, the upper-m endpoint is m=y when y<=1/2 and m=1/2 otherwise. For D2 it is m=y when y<=5/8 and m=5/8 otherwise. This explains every endpoint used in the three identities.

## 4. The unbounded y region requires no further polynomial checks

Suppose 0<m<=1/2 and y>=3/2. Put x=y+m. If H(m)>=1/x^2, the second-moment bound immediately gives

    P(|X|<x)>=1-1/x^2>=1-H(m)>=H(x)-H(m).

Otherwise H(m)<1/(y+m)^2. Since

    H(m)>=c0 m(1-m^2/6)>=(23/24)c0 m,

we obtain the useful budget constraint

    m(y+m)^2 < 24/(23c0).                            (18)

The elementary inequality exp(9/8)>3 gives

    M(m,y)>=H(m)-c0 m exp(-y^2/2)
           >(5/8)c0 m.                              (19)

Divide the four error terms in (12) by m. In their displayed order they are at most

    4/23,
    48/(23c0 pi^2),
    1/(36pi^2),
    24/(23c0 e pi^3).                                (20)

For the first, use 1-exp(-m^2/4)<=m^2/4, (18), and y>=3/2:

    c0 ym/4 < 6y/[23(y+m)^2] <=6/(23y)<=4/23.

For the second, use y+2m/3<=y+m and (18). For the third, m^5<=1/32. For the fourth, (18) gives m<=24/(23c0 y^2), and the elementary maximization

    exp[-pi^2/(2y^2)]/y^2 <=2/(e pi^2)

does the rest.

Using c0>199/250, pi>25/8, and e>8/3, the difference between the lower bound (5/8)c0 in (19) and the upper bound in (20) is greater than the exact positive rational number

    14895943/411930000 >0.                            (21)

Thus the whole unbounded region 0<m<=1/2, y>=3/2 is closed. This argument uses only a necessary condition for Chebyshev not to have finished the task, not an assumption about the distribution of X beyond its variance.

## 5. Two elementary second-moment joins

For t>0,

    t^3 phi(t)<1.

Indeed its maximum is attained at t=sqrt(3), and is smaller than 3*2*(2/5)/3=4/5, using sqrt(3)<2, phi(0)<2/5, and exp(3/2)>3.

Therefore

    G_m(x)=H(m)+1-H(x)-1/x^2

is strictly increasing in x>0 and in m. If G_m(x)>=0, Markov's inequality on the WEAK complementary event |X|>=x proves the STRICT central estimate (1).

### Join A: m>=1/2 and x>=4/3

At m=1/2, x=4/3 it suffices that H(4/3)-H(1/2)<7/16. The degree-4 exponential upper Taylor bound and c0<4/5 give

    H(4/3)-H(1/2)
       <26586523759/60949905408,

and

    7/16-26586523759/60949905408
       =79059857/60949905408>0.

Monotonicity of G_m(x) proves the whole stated join.

### Join B: m>=5/8 and x>=2m

The function

    G_m(2m)=H(m)+1-H(2m)-1/(4m^2)

is strictly increasing in m, since its derivative is

    2phi(m)+4[(2m)^(-3)-phi(2m)]>0.

At m=5/8, use the degree-2 exponential upper Taylor bound and c0<4/5:

    H(5/4)-H(5/8)<65129/196608,

    9/25-65129/196608=141247/4915200>0.

Since 1/(4(5/8)^2)=16/25, this proves Join B.

## 6. Complete coverage, including all atoms and joins

For every actual m in (0,1] and every x>=0:

1. If x<=2m, use the independently accepted lower-central theorem frozen in the inputs.
2. If x>2m and m>=5/8, apply Join B.
3. If x>2m and 1/2<=m<5/8:
   - When x>=4/3, apply Join A.
   - Otherwise y=x-m satisfies m<y<5/6 and m<5/8, hence D2 applies.
4. If x>2m and 0<m<1/2:
   - When y=x-m<=3/2, apply D1.
   - When y>=3/2, apply Section 4.

Every boundary is included by at least one closed inequality or by the accepted x<=2m result. The Prawitz input controls P(|X|<x); all subsequent analytic comparisons retain that strict event. Every use of the second-moment bound controls its weak complement |X|>=x. No atom is replaced by a half-weight event here.

This completes the claimed analytic lower-central theorem (1), conditional on independent acceptance of this new proof. It does not assert the remaining weak upper-central inequality or the full Kolmogorov theorem in the middle-max range. The independent auditor should review in particular the sine-sign split in (10), the Gamma normalization, the concavity argument, the three exact polynomial identities, and the global coverage in this section.
