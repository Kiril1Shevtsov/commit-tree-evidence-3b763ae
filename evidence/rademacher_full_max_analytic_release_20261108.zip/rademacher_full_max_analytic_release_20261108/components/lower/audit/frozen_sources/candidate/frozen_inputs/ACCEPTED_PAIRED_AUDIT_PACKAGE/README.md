# Independent paired-closure audit

Verdict: PASS. Read AUDIT.md for the independent mathematical review and exact scope; VERDICT.json is the machine-readable result. The full original CDF theorem is accepted here for actual maximum m>=27/40, not for the remaining analytic middle sector.

Source bytes are frozen under frozen_sources/ and bound by FROZEN_SOURCE_HASHES.json. FINAL_INTEGRITY.json records final source rechecking.

The supplemental finite exact-algebra checks can be reproduced with:

    python -B independent_exact_algebra.py

They use only the Python standard library, perform no quadrature or parameter sampling, and do not run the primary checker. INDEPENDENT_EXACT_RESULTS.json is the resulting exact output. AUDIT_MANIFEST.json binds all packet files except itself.
