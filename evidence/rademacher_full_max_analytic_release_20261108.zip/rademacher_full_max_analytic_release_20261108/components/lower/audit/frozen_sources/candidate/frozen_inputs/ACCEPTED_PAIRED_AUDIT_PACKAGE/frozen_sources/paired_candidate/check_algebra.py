#!/usr/bin/env python3
from fractions import Fraction as F
from math import comb
import json

def trim(p):
 p=list(map(F,p))
 while len(p)>1 and p[-1]==0:p.pop()
 return p

def add(p,q):
 r=[F(0)]*max(len(p),len(q))
 for i,v in enumerate(p):r[i]+=v
 for i,v in enumerate(q):r[i]+=v
 return trim(r)
def mul(p,q):
 r=[F(0)]*(len(p)+len(q)-1)
 for i,a in enumerate(p):
  for j,b in enumerate(q):r[i+j]+=a*b
 return trim(r)
def scale(p,c):return trim([v*c for v in p])
def power(p,n):
 r=[F(1)]
 for _ in range(n):r=mul(r,p)
 return r
def shift(p,c):
 r=[F(0)]
 for i,v in enumerate(p):r=add(r,scale(power([c,1],i),v))
 return r
def require(ok,msg):
 if not ok:raise RuntimeError(msg)

N1=[-64,192,-324,10,225,60]
require(shift(N1,1)==list(map(F,[99,774,1656,1510,525,60])),'N1 shift')
# Difference of squared Gamma proxy and target, after common denominator.
# 72p^4(p+2)^3 [p(4p+9)^2/(16(p+2)^3) - (12p²-9p+4)^2/(144p^4)]
left=add(scale(mul(power([0,1],5),power([9,4],2)),F(9,2)),scale(mul(power([2,1],3),power([4,-9,12],2)),F(-1,2)))
require(left==list(map(F,N1)),'N1 rational square identity')
D=F(1,6)
a0=F(1,4)-D/2-D*D/6
mu4=1+2*D+2*D*D+D**3+D**4/5
b0=F(1,3)-mu4/8
require((a0,b0,mu4)==(F(35,216),F(8249,51840),F(9031,6480)),'a0 b0')
D=F(7,16)
require(F(1,4)-D/2-D*D/6==F(-1,1536),'a at 7/16')
require(-1/(24*D*D)+F(1,12)+D/4+3*D*D/40==F(-15991,1505280),'Z derivative bound')
N2=list(map(F,[-2994024044,3103636756,2244514789,-1580224800,-776160000,412876800]))
q=add(scale(power([0,1],5),256),scale(mul(power([2,1],2),power([-b0,a0],2)),F(-5832*22,7)))
require(scale(q,1612800)==N2,'N2 square identity')
require(shift(N2,2)==list(map(F,[343007824,1312022312,7165469989,8725567200,3352608000,412876800])),'N2 shift')
B=[F(410619501),F(3864833439,5),F(1665757427,2),F(5347458981,10),F(403016808,5),F(343007824)]
br=[F(0)]
for j,b in enumerate(B):br=add(br,scale(mul(power([0,1],j),power([1,-1],5-j)),b*comb(5,j)))
require(br==shift(N2,1),'N2 Bernstein identity')
require(all(x>0 for x in B),'N2 Bernstein positivity')
require(F(7,16)-F(24,55)==F(1,880),'Chebyshev tail anchor')
print(json.dumps({'status':'PASS_PRIMARY_EXACT_ALGEBRA_ONLY','N1':'positive shifted coefficients','N2':'one Bernstein interval plus positive shifted coefficients','tail_anchor':'1/880','full_analytic_max_theorem':'NOT_PROVED','independent_audit':'PENDING'},sort_keys=True,indent=2))
