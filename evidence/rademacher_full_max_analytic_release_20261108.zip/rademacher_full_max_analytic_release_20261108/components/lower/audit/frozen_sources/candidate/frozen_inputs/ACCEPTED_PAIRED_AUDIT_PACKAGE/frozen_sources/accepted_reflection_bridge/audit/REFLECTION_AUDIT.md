# Independent reflection and terminal-law addendum

Date: 2026-11-08. Verdict: **PASS for the new analytic identities and the obstruction to the sufficient paired functional. No complete CDF theorem follows.**

Reviewed reflection source is frozen as `REVIEWED_REFLECTION_PROOF.md`, SHA-256 `4e54fe019cdfb457940de048aab5202e087aa99ac9f53786f78141b550e085bf`. No floating quadrature was used as evidence and no old certificate was run. The previous signed-source audit was read only to verify the normalization of the cited Prawitz input; this addendum does not reconstruct that external smoothing theorem.

## Actual-frequency reflection

For v in [0,pi/2] and r in [0,1],

    rv <= r(pi-v) <= pi-rv.

On this angle interval, the maximum of absolute cosine is cos(rv). This proves the factor inequality and, by multiplication, |f(T-t)| <= f(t). All low-frequency factors are positive for t<T/2. For 0<r<1 the two angle comparisons are strict there, giving strict product improvement for any nonflat vector. Endpoints and zero coefficients cause no problem. The result requires a genuine upper bound on every coefficient; it cannot be asserted with the fourth-mass scale in place of m.

## Paired signed envelope

Substitution u -> 1-u gives the exact integral pairing

    J = integral_0^(1/2) [k(u) f(Tu) + k(1-u) f(T(1-u))] du.

Because f(Tu)>=0 and |f(T(1-u))|<=f(Tu), its integrand is at most [k(u)+|k(1-u)|] f(Tu). The lower low-frequency bound follows by summing log(cos(r z)) >= r^2 log(cos z). The upper bound follows by retaining one attained maximum factor and using cos(y)<=exp(-y^2/2) on every other factor. Multiplication by the signed paired kernel then selects U when its sign is nonnegative and L otherwise. Every inequality direction in (3)-(5) is correct.

The cited strict-tail Prawitz input has the form P(X<x)>=1/2-J(x). For x>0, symmetry gives P(|X|<x)=2P(X<x)-1, so the lower-central bound is -2J(x). At -x, the same strict-tail input gives the weak upper-central bound 2J(-x). These conventions agree with the old source audit and require no atom-discarding continuity assumption. Accordingly (6) is sufficient for the desired lower-central estimate.

## Derivative and strict counterexample

At xi=1, both paired kernels equal -sin(pi u)/pi, so c_1 is identically zero. For fixed interior u, k_xi(1-u) remains negative in a neighborhood of xi=1. The identity

    u rho(u) + (1-u) rho(1-u) = 1/pi

then gives c'_1(u)=-cos(pi u) directly, because the two sine terms in k'_1(u)-k'_1(1-u) cancel.

Here is a precise domination argument that does not assume smoothness of absolute value at zero. On (0,1), 0<=rho(u)<=1/(pi u), so

    |partial_xi k_xi(u)| <= pi u(1-u) + pi u rho(u) <= pi/4+1.

The absolute value operation is Lipschitz. Thus c_xi is uniformly Lipschitz in xi, and |c_xi/(xi-1)| has an integrable constant bound near xi=1. Both envelopes lie in [0,1]. For every interior u<1/2, c'_1(u)<0, so the right difference quotient in (5) selects L for all sufficiently small positive increments depending on u. Dominated convergence now proves exactly

    J_pair'(m,1+) = -integral_0^(1/2) cos(pi u)^(p+1) du.

There is no need for a uniform neighborhood on which the kernel is negative everywhere.

At m=1/sqrt(2), the integral is 2/(3pi), whereas m phi(m)=exp(-1/4)/(2 sqrt(pi)). The derivative is strictly negative precisely when 16 exp(1/2)<9pi. For an entirely explicit exponential estimate, the series through order two sums to 13/8, and the remaining tail is at most (1/48)/(1-1/8)=1/42. Hence exp(1/2)<=277/168<5/3. With pi>3, the claimed strict inequality follows. Since the gap is zero at xi=1 and has negative right derivative, it is negative for every sufficiently small positive xi-1. This is a genuine failure of the sufficient functional, not a counterexample to the target theorem.

No numerical viability claim about more distant xi is certified by this addendum. The suggested comparison bridge remains unproved here.

## Corollary: the adaptive terminal law has no finite independent-sign representation

For the unnormalized adaptive law M_raw, the modified |S_16|=4 branches lie in [-8,8]. On all other branches, M_raw=S_16+epsilon_17+epsilon_18. Its outer support points are therefore exactly +/-18. Each outer atom is 2^-18: all sixteen prefix signs and the next two signs must agree; the six zero-coefficient signs have no effect. The variance is 18.

Suppose this same law were sum_{j=1}^N b_j eta_j with independent unbiased signs and nonzero b_j. Its largest support point is sum |b_j|, achieved by exactly one sign vector, so its mass is 2^-N. Matching the endpoint and its atom forces

    N=18, sum |b_j|=18, sum b_j^2=18.

Cauchy-Schwarz is then an equality: (sum |b_j|)^2=N sum b_j^2. Every |b_j| must equal 1. But eighteen unit signs have central atom 12155/65536, strictly smaller than 195481/1048576 for M_raw. Contradiction.

Thus the adaptive law is not merely produced by a dependent coefficient-selection mechanism: its terminal distribution cannot equal any finite sum of independent unbiased Rademacher signs with deterministic coefficients. Zero coefficients do not alter the argument; an additional deterministic shift would be forced to zero by the symmetric endpoints.
