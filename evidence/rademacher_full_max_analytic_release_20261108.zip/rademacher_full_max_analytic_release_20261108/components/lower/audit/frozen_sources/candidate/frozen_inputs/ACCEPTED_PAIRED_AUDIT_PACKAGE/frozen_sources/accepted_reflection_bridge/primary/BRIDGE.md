# An analytic near-threshold bridge for every maximum m

Date: 2026-11-08. Primary derivation; no full CDF theorem claimed.

Assume the notation and exact reflection pairing of PROOF.md. The Prawitz and half-weight comparison inputs are the same analytic inputs as in the accepted original max proof.

## 1. A linear central-mass bound

For every normalized finite independent Rademacher sum with maximum m,

    P(|X|<2m) >= 87m/(64pi).                              (1)

At xi=2 the kernel simplifies exactly:

    k_2(u)=-(1-u)-sin(2pi u)/pi,
    k_2(1-u)=-u+sin(2pi u)/pi.

Thus for u in [0,1/2], c_2(u)=k_2(u)+|k_2(1-u)| is nonpositive. More explicitly, it is -1 when sin(2pi u)/pi>=u, and otherwise equals -1+2u-2sin(2pi u)/pi<=0. For u<=1/4, concavity of sine gives sin(2pi u)>=4u>=pi u, so c_2(u)=-1.

Pairing and the low-band lower bound give

    J(2m) <= -integral_0^{1/4} cos(pi u)^{1/m^2} du.

Because m<=1 and pi>3, the interval [0,3m/(4pi)] lies inside [0,1/4]. Write p=1/m^2>=1. For 0<=v<=3m/4, cos v>=1-v^2/2>0. The real Bernoulli inequality yields

    cos(v)^p >= (1-v^2/2)^p >= 1-pv^2/2.

Consequently

    P(|X|<2m) >= -2J(2m)
      >= (2/pi) integral_0^{3m/4} [1-v^2/(2m^2)] dv
       = 87m/(64pi).

This keeps the strict event; no endpoint atom is discarded or converted to a weak event.

## 2. Complete lower bridge from m through 7m/6

Let W(l,r) count the probability strictly between l and r plus half of each endpoint atom. The accepted half-weight comparison, with the actual maximum m, states

    W(-2m,2m) <= 3 W(-m,m).

For every x>m,

    P(|X|<x) >= W(-m,m)
               >= W(-2m,2m)/3
               >= P(|X|<2m)/3
               >= 29m/(64pi).

Use pi<22/7 to obtain

    29m/(64pi) > 203m/1408.

For m<x<=7m/6, since phi(0)<2/5,

    H(x)-H(m) <= (4/5)(x-m) <= 2m/15.

The rational margin is

    203/1408-2/15 = 229/21120 > 0.

Therefore

    P(|X|<x) >= H(x)-H(m)  for every 0<=x<=7m/6.

For x<=m the target is nonpositive and automatic; at x=m this observation retains all atoms. For x>m the displayed bridge is strict relative to the target. The statement holds for every m in (0,1] and every finite dimension.

This is a bridge for the original max target. Replacing m by h=sqrt(sum a_i^4) in the half-weight comparison is not justified. The rest of the lower side, x>7m/6, and the complete upper side remain unproved by this note.
