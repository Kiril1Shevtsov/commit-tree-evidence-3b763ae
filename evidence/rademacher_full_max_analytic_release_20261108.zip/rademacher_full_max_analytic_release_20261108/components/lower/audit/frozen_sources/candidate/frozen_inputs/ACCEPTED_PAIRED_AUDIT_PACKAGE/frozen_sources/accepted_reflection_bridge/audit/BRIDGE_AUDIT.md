# Independent near-threshold bridge audit

Date: 2026-11-08. Verdict: **PASS.** With the same cited Prawitz smoothing and half-weight interval-comparison inputs as the existing proof, the argument proves

    P(|X|<2m) >= 87m/(64pi)

and the original lower-central target

    P(|X|<x) >= H(x)-H(m),    0 <= x <= 7m/6,

uniformly in every finite dimension and every actual maximum m in (0,1]. This is a positive analytic bridge, not a full theorem or a fourth-mass substitution.

Reviewed source is frozen as `REVIEWED_BRIDGE.md`, SHA-256 `db626c447e913247fd2acf0624bf6b21d28c0fffdc09de59583fd71a073938af`. No primary checker, floating quadrature or old certificate was run.

## Kernel and integral

Writing s=sin(2pi u)/pi, direct trigonometric simplification gives k_2(u)=-1+u-s and k_2(1-u)=-u+s. Hence the paired kernel is -1 when s>=u, and -1+2u-2s otherwise. On [0,1/2], s>=0, so the second branch is nonpositive. On [0,1/4], the chord bound sin(2pi u)>=4u and pi<4 imply s>=u. Thus c_2=-1 on the whole quarter-band.

The actual-frequency pairing proved in the previous addendum gives J<=integral c_2 f. Since c_2<=0 and f>=cos(pi u)^(1/m^2), replacing f by this lower bound gives an upper bound for J. Discarding the remaining nonpositive integral over [1/4,1/2] increases that upper bound. Therefore J(2m)<=-integral_0^(1/4) cos(pi u)^(1/m^2) du.

The shorter interval [0,3m/(4pi)] is contained in [0,1/4] because m<=1 and pi>3. With v=pi u and p=1/m^2>=1, cos v>=1-v^2/2>0, and convexity of y^p gives the real Bernoulli bound (1-v^2/2)^p>=1-pv^2/2. This yields exactly

    (2/pi)[3m/4-(3m/4)^3/(6m^2)] = 87m/(64pi).

The strict-event smoothing inequality supplies the asserted strict central probability; no equality between a weak and strict event is assumed.

## Half-weight comparison and atoms

The accepted Keller-Klein Lemma 3.7 has the required hypotheses |A|<=C and 2 max(m,D-B)<=C-A for the comparison W(C,D)<=W(A,B). At (A,B,C,D)=(-m,m,m,2m), these become m<=m and 2m<=2m. Thus W(m,2m)<=W(-m,m). Symmetry gives the same bound for W(-2m,-m), and half-weight additivity gives

    W(-2m,2m)=W(-2m,-m)+W(-m,m)+W(m,2m)<=3W(-m,m).

This verifies the actual application, including its equality boundary; it does not re-prove the external comparison lemma. I checked its statement and conventions against the existing `audit_lower_full_20261107/INDEPENDENT_LOWER_AUDIT.md`, without executing any certificate.

For x>m, the event (-x,x) contains all mass in [-m,m], so its strict probability is certainly at least W(-m,m). Conversely W(-2m,2m) is at least P(|X|<2m), including rather than discarding its half endpoint masses. The chain therefore yields P(|X|<x)>=29m/(64pi) for every x>m. It would be invalid to assert this chain at x=m; the proof correctly does not do that.

## Gaussian comparison and endpoints

Using pi<22/7 gives 29/(64pi)>203/1408. Also phi(0)<2/5 (equivalently pi>25/8), available for example from the previously established pi>157/50. Therefore H(x)-H(m)<=(4/5)(x-m)<=2m/15 when m<x<=7m/6. The independent rational subtraction is

    203/1408 - 2/15 = 229/21120 > 0.

Thus this whole nontrivial interval has positive margin. At 0<=x<=m, H(x)-H(m)<=0 and the target is automatic, including x=m and x=0 regardless of atoms. The endpoint x=7m/6 is included by the non-strict threshold estimate and the strictly positive constant margin.

No correction is required. Remaining lower thresholds x>7m/6 and the upper-central side are outside this bridge's scope.
