# Global max-coefficient analytic route: a Bellman obstruction and static reductions

Date: 2026-11-08. Status: written primary proofs, not yet independently audited.

The target is the original max-coefficient theorem

    d_K(sum a_i epsilon_i, N(0,1)) <= B(m),
    B(m)=Phi(m)-1/2, sum a_i^2=1, m=max |a_i|.

This note does NOT prove a complete computer-free version of that theorem. It does not prove the unrestricted fourth-mass strengthening. It does not replace any cell of the existing full proof. The analytic small-m theorem and the previously audited computational theorem remain separate inputs, not premises of the results below.

The purpose is a global viability gate followed by an exact nonadaptive route. There are three results:

1. A short explicit counterexample rules out a local Bellman proof which retains only current sum, remaining pathwise variance and an increment cap and is valid for every admissible midpoint step.
2. A common-tail fourth-difference identity retains the missing nonadaptive structure. The counterexample's gain disappears, with a strict reverse sign, when the tail is chosen independently of the prefix.
3. At each fixed dimension, the upper max-coefficient deficit has a maximizer on a rational resonance ray. Positive lower-side maxima admit a rational two-dimensional stationary reduction, with a scalar degenerate case. For resonance faces of dimension at least three, the admissible stationary ratio is unique when it exists.

The third result reduces the analytic form of the remaining problem, but gives no dimension-independent comparison between the required Boolean counts and Gaussian values. That is the unresolved step.

## 1. An explicit adaptive counterexample

Let epsilon_1,...,epsilon_24 be independent uniform signs and S=sum_{j=1}^{16} epsilon_j. Set

    M_raw = S + (1/2) sum_{j=17}^{24} epsilon_j, if |S|=4,
    M_raw = S + epsilon_17 + epsilon_18, otherwise.

In the second branch set the coefficients of epsilon_19,...,epsilon_24 to zero. These coefficients are predictable: the choice is made after the first sixteen signs, before any of the remaining signs is seen. Put M=M_raw/sqrt(18).

Every increment is conditionally symmetric Rademacher or zero. On EVERY path, the unnormalized sum of squared coefficients is either

    16+8(1/2)^2=18, or 16+2=18.

Thus the predictable quadratic variation is exactly 1 after normalization. The maximum coefficient is exactly m=1/sqrt(18) on every path, attained by the first sixteen increments. The law is symmetric by flipping all signs. Its variance is exactly 1 by the martingale-difference identity.

The ordinary eighteen-sign sum has central atom

    binom(18,9)/2^18 = 12155/65536.

On |S|=4, its ordinary two-sign continuation cannot hit zero. The substituted eight-half-sign continuation hits zero with probability 1/256, since all eight signs must be opposite to S. Therefore

    P(M=0)
      = binom(18,9)/2^18 + 2 binom(16,10)/(2^16 2^8)
      = 12155/65536 + 1001/1048576
      = 195481/1048576.

This exceeds H(m)=2Phi(m)-1. Here is a short rational proof, with no normal-CDF evaluation. The elementary inequality exp(-u)<=1-u+u^2/2 for u>=0 gives

    H(1/sqrt(18))
      <= [1/(3 sqrt(pi))] [1-1/108+1/12960].

For completeness, the classical Machin identity and the alternating arctangent series give

    pi = 16 arctan(1/5)-4 arctan(1/239)
       > 16(1/5-1/375)-4/239
       = 281476/89625 = 157/50+107/179250 > 157/50.

Since

    (157/50)(1411/2500)^2-1 = 74597/312500000 > 0,

we have 1/sqrt(pi)<1411/2500. Consequently

    H(1/sqrt(18))
      < (1411/7500)(1-1/108+1/12960),

and the difference between 195481/1048576 and the last rational number is

    15395383/796262400000 > 0.

By symmetry, F_M(0)-Phi(0)=P(M=0)/2>B(m).

This is not an independent Rademacher sum and not a counterexample to the target theorem. The choice of its last block depends on S.

### Exact Bellman consequence

Fix m=1/sqrt(18). There cannot exist a function U(s,v) satisfying all of:

- U(s,0)>=1_{s=0};
- U(s,v)>=[U(s-h,v-h^2)+U(s+h,v-h^2)]/2 whenever 0<=h<=m and h^2<=v;
- U(0,1)<=H(m).

Iterating the midpoint inequality along the above predictable strategy would give U(0,1)>=P(M=0)>H(m). Only finitely many iterations are needed. Zero coefficients may instead be treated by terminating a branch when v=0.

The same obstruction applies if m is carried as a fixed parameter. It also applies to a running maximum state when the permitted midpoint inequalities include this strategy and the root bound is the desired one. It does not rule out Bellman functions retaining the full residual coefficient multiset, a common tail distribution, or a weaker averaged induction inequality not valid for arbitrary adaptive choices.

## 2. What the nonadaptive common tail preserves

For h>=0 let

    (T_h f)(x)=[f(x+h)+f(x-h)]/2.

Translation operators commute. A direct operator calculation gives

    T_{h/2}^2=(I+T_h)/2,
    T_{h/2}^4-T_h=(T_h-I)^2/4.

Equivalently, for every function f for which these values are defined,

    (T_{h/2}^4-T_h)f(x)
      = [f(x-2h)-4f(x-h)+6f(x)-4f(x+h)+f(x+2h)]/16.

This is an exact replacement of one sign of amplitude h by four independent signs of amplitude h/2, preserving variance. If f is the CDF of an independent common remainder, it is an exact CDF identity, including weak endpoints and atoms. If f(t)=P(Y<t), it is the corresponding strict-endpoint identity. No smoothness is assumed.

For the two-sign/eight-half-sign replacement used above,

    T_{1/2}^8-T_1^2
       = (T_1-I)^2(T_1^2+6T_1+I)/16.

The signed central-atom gain, conditional on an EVEN prefix value s, is

    s=0:      -29/128,
    s=+/-2:   -9/64,
    s=+/-4:   +1/256,
    |s|>=6:   0.

When the same eight-half-sign block is used after EVERY sixteen-sign prefix, direct binomial convolution therefore gives

    P(S_16 + (1/2)S_8=0) = 389389/4194304,
    P(S_18=0)           = 12155/65536,

and their difference is

    -388531/4194304 < 0.

The adaptive counterexample selects only the positive s=+/-4 part of this signed kernel. The nonadaptive comparison necessarily retains the large negative contributions at s=0,+/-2. This isolates the exact independence information lost by pointwise Bellman maximization.

The fourth-difference identity is a viable starting point for a static, signed comparison argument. It is not by itself a sign theorem for arbitrary common Rademacher remainders or arbitrary CDF thresholds. Taking absolute values or optimizing the continuation separately at each prefix loses the essential cancellation.

## 3. Global nonadaptive reduction at fixed dimension

Fix n. Absorb signs into the independent signs and work on

    S_+ = {a in R^n: a_i>=0, ||a||_2=1}.

Zeros are allowed. Let E={-1,+1}^n. For s in E define x_s(a)=s dot a. Every CDF extremum occurs at a support endpoint, with the correct strict or weak convention. Include the following homogeneous rational hyperplanes in a finite arrangement:

- a_i=0;
- a_i-a_j=0;
- (s-t) dot a=0, for s,t in E;
- s dot a=0, for s in E.

The resulting relatively open polyhedral cones keep the positive-coordinate support, the maximum-coordinate ties, the support ordering and its collisions, and the sign of every support endpoint fixed. On a cone C let L=span(C). Choose a maximum coordinate k; on L every tied maximum coordinate has the same projection as e_k. Let m=e_k dot a.

### 3.1 Weak upper endpoints reduce to rational rays

At a nonnegative endpoint x=s dot a, define

    p_+(a,s)=2^-n #{t in E: t dot a <= s dot a},
    G_+(a,s)=p_+(a,s)-Phi(x)-B(m).

The maximum over a in S_+ and s with x>=0 exists. Indeed the domain for each s is compact, p_+ is upper semicontinuous (it is a finite sum of indicators of closed inequalities), and the remaining terms are continuous. Taking a maximum over finitely many s preserves attainment.

On one arrangement cone, p_+ is constant and

    G_+ = p_+ +1/2-Phi(x)-Phi(m).

Suppose a maximizer lies in a stratum with dim L>=2. Choose a unit w in L orthogonal to a. For sufficiently small positive and negative t,

    a(t)=a cos t+w sin t

stays in the same stratum and on the unit sphere. At t=0,

    x''=-x, m''=-m,
    G_+''=x phi(x)[1+(x')^2]+m phi(m)[1+(m')^2]>0.

The first term is nonnegative since x>=0, and the second is strictly positive since m>0. This contradicts local maximality. Hence a maximizer lies in a one-dimensional cone. Such a cone is a rational ray, so its normalized generator is proportional to a nonnegative integer vector.

Conclusion: for EACH FIXED n, the weak upper-central max-coefficient inequality (equivalently the weak upper CDF inequality at nonnegative endpoints) is equivalent to checking the finitely many one-dimensional rays of this arrangement, with all their actual nonnegative endpoint counts. This is an exact nonadaptive finite-dimensional reduction, not a new proof of those inequalities. The count and size of the rays are not bounded uniformly in n by this argument.

### 3.2 Strict lower endpoints: two-dimensional stationary data

At x=s dot a>0 define

    p_-(a,s)=2^-n #{t in E: t dot a < s dot a},
    G_-(a,s)=Phi(x)-p_-(a,s)-B(m).

By symmetry p_->=1/2 for x>0, so x<=m implies G_-<=0. To find any positive maximum it therefore suffices to restrict to the compact domain x>=m; here m>=1/sqrt(n)>0. On this domain p_- is lower semicontinuous, hence G_- is upper semicontinuous and attains its maximum. A positive maximizer has x>m>0.

Within its exact arrangement stratum, let

    u=P_L s, v=P_L e_k,
    D=||u||^2, A=||v||^2, C=u dot v.

These Gram numbers are rational, because L is a rational linear subspace. Also A>0. The strict endpoint count p_- is constant in this stratum. Spherical stationarity is

    phi(x)u-phi(m)v=lambda a,
    lambda=x phi(x)-m phi(m).

Put r=phi(m)/phi(x)=exp((x^2-m^2)/2)>1.

If lambda!=0, then a lies in the rational plane span(u,v), of dimension at most two. If u and v are independent, put

    Q(r)=D-2Cr+Ar^2 > 0,
    N(r)=(D-rC)^2-(C-rA)^2.

The two orientation choices are

    a=+/- (u-rv)/sqrt(Q(r)),
    x=+/- (D-rC)/sqrt(Q(r)),
    m=+/- (C-rA)/sqrt(Q(r)),

with the SAME sign in all three expressions. Feasibility requires a to belong to the original cone and x>m>0. The stationary ratio must solve the single scalar equation

    log r = N(r)/(2Q(r)).                                    (1)

There are at most five positive solutions of (1). Indeed

    d/dr[log r-N/(2Q)]
      = 1/r - (AD-C^2)[C r^2-(A+D)r+C]/Q^2,

whose numerator over the positive denominator r Q^2 is a nonzero polynomial of degree four (its leading term is A^2 r^4). Rolle's theorem then bounds the number of roots by five.

If lambda=0, stationarity gives u=r v, so the two projected vectors are parallel and x=r m on the whole stratum. In that degenerate case the objective is the scalar function

    Phi(r m)-Phi(m)+1/2-p_-.

Its possible interior critical value is

    m^2=2 log r/(r^2-1).

One must still check whether this m is attained inside the actual cone. No claim that the maximizing vector lies in span(u,v) is made in this lambda=0 case. If u and v are parallel with x/m<=1, the case cannot give a positive deficit.

### 3.3 Higher-dimensional faces have at most one admissible stationary ratio

Suppose dim L>=3 and u,v are independent. At a local maximum, lambda cannot be negative: choose a nonzero w in L orthogonal to u and v. Stationarity makes w orthogonal to a. Along its normalized great-circle direction, the second derivative is -lambda>0, a contradiction. Lambda=0 is impossible when u,v are independent. Therefore lambda>0.

It follows that the plus orientation holds and

    1<r<C/A,

in particular C>A>0. On this interval the quadratic

    K(r)=C r^2-(A+D)r+C

is negative. It is convex, and its endpoint values are

    K(1)=2C-A-D<0,
    K(C/A)=-C(AD-C^2)/A^2<0.

Consequently the derivative in Section 3.2 is strictly positive. Equation (1) has at most one root in the admissible interval. In fact its endpoint signs are

    [log r-N/(2Q)]_{r=1}=-(D-A)/2<0,
    lim_{r upward C/A}[log r-N/(2Q)]
        =log(C/A)-(AD-C^2)/(2A).

Thus a strictly interior ratio exists exactly when the last expression is positive. Equality puts the zero at m=0 and supplies no admissible positive maximum. Any root must additionally satisfy the original cone inequalities; existence of a scalar root alone does not give a feasible coefficient vector.

This is a real global simplification of stationary candidates for the original max envelope. It is not an exclusion of positive maxima. The lower candidate's value still depends on its actual dyadic count p_-. No Gaussian bound on that count has been proved here.

## 4. What remains for a complete analytic proof

The local Bellman relaxation is definitively unusable in the stated form. The common-tail identities and the arrangement reduction retain independence and do not suffer that particular counterexample. But they leave two genuinely global questions:

- Upper side: compare the endpoint counts of every rational resonance ray, uniformly in dimension, with Phi(x)+B(m).
- Lower side: compare the actual strict endpoint count with Phi(x)-B(m) at the scalar stationary candidates, including two-dimensional and parallel degeneracies.

No existing small-sector result or numerical test in this note settles these questions. In particular, rational-ray reduction must not be confused with a finite list uniform in dimension, and the two-dimensional projected plane is not a two-block coefficient family.

The optional exact checker verifies the binomial arithmetic, the rational Gaussian margin, the operator polynomial identities, and the rational form of the stationary derivative. These checks do not replace the written universal arguments and do not constitute an independent audit.
