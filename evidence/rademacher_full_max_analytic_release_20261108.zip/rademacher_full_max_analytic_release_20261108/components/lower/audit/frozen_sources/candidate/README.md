# Full lower-central phase candidate

Status: PRIMARY CANDIDATE, not independently accepted yet.

Main claimed result: for every finite normalized independent Rademacher sum, every actual maximum m in (0,1], and every x>=0,

    P(|X|<x)>=2Phi(x)-1-[2Phi(m)-1].

Read PROOF.md. This is a claim about the entire strict lower-central side only. The weak upper-central middle-max range is still open analytically. No unrestricted q theorem is claimed.

The new proof handles every x>2m through an actual-frequency phase envelope, an explicit Gaussian budget, concavity in m, three one-variable polynomial identities, and variance joins. The accepted x<=2m result is retained unchanged. The proof distinguishes strict central events from weak complementary tail events at atoms.

Run `python -I -S -B check_exact.py` for primary standard-library rational checks. These checks do not independently audit the analytic reductions. All 25 Bernstein coefficients are printed in PROOF.md, and each identity covers a whole interval without parameter subdivision or numerical integration.

Frozen sources:
- ACTUAL_REFLECTION.md and ACTUAL_REFLECTION_AUDIT.md: accepted actual-frequency pairing.
- ACCEPTED_PAIRED_PROOF.md and the adjacent audit/verdict: accepted x<=2m proof.
- ACCEPTED_PAIRED_AUDIT_PACKAGE/: complete unchanged independent audit package, including its frozen reflection, bridge, sign-pattern sources, external smoothing/half-weight source provenance, and earlier large-max composition. Its acceptance is not automatically acceptance of this new candidate.

The previously accepted scope in those frozen files is historical and remains unchanged. Some primary-source headers correctly retain their original pending status; the adjacent independent verdicts establish what was subsequently accepted.

The `SOURCE_HASHES.json` manifest binds every candidate/frozen file except itself. The current new PROOF.md requires independent review before any stronger status is reported.
