# Independent audit of the complete strict lower-central bound

Date: 2026-11-07.

## Verdict and exact scope

**PASS.** The frozen lower C/P driver, its 52-witness pilot, all 3918 full-run split witnesses, all 65 tail thresholds, exact coefficient/threshold coverage, and the submitted full lower composition are accepted.

Let X=sum b_i epsilon_i be any finite sum of independent uniform signs with sum b_i^2=1, and let m=max_i |b_i|. Combining this audit for m>3/20 with the separately accepted analytic lower theorem for 0<m<=3/20 establishes

    P(|X|<x) >= H(x)-H(m),    H(t)=2Phi(t)-1,    for every x>=0.

An arbitrary coefficient upper bound a>=m may replace m, by monotonicity of H. Coefficient signs may be absorbed into the uniform signs, and zero coefficients discarded. Normalization implies 0<m<=1. Unequal coefficients, arbitrary finite dimension, and atoms at every threshold are included.

This frozen verdict accepts the **full strict lower-central statement only**. Its conversion together with the matching full weak upper-central statement is mathematically sound, but independent acceptance of that separate upper computation is not asserted by this report. No priority, originality of the conjecture, or proof-assistant formalization claim is made.

The main numerical replay is a fresh higher-precision build of the same source-audited engine, not a second independently authored quadrature implementation. In addition, the 65 tail inequalities were checked by a separately authored, exact rational-series implementation with no MPFI/MPFR calls.

## Frozen sources and dependencies

The exact accepted source and contract hashes are:

- Lower C/P source: `3d2f84b25a2f09356e374d1fb72a10275287dcbee95bec1d164773820e239f1c`.
- Lower split method: `6194dc10df514e1a15f266f43d854daa947f722b8d8035748412d74a22e77d39`.
- Full lower composition: `15b11fde70c238ab9f52ece52920abce13653517f5982500db556652ff1336cc`.
- Included interval wrapper: `ffead441ac72051aea15a729b377733fa1a88d98ac6e7448e320002d92b1c0b8`.
- Previously accepted signed B source: `38543b3feff85724c55e9cd4632863446a767dd937fb3df27d4837e5aabf6e07`.
- Original lower parameter gzip: `1118089fd4d3adadde7f3475202a5b3f48343c1e3d70b5283bd04bbff41641b4`.
- Full split input: `115904217be6a4f859d3e95809ae664dd092c5330e75ad7b2f49d824b1a9dd81`.
- Completed primary full output: `4d606f21334c66aca964419c9bee7e136749bba13bc8a2d4ddbf99dff8534531`.
- Accepted small-range lower verdict: `cd011ac7ecd711c2f3e3cce1f07a80b7631d7cac731df3300e1ca0c7453bca1a`.
- Accepted small-range lower proof: `d04e2d226a0a18ff9b95eda47b4aca40b97def07173c8da74aa033e67aad3b75`.

Read the full signed B audit, the lower split-method note, the complete lower source and driver diff, the input selector, the primary tail source, the small-range independent audit/verdict, and the full lower composition. The pre-main integration engine is byte-identical to the accepted B engine. `LOWER_DRIVER_DIFF.txt` records every changed line. The interval wrapper and all source/input hashes were checked again after replay.

The signed engine's accepted arithmetic, characteristic envelopes, outward max, fourth-order jets, derivative remainder, endpoint strips/sinc identities, adaptive summation, and fail-closed behavior are inherited only because their bytes are unchanged. Its assumptions are rechecked for every new input. In particular, the binary does not itself enforce left>=0; this audit's exact input checker does, and all actual left endpoints are strictly positive. The source is not accepted as a validator for unrestricted malformed inputs.

No downloaded author mathematical source was imported or executed. The downloaded gzip was read only as proposed parameter data. The submitted selector and primary-output checker were read but not executed by this auditor. The independently authored Python checkers use explicit exceptions, not disableable assertions.

## External analytic inputs and lower kernel

The external smoothing and half-weight interval-comparison inputs are Keller and Klein, *Proof of Tomaszewski's Conjecture on Randomly Signed Sums*, Theorem 4.5, equations (39)–(40), and Lemma 3.7, equations (24)–(25):

https://arxiv.org/html/2006.16834v4#S4.SS1.SSS1

https://arxiv.org/html/2006.16834v4#S3.SS2

Their current primary-source statements were checked, including the strict tail in the smoothing formula and the hypotheses of the comparison lemma. Their complete proofs are external dependencies, not reconstructed by this audit.

For z>0, put lambda=Tz and

    rho(u)=(1-u)cot(pi u)+1/pi,
    k(u)=(1-u)cos(lambda u)-rho(u)sin(lambda u).

The strict-tail smoothing input and symmetry give

    P(|X|<z) = 2P(X<z)-1 >= -2 integral_0^1 k(u) phi_X(Tu) du.

The change of variables has already absorbed T into the characteristic function and angle; there is no extra T factor. The audited engine encloses the integral of f(u)=max(k(u)L(u),k(u)U(u)), where L<=phi_X(Tu)<=U for every normalized vector with maximum coefficient at most beta. Pointwise k phi_X<=f. If its returned interval is J=[Jlo,Jhi], then the actual kernel integral is at most Jhi. Consequently the strict central probability is at least -2Jhi. The lower driver correctly uses positive lambda=Tz, unlike B's negative lambda; the symmetric endpoint and derivative bounds remain valid for either sign.

Its only mathematical driver changes are the C/P kind, z=2left or left, the target H(alpha)-H(right), and multiplier 2/3 or 2. Those changes were inspected individually and match the inequalities below. The alpha endpoint, rather than beta, belongs in the target because m>=alpha; beta remains the upper envelope parameter.

## P cells

For a P half [l,r], the tested gap is

    H(alpha)-H(r)-2J(l).

A nonnegative lower endpoint implies -2Jhi(l)>=H(r)-H(alpha). For every x in [l,r], strict-event monotonicity and m>=alpha give

    P(|X|<x) >= P(|X|<l) >= -2Jhi(l)
                 >= H(r)-H(alpha) >= H(x)-H(m).

Both endpoints of a P cell are valid. No replacement of a strict event by a weak event occurs.

## C cells and atoms

Let W(A,B) denote mass strictly between A and B plus half the mass at each endpoint. For any b>=m, the substitution (A,B,C,D)=(-b,b,b,2b) satisfies |A|<=C and 2max(m,D-B)<=C-A. The comparison lemma gives W(b,2b)<=W(-b,b). Symmetry and additivity of half-weight masses therefore give W(-2b,2b)<=3W(-b,b).

For a C half (l,r], only x>max(m,l) is nontrivial. Choose b=max(m,l), so m<=b<x. Then

    P(|X|<x) >= W(-b,b) >= W(-2b,2b)/3
                >= P(|X|<2l)/3 >= -(2/3)Jhi(2l).

The first inequality holds because even the endpoint mass at +/-b lies strictly inside (-x,x). The third holds because 2l<=2b; if equality holds, W includes at least the strict interior mass. These are inequalities, not invalid equalities at atoms.

Thus the tested gap

    H(alpha)-H(r)-(2/3)J(2l)

is sufficient for H(x)-H(m) throughout the claimed half cell. At an excluded left endpoint l>m, the preceding C half includes that point as its right endpoint. At the first C endpoint l=alpha<=m the target is nonpositive. Points x<=m are always automatic. The last C boundary is included, and the subsequent closed P range covers its own first endpoint. If there are no P cells, the C range reaches at least the tail cutoff. This closes every endpoint case without an atom-free assumption.

## Independent exact coverage reconstruction

`check_exact_coverage.py` decompresses the original data and independently reconstructs every parameter and split. Numeric JSON tokens are first converted from decimal text to exact rationals, then rounded to nearest-even normal IEEE binary64 by integer arithmetic, matching the proposed source parameter semantics. No floating-point comparison decides acceptance. Those dyadic rationals are the exact parameters actually certified; the old author's numerical inequalities are not used.

For each source block it checks 0<alpha<beta<=1, positive smoothing parameters, the complete ordered C grid starting at alpha, the P grid, the C/P join, and the tail cutoff. It reconstructs each exact midpoint (l+r)/2 and both half-cell endpoints. It matches all full input rows exactly and checks the four shards form the indicated disjoint partition. It also matches all 26 original pilot cells to the source and reconstructs their 52 halves.

Results:

- 362 original data blocks read; exactly 65 have beta>3/20.
- 1959 original full-run cells become 3918 halves: 458 C and 3460 P.
- Shard sizes 980, 980, 979, 979; all ordered identities/parameters match.
- 65 tail rows exactly match their source blocks and cutoffs.
- The first selected alpha is 5338517761227981/36028797018963968, strictly below 3/20.
- Sorting coefficient intervals gives one initial overlap with the already accepted range and 64 exact joins, ending at beta=1. No coefficient gap occurs.

Every original interval is covered by its two halves with the correct C open-left/closed-right convention or P closed convention. Combined with the automatic range x<=m and the tail proof, the checked grids cover every x>=0. Result: `EXACT_COVERAGE.json`, PASS.

## Tail proof and independent arithmetic

For each block, the required tail condition is

    H(alpha)/2-exp(-x_end^2/2)>=0.

Hoeffding's bound applies to the weak complementary tail P(|X|>=x), so for every x>=x_end,

    P(|X|<x) >= 1-2exp(-x^2/2) >= 1-H(alpha)
                 >= H(x)-H(m).

This remains valid at atoms at x. All 65 primary tail intervals were verified against a fresh 256-bit build of the frozen tail source, with strictly positive lower gaps and complete interval containment.

Separately, `check_exact_tails.py` proves all 65 inequalities with Python Fraction arithmetic and integer square roots only. It encloses pi using alternating Machin arctangent sums, encloses phi(0)=1/sqrt(2pi) by exact square inequalities, bounds the integrated Gaussian series on 0<alpha<=1 between consecutive alternating partial sums, and bounds exp(x_end^2/2) by a positive partial sum plus a geometric remainder before inversion. The required exp argument is checked to lie in [0,4). Each displayed decimal endpoint is rounded outward by integer division.

All 65 independent exact enclosures lie inside the corresponding 160-bit primary gap intervals. The smallest exact lower gap, at source row 302, exceeds

    0.00000000033372917805693408114563063844500586317507628195402477110403163250116083.

The tail result therefore does not rest solely on replaying the same transcendental-library implementation. Results: `EXACT_TAILS.json` and `SOURCE_TAIL_REPLAY_CHECK.json`, both PASS.

## Fresh numerical replay and recorded-output checks

Environment: g++ Debian 14.2.0-19, MPFI 1.5.4, MPFR 4.2.2. Source compiled with -O2 -std=c++17 -DINTERVAL_BITS=256 and linked against installed libmpfi.so.0, libmpfr.so.6 and GMP. The previous wrapper/ABI audit is part of the accepted B dependency.

Pilot: a fresh 256-bit run on CPU 2 at exact tolerance 1/200000000 passed 52/52 in 15.2035302 seconds. All 104 finer J/gap intervals are contained in their 160-bit primary intervals. Its minimum lower gap exceeds 0.00035374733662338257.

Full run: fresh 256-bit replay on CPUs 2, 5, 6, 7 at exact tolerance 1/2000000 passed all 3918 witnesses. Shard times were 147.051856, 146.125128, 146.529577, and 149.688088 seconds. All six successful replay processes (pilot, four full shards, tail replay) exited zero and had empty stderr. The completed 160-bit primary full run passed 3918/3918 at tolerance 1/1000000 in 418.983016 seconds.

The newly authored `check_records.py` checks exact ordered identity and rational parameters, record counts, nonnegative input domain, versions/precision metadata, rational tolerance enclosure, finite ordered rational interval endpoints, width <= requested tolerance, strictly positive lower gap, success flags, panel/evaluation consistency, and final summaries. It compares all 7836 J/gap intervals and finds **all 7836 finer intervals contained** in their primary intervals.

The full minimum lower gaps occur at P, source row 302, half-cell 41:

- Primary: 4.420575389245914409841954344695517075228154583760353046e-4.
- Independent replay: 4.425375594501705241133162507637938642579934813723982054e-4.

The largest replay J width is strictly below 5e-7; the largest primary J width is strictly below 1e-6. No failed witness was omitted. Results: `PILOT_RECORD_CHECK.json` and `FULL_RECORD_CHECK.json`, both PASS.

Fail-closed probes confirm empty input returns 1 rather than success, an unknown lower kind returns 3, and an artificially tiny maximum-leaf limit returns 3 with the expected diagnostic. The successful-run and probe exit records are retained.

## Composition, exact scope of the CDF implication, and reproducibility

The submitted `FULL_LOWER_COMPOSITION.md` is accepted at its frozen hash. The small analytic lower dependency covers all 0<m<=3/20. The exact coefficient cover, numerical cells and tails cover all 3/20<m<=1. These are the same normalization, sign law, arbitrary finite dimension and strict-event convention. Thus there is no unresolved lower-central coefficient or threshold range.

If the matching weak upper-central statement P(|X|<=x)<=H(x)+H(m) is separately accepted for all m and x>=0, then for x>0 the identities

    P(|X|<=x)=2F(x)-1,
    P(|X|<x)=2F(x-)-1

give the two normal-approximation bounds on F(x), retaining the stronger lower statement on F(x-). For y>0, F(-y)=1-F(y-) transfers both bounds to negative arguments; the needed upper bound on F(y-) follows from F(y-)<=F(y). At zero, F(0)=1/2+P(X=0)/2 and the weak upper-central bound controls the atom. The resulting conditional implication is

    |P(X<=x)-Phi(x)| <= Phi(m)-1/2,    for every real x.

This report deliberately does not accept the separate unfinished upper package. A later global-composition addendum may bind both completed verdicts without changing this frozen lower verdict.

All inputs, raw replay outputs, independently authored exact checkers, source diff, failure probes, environment details, and dependency copies are retained in this directory. `INPUT_SHA256SUMS` binds frozen inputs/dependencies. `audit_manifest.json` and `SHA256SUMS` bind final artifacts. `build_replay.sh` documents a portable fresh build retaining original source bytes and include layout; it runs sequentially by default or uses four explicitly supplied CPU affinities. The standard-library exact checkers run entirely from this directory. Timing fields are descriptive, not acceptance inputs.

No unresolved mathematical or computational blocker remains for the stated full strict lower-central claim.
