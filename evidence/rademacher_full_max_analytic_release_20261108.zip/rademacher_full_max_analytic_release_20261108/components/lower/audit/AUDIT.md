# Independent audit: complete strict lower-central theorem

Date: 2026-11-08. Verdict: **PASS**.

## Result and limits

The submitted proof establishes, for every finite deterministic real coefficient vector with sum a_i^2=1, independent unbiased Rademacher signs, actual maximum m=max_i |a_i| in (0,1], and every x>=0,

    P(|X|<x) >= H(x)-H(m),   H(t)=2 Phi(t)-1.

The central event is strict. Unequal coefficients, negative coefficients, zero coefficients, and atoms are all included. No gap, false displayed identity, incorrect comparison direction, or missing parameter region was found. **No change to the primary proof is required.**

The newly audited part is x>2m for all actual m; the independently accepted x<=2m theorem is retained as an explicit analytic input. This is the entire lower-central side only. It does not prove the weak upper-central side, the remaining middle-maximum full Kolmogorov theorem, the unrestricted q strengthening, mathematical priority, or proof-assistant formalization.

Reviewed primary: `frozen_sources/candidate/PROOF.md`, SHA-256
`a01325278bbcfaaae016dcfe1b18df39431573a9d7a13c50abfa792324988d8d`.
Line references below refer to that exact file.

## 1. Evidence, integrity, and independence

The candidate proof, audit request, source manifest, actual-frequency reflection proof/audit, and accepted local paired-closure audit/verdict were read. The accepted input contract was checked against the frozen source statements and event conventions. The smoothing theorem and accepted local closure are not re-proved from first principles by this new audit.

All 43 entries in the candidate SOURCE_HASHES.json matched their bytes. These files plus the manifest itself were copied into this audit's `frozen_sources/candidate/`, giving 44 frozen files. `FROZEN_SOURCE_HASHES.json` records original locations and hashes. The accepted audit's own 31-file manifest and its 24 retained-source hashes were also checked, giving 55 additional inherited integrity comparisons in `INHERITED_INTEGRITY.json`.

The primary checker was neither read for its algorithm nor executed. The independent `independent_exact_checks.py` constructs the bivariate polynomial from its mathematical integral definition, specializes its boundaries, and uses triangular Bernstein-basis elimination. It independently expands the resulting Bernstein sum back to the power basis. Its 56 exact checks pass, including all 25 submitted positive Bernstein coefficients, both trigonometric lower polynomials, the rational error margins, and both variance joins. Only integer and Fraction arithmetic is used. No parameter grid, numerical quadrature, floating acceptance test, coefficient search, or old numerical certificate is a proof input. Frozen historical packages contain older results, but those computational assertions are not imported into this proof.

## 2. Actual-frequency pairing and the all-phase envelope

The retained Prawitz input is

    P(|X|<x) >= -2 J(x),
    J(x) = integral_0^1 k_(x/m)(u) f(pi u/m) du,

for x>0, with f(t)=product cos(a_i t). At a positive threshold, symmetry gives the exact atom-sensitive identity P(|X|<x)=2P(X<x)-1. Thus the sign and strict-event convention agree with the cited one-sided strict-tail smoothing theorem.

For 0<=v<=pi/2 and r=|a_i|/m<=1,

    rv <= r(pi-v) <= pi-rv,
    |cos(r(pi-v))| <= cos(rv).

Multiplication proves |f((pi-v)/m)|<=f(v/m), the latter product being nonnegative. Pairing the two halves of J therefore gives J<=integral_0^(1/2) [k(u)+|k(1-u)|] f(pi u/m)du. Multiplication by -2 and the substitution v=pi u give exactly (7), including its direction and factor 2/pi. This argument makes no restriction on xi=x/m, apart from the positive threshold needed here.

Here is an independent direct derivation of the new identities in lines 46-52. Put s=sin v, c=cos v, alpha=delta v, beta=delta(pi-v), and R=v/s-c. The original kernel simplifies to

    k_(1+delta)(v/pi)
      = -(1-v/pi) sin(alpha)/s - sin(v+alpha)/pi,

    k_(1+delta)(1-v/pi)
      = -[sin(v-beta)+(v/s)sin(beta)]/pi.

Expand the remaining sines. This gives

    -k1 = sin(alpha)/s + [s cos(alpha)-R sin(alpha)]/pi,
    k2 = -[s cos(beta)+R sin(beta)]/pi.

These are the submitted identities. The second numerator has absolute value at most A=sqrt(s^2+R^2). Consequently W=-k1-|k2| is bounded below by sin(alpha)/s-E/pi with

    E=A-s cos(alpha)+R sin(alpha)>=0.

The last inequality is Cauchy-Schwarz for the vector (s,-R) and the unit vector (cos alpha,sin alpha). There is no assumption about the sign of k2 or W, and no hidden restriction delta<=1 or delta<=2.

The removable limits at v=0 are harmless: R=O(v^2), A=O(v), E tends to zero, and sin(delta v)/sin v tends to delta for each finite delta. At v=pi/2 the formulas have no singular denominator. Each finite m>0 and finite x has finite delta. All integrals are therefore proper after endpoint extension.

## 3. Trigonometric inequalities and the integrated phase error

For nonnegative arguments, the needed odd Taylor polynomials for sine are global lower bounds. One elementary justification starts with sin t<=t for all t>=0 and repeatedly integrates the inequality with alternating signs using sin''=-sin. It does not require an alternating-series magnitude condition at 2v.

With z=v^2 and v<=pi/2<11/7, we have z<5/2. The degree-7 lower bound for sin v and degree-11 lower bound for sin(2v) give, by exact expansion,

    (2/3)v^2 sin v-v+sin v cos v
      >= v^5[1/45-z/140+13z^2/22680-4z^3/155925].

Discard the nonnegative quadratic term and use z<=5/2 in the two negative terms. The remaining rational margin is exactly

    1/45-(5/2)/140-4(5/2)^3/155925 = 989/249480 >0.

Division by sin v proves R<=2v^2/3 for v>0. Nonnegativity of R follows already from v/sin v>=1>=cos v.

Likewise the independent expansion of (1+v^2/4) times the degree-7 sine lower polynomial minus v is

    v^3[1/12-z/30+z^2(38-z)/20160].

For z<=5/2 the first two terms have nonnegative sum and the last is nonnegative. This proves 1<=v/sin v<=1+v^2/4, with v=0 covered by continuity.

Now A-s=R^2/(A+s)<=R^2/(2s). The preceding bounds imply

    A-s <= (2/9)v^3+(1/18)v^5.

In addition, s(1-cos(delta v))<=delta^2 v^3/2 and R sin(delta v)<=2 delta v^3/3, using 1-cos t<=t^2/2 and sin t<=t for all t>=0. The latter inequality remains an upper bound when sin(delta v) is negative. Adding proves (5) for every delta>=0.

On the low-frequency half-band, L=cos(v)^p<=F<=G=exp(-p v^2/2), where p=1/m^2. The lower comparison follows by summing log cos(rv)>=r^2 log cos v; the upper follows from log cos t<=-t^2/2. All factors are nonnegative and endpoints follow by continuity. Because E>=0, replacing F by G in the subtracted phase term is conservative. Extending its nonnegative integral to infinity and using

    integral_0^infinity v^3 G(v)dv=2m^4,
    integral_0^infinity v^5 G(v)dv=8m^6

gives exactly (8).

## 4. Oscillatory sine split, cutoff remainder, and Gamma scale

The Gaussian identity in (127)-(128) follows by differentiating in delta, evaluating the Gaussian cosine transform, and using the value zero at delta=0. Differentiation is dominated by G and is justified for every finite delta. Write

    D(v)=F(v)sin(delta v)/sin v-G(v)sin(delta v)/v.

If the sine is nonnegative, sin v<=v and F>=L give

    D >= -(G-L)sin(delta v)/v >= -delta(G-L).

If the sine is negative, F<=G and multiplication by that negative sine give

    D >= -G(1/sin v-1/v)|sin(delta v)| >= -(v/4)G.

The first possible negative interval starts at pi/delta. Replacing all negative portions in [0,pi/2] by the larger domain [pi/delta,infinity) for the nonnegative majorant vG/4 gives (9). The estimate 1/sin v-1/v<=v/4 is used only on the original half-band; no claim about sine denominators outside that interval is made. For delta<=2 there is no negative interval inside it, so the same positive upper bound is still valid.

The omitted Gaussian main term beyond pi/2 has absolute value at most delta integral_(pi/2)^infinity G. The positive-sine loss can be enlarged to delta integral_0^(pi/2)(G-L), since G-L>=0. Combining these two losses gives exactly

    delta[(2/pi) integral_0^infinity G
              -(2/pi) integral_0^(pi/2)L]
      =delta[c0 m-A0(p)].

This confirms (10), with no double sign error or missing cutoff term.

The beta integral gives A0(p)=Gamma((p+1)/2)/(sqrt(pi)Gamma((p+2)/2)). For z=p/2,

    A0(p)=1/[sqrt(pi z) R_G(z)]=c0 m/R_G(p/2),
    R_G(z)=sqrt(z)Gamma(z)/Gamma(z+1/2).

In particular the scale is p/2, not (p+2)/2 from the earlier accepted local calculation.

For completeness the retained digamma integral gives

    (log R_G)'(z)
      =1/(2z)-integral_0^infinity e^(-zt)/(1+e^(-t/2))dt
      =-(1/2)integral_0^infinity e^(-zt)tanh(t/4)dt.

The integration constant is fixed by R_G(z)->1. This standard ratio limit may also be obtained without a formal asymptotic remainder: in the beta integral for A0, substitute w=sqrt(p)v, use cos(w/sqrt(p))^p->exp(-w^2/2), and dominate by exp(-w^2/2). Dominated convergence gives sqrt(p)A0(p)->c0 and hence R_G(p/2)->1. Integration from z to infinity then proves the displayed log integral. Its integrand is nonnegative and integrable for every z>0, so the interchange is justified by Tonelli.

Using tanh(t/4)<=t/4 yields log R_G(z)<=1/(8z). Thus A0>=c0 m exp(-m^2/4). This has the required direction when substituted into -delta[c0m-A0]. Together with the phase and negative-sine errors this proves (12) exactly.

## 5. Budget normalization and concavity

The constants are conservative in the indicated directions. From 25/8<pi<22/7 one obtains 199/250<c0<4/5. Also

    [2/(pi^2 c0)]^2=2/pi^3<(32/125)^2,
    (4/9)(32/125)=128/1125<57/500.

For u>0 the maximum of u^2 exp(-u) is 4/e^2. With u=pi^2/(2y^2), this gives the negative-sine loss at most 8m^2y^4/(e^2 pi^5)<m^2y^4/250. The displayed integer comparison is correct. Dividing by c0 gives a coefficient less than 1/199, hence less than 1/198. The exponential loss uses 1-exp(-m^2/4)<=m^2/4.

Directly,

    M(m,y)=c0 integral_0^m
      [exp(-t^2/2)-exp(-(t+y)^2/2)]dt.

After subtracting all four errors and dividing by c0m, the function B in (14) is indeed a lower bound. The m powers in every term are correct.

For fixed y>0 set f_y(t)=exp(-t^2/2)-exp(-(t+y)^2/2) and g(t)=(t^2-1)exp(-t^2/2). Then f_y''=g(t)-g(t+y). For 0<=t<=1, either t+y<=1 and g is increasing throughout [t,t+y], or t+y>=1 and g(t)<=0<=g(t+y). Thus f_y''<=0 on [0,1], even for arbitrarily large y.

The integral average in B is integral_0^1 f_y(mr)dr, hence concave in m on [0,1]. The subtracted polynomial m(y+2m/3)^2 is convex for m>=0, as its expansion is y^2m+(4y/3)m^2+(4/9)m^3. The m^5 term is convex, and the other terms are linear in m. Therefore B is concave as claimed. At m=0 its continuous extension is 1-exp(-y^2/2)>0. Positive values at the upper endpoint of any vertical m interval imply positive values throughout that interval by the concave chord bound.

## 6. Three whole-interval polynomial certificates

Taylor's theorem with the signed remainder gives T3(z)<=exp(-z)<=T4(z) for every z>=0. Applying it pointwise inside the defining integral proves mB>=P with P exactly as in lines 230-234.

Independently reconstructing this bivariate polynomial confirms the displayed degree-six expression P(y,y)/y^3 and all three Bernstein representations:

- P(y,y)/y^3 on [0,5/8]: degree 6, 7 strictly positive coefficients.
- P(1/2,y) on [1/2,3/2]: degree 8, 9 strictly positive coefficients.
- P(5/8,y) on [5/8,5/6]: degree 8, 9 strictly positive coefficients.

Every coefficient agrees exactly with the source. The independent JSON records their full values and power-basis terms. Reconstruction by expansion verifies each identity as a polynomial identity, not merely at finitely many y values. The Bernstein basis functions are nonnegative and sum to one on each closed interval, so positivity is uniform and includes both endpoints.

For D1, the upper-m boundary is m=y when 0<y<=1/2, controlled by the first polynomial, and m=1/2 when 1/2<=y<=3/2, controlled by the second. For D2 it is m=y when 0<y<=5/8 and m=5/8 when 5/8<=y<=5/6. Concavity with the positive m=0 limit proves B>0 throughout both submitted regions. The removable polynomial value y=0 causes no division issue: the theorem only uses m>0 and y>=m, hence y>0.

## 7. Unbounded y and both variance joins

For 0<m<=1/2 and y>=3/2, let x=y+m. If H(m)>=1/x^2, Markov applied to X^2 on |X|>=x gives

    P(|X|<x)>=1-1/x^2>=1-H(m)>=H(x)-H(m).

Otherwise H(m)<1/(y+m)^2. Since exp(-t^2/2)>=1-t^2/2,

    H(m)>=c0m(1-m^2/6)>=(23/24)c0m,
    m(y+m)^2<24/(23c0).

This is a necessary consequence of failure of the simple variance criterion, not an extra distributional hypothesis.

Monotonicity of the Gaussian density and exp(9/8)>3 give

    M>=H(m)-c0m exp(-y^2/2)>(5/8)c0m.

Divide the four errors in (12) by m. In order they are bounded by

    4/23,
    48/(23c0 pi^2),
    1/(36pi^2),
    24/(23c0 e pi^3).

The first follows from c0ym/4<6y/[23(y+m)^2]<=6/(23y)<=4/23. The second uses y+2m/3<=y+m and the necessary condition above. The third uses m^5<=1/32. For the fourth, m<24/(23c0y^2), and maximization of u exp(-u) at u=1 gives exp(-pi^2/(2y^2))/y^2<=2/(e pi^2). All directions are conservative.

After replacing c0, pi and e in denominators by their lower bounds and the positive budget c0 by its lower bound, the exact residual is

    14895943/411930000>0.

The elementary exponential constants are independently certified by finite positive power-series partial sums. Thus the unbounded region is genuinely closed without further polynomial approximations in y.

For both joins, differentiation shows the maximum of t^3 phi(t) is at sqrt(3). The submitted elementary estimates give it less than 4/5<1. Consequently

    partial_x [H(m)+1-H(x)-x^(-2)]
      =2[x^(-3)-phi(x)]>0,

and the same function is increasing in m. At m=1/2, x=4/3, integrating T4(t^2/2) and multiplying by 4/5 gives exactly 26586523759/60949905408. Subtracting this from 7/16 leaves 79059857/60949905408>0. This proves Join A.

Along x=2m the derivative is exactly

    2phi(m)+4[(2m)^(-3)-phi(2m)]>0.

At m=5/8, integrating T2(t^2/2) between 5/8 and 5/4 and multiplying by 4/5 gives exactly 65129/196608. Its difference from 9/25 is 141247/4915200>0. Since (4m^2)^(-1)=16/25 there, Join B follows. The Taylor upper polynomials are positive; replacing c0 by 4/5 is therefore in the correct direction in each anchor calculation.

## 8. Coverage, endpoints, and final scope

For x<=2m the unchanged accepted local theorem applies. For x>2m:

1. If m>=5/8, Join B applies.
2. If 1/2<=m<5/8 and x>=4/3, Join A applies.
3. If 1/2<=m<5/8 and x<4/3, then y=x-m>m and y<4/3-1/2=5/6, so D2 applies.
4. If 0<m<1/2 and y<=3/2, D1 applies.
5. If 0<m<1/2 and y>=3/2, the unbounded-y argument applies.

This exhausts all finite m>0 and x>=0. The boundaries x=2m, m=1/2, m=5/8, x=4/3, and y=3/2 are all covered, with overlap where indicated. Normalization rules out m=0; no uniform limiting argument at m=0 is required. Coefficient signs and zeros do not affect the cosine or variance arguments.

The phase/Prawitz branch starts with the strict central event and never changes it. Every second-moment step bounds the weak complement |X|>=x. Thus there is no atom loss, half-weight substitution, or implicit continuity assumption about the discrete distribution.

**Final verdict: PASS for the complete analytic strict lower-central theorem at all actual maxima. The analytic upper-middle obligation remains separate.**
