# Карта доказательства и источников

Все пути ниже относительны корню архива. Полный побайтовый источник каждой
копии указан в SOURCE_MAP.json. Абсолютные исторические пути служат только
происхождением; при автономной проверке они не открываются.

## Нижняя оценка

- components/lower/primary/PROOF.md: новая глобальная фазовая часть.
- components/lower/audit/AUDIT.md, VERDICT.json: окончательная приёмка всех x≥0.
- components/lower/primary/frozen_inputs/: ранее принятая полоса x≤2m,
  actual-frequency reflection, полный связанный аналитический аудит и
  контракт внешнего неравенства Правица.
- components/lower/audit/independent_exact_checks.py: отдельный рациональный
  replay на 56 проверок, 25 коэффициентов Бернштейна.

components/lower/ целиком совпадает со старым принятым lower-release.
Его прежние замечания об оставшейся верхней стороне исторические.

## Внешняя верхняя оценка

- components/outer/primary/PROOF.md: m≥3/20, x≥m.
- components/outer/audit/INDEPENDENT_AUDIT.md и AUDIT_VERDICT.json: окончательная приёмка.
- components/outer/audit/independent_exact_checks.py: 61 самостоятельная
  рациональная проверка, 25 коэффициентов Бернштейна.
- components/outer/primary/frozen_inputs/ACCEPTED_REFLECTION_BRIDGE_RELEASE/:
  actual-frequency reflection и проверенный контракт Правица.

Для **0<m≤3/20 и x≥m** дополнительно нужны:

- components/outer/primary/frozen_inputs/ACCEPTED_SMALL_UPPER_PROOF/UPPER015_EXTENSION_PROOF.md,
  разделы 2–5, и указанные там знаковые формулы из BASE_RECONSTRUCTED_PROOF.md;
- components/outer/primary/frozen_inputs/ACCEPTED_SMALL_UPPER_AUDIT/INDEPENDENT_AUDIT.md
  и AUDIT_VERDICT.json, принимающие эти точные исходники.

Это явная аналитическая зависимость для малых m, а не молчаливое расширение
новой фазовой теоремы на m<3/20. Разделы 2–5 используют точные рациональные
бюджеты, монотонность и положительные конечные ряды с известным знаком остатка.
Их непрерывные области включают x=m и все последующие стыки.

В историческом small-max пакете также сохранена старая центральная affine-часть
и её AFFINE015_INTERVALS.json, certify_affine015.py и прочие результаты.
В настоящей композиции центральная область закрыта новым отдельным аудитом,
поэтому эти исторические affine-сертификаты не являются входами доказательства.
Они остаются в неизменённом исходном дереве для прослеживаемости и **не запускаются**.
Все новые replay используют лишь стандартную библиотеку Python.

## Центральная верхняя оценка

- components/central/primary_small/PROOF.md: 0<m≤1/2, 0≤x≤m.
- components/central/cap_defect/PROOF.md: cap-defect reflection.
- components/central/primary_middle/PROOF.md: 1/2≤m≤27/40, 0≤x≤m.
- components/central/audit/AUDIT.md, VERDICT.json: полная приёмка всех m,
  включая элементарный large-max helper при m≥27/40.
- components/central/audit/frozen_inputs/large/: неизменённый helper и его аудит.
- components/central/audit/frozen_inputs/prawitz/: внешний контракт и reflection.
- components/central/audit/independent_verifier.py: 93 математические и
  24 original/frozen hash-проверки; ровно 117 сохранённых записей.

Двенадцать входов центрального аудита сохранены также как отдельные оригинальные
зеркала под components/central/original_inputs/. Каждая пара сверяется по SHA-256
и размеру. PORTABLE_SOURCE_MAP.json связывает исходный абсолютный source,
замороженный вход и переносимый оригинал. Во время replay меняются только
source-поля временной копии метаданных. Код аудитора и proof-байты не изменяются.

## Внешние аналитические входы

Основное сглаживание: Keller и Klein, *Proof of Tomaszewski's Conjecture on
Randomly Signed Sums*, Theorem 4.5, (39)–(40):
https://arxiv.org/html/2006.16834v4#S4.SS1.SSS1

Пакет включает проверенный source contract с нормировкой и строгими/слабыми
событиями, а не полное воспроизведение опубликованного доказательства Правица.
Нижняя фазовая часть отдельно использует стандартные интегральные факты
для гамма-функции; нужная нормировка обсуждается в её окончательном аудите.

## Что именно проверяет verify.py

1. Полный состав файлов без неожиданных добавлений, пропусков и символических ссылок.
2. Размеры, SHA-256, ключевые принятые версии, source maps и все связи
   primary/frozen, включая small-max dependency.
3. Точные границы трёх компонент, статус полной max-композиции и отсутствие
   необоснованных q-, novelty-, peer-review- и formal-verification заявлений.
4. Три независимых арифметических replay в изолированных временных каталогах,
   со сравнением JSON-результатов **побайтно**, а не только по слову PASS.
5. При --negative-controls: отказ на изменённый proof, отсутствие STATUS.json
   и добавленный посторонний файл.

Не исполняются первичные checkers, старые численные сертификаты или код,
загруженный с внешних сайтов. Хеш-проверка не заменяет чтение математического
доказательства. Криптографической подписи авторства этот пакет не содержит.
